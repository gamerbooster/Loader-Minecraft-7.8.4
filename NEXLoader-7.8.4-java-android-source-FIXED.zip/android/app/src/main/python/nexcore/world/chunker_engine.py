from __future__ import annotations

import hashlib
import io
import lzma
import os
import platform
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping
from urllib.request import Request, urlopen

CHUNKER_VERSION = "1.21.0"
CHUNKER_SHA256 = "63148e587f5ee5a2ca7ebae1079b235c82ae4d1eff8f7a8a8a3398332513dda6"
CHUNKER_URL = f"https://github.com/HiveGamesOSS/Chunker/releases/download/{CHUNKER_VERSION}/chunker-cli-{CHUNKER_VERSION}.jar"
# Android OpenJDK 17 mobile builds are published as GitHub Actions artifacts.
# The branch is explicit so the runtime source is tied to a maintained Android build.
ANDROID_JRE17_BRANCH = "Build_JRE_17"
ANDROID_JRE17_BASE_URL = "https://nightly.link/FCL-Team/Android-OpenJDK-Build/workflows/build/Build_JRE_17"
MAX_ENGINE_DOWNLOAD_BYTES = 64 * 1024 * 1024
MAX_ANDROID_JRE_DOWNLOAD_BYTES = 180 * 1024 * 1024
DEFAULT_TARGET = "BEDROCK_1_26_50"


class WorldEngineUnavailable(RuntimeError):
    pass


def _is_android_runtime() -> bool:
    """Return True for the current Android/ART runtime used by Chaquopy."""
    if sys.platform == "android":
        return True
    return Path("/system/bin/app_process").exists() and Path("/system/build.prop").exists()


def _android_arch() -> str:
    machine = platform.machine().lower()
    aliases = {
        "aarch64": "aarch64",
        "arm64": "aarch64",
        "x86_64": "x86_64",
        "amd64": "x86_64",
        "x86": "x86",
        "i686": "x86",
        "armv7l": "aarch32",
        "armv8l": "aarch32",
    }
    arch = aliases.get(machine)
    if arch in {"aarch64", "x86_64"}:
        return arch
    raise WorldEngineUnavailable(f"Arquitectura Android no soportada por el JRE 17 integrado: {machine or 'desconocida'}")


def _android_jre_url() -> str:
    arch = _android_arch()
    return f"{ANDROID_JRE17_BASE_URL}/jre17-{arch}.zip"


def _java_major(java: str | None, env: Mapping[str, str] | None = None) -> int | None:
    if not java:
        return None
    try:
        proc = subprocess.run(
            [java, "-version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
            check=False,
            env=dict(env) if env is not None else None,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    match = re.search(r'version\s+"?(\d+)(?:\.(\d+))?', proc.stdout)
    if not match:
        return None
    major = int(match.group(1))
    if major == 1 and match.group(2):
        return int(match.group(2))
    return major


@dataclass(frozen=True)
class EngineInfo:
    version: str
    jar: str
    java: str
    sha256: str
    env: Mapping[str, str] | None = None
    runtime: str = "desktop"


def _candidate_paths(explicit: str | Path | None = None) -> list[Path]:
    values: list[Path] = []
    if explicit:
        values.append(Path(explicit).expanduser())
    env = os.environ.get("NEX_CHUNKER_JAR")
    if env:
        values.append(Path(env).expanduser())
    here = Path(__file__).resolve()
    values.extend([
        here.parents[2] / "tools" / "world_engine" / f"chunker-cli-{CHUNKER_VERSION}.jar",
        Path.cwd() / "tools" / "world_engine" / f"chunker-cli-{CHUNKER_VERSION}.jar",
    ])
    out: list[Path] = []
    seen: set[str] = set()
    for x in values:
        try:
            key = str(x.resolve())
        except OSError:
            key = str(x)
        if key not in seen:
            seen.add(key)
            out.append(x)
    return out


def _sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def _android_runtime_root(engine_dir: str | Path) -> Path:
    return Path(engine_dir).expanduser().resolve() / f"jre17-{_android_arch()}"


def _android_java_env(jre_root: Path) -> dict[str, str]:
    env = os.environ.copy()
    env["JAVA_HOME"] = str(jre_root)
    env["PATH"] = str(jre_root / "bin") + os.pathsep + env.get("PATH", "")
    lib_parts = [
        str(jre_root / "lib"),
        str(jre_root / "lib" / "server"),
        str(jre_root / "lib" / "jli"),
    ]
    existing = env.get("LD_LIBRARY_PATH", "")
    if existing:
        lib_parts.append(existing)
    env["LD_LIBRARY_PATH"] = os.pathsep.join(lib_parts)
    env.setdefault("JAVA_TOOL_OPTIONS", "-Dfile.encoding=UTF-8")
    return env


def _find_release_file(root: Path) -> Path | None:
    direct = root / "release"
    if direct.is_file():
        return direct
    for p in root.rglob("release"):
        try:
            if p.is_file() and len(p.relative_to(root).parts) <= 4:
                return p
        except ValueError:
            continue
    return None


def _safe_zip_member(name: str) -> bool:
    p = Path(name)
    return not p.is_absolute() and ".." not in p.parts and not name.startswith("\\")


def _download_to(path: Path, url: str, max_bytes: int, label: str) -> None:
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".part", dir=str(path.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        request = Request(url, headers={"User-Agent": "NEXLoader-World-Engine/7.8.4-M2"})
        with urlopen(request, timeout=120) as response, tmp.open("wb") as out:
            total = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                total += len(block)
                if total > max_bytes:
                    raise WorldEngineUnavailable(f"{label} supera el límite de seguridad de {max_bytes // (1024 * 1024)} MiB.")
                out.write(block)
        tmp.replace(path)
    except WorldEngineUnavailable:
        tmp.unlink(missing_ok=True)
        raise
    except Exception as exc:
        tmp.unlink(missing_ok=True)
        raise WorldEngineUnavailable(f"No se pudo descargar {label}: {exc}") from exc


def _install_android_jre(runtime_root: Path) -> tuple[Path, dict[str, str]]:
    runtime_root.parent.mkdir(parents=True, exist_ok=True)
    existing_release = _find_release_file(runtime_root)
    java = runtime_root / "bin" / "java"
    if existing_release and java.is_file():
        try:
            java.chmod(java.stat().st_mode | 0o111)
        except OSError:
            pass
        env = _android_java_env(runtime_root)
        if _java_major(str(java), env) >= 17:
            return java, env
        shutil.rmtree(runtime_root, ignore_errors=True)

    with tempfile.TemporaryDirectory(prefix="nex_jre17_") as td:
        work = Path(td)
        artifact = work / "jre17-artifact.zip"
        _download_to(artifact, _android_jre_url(), MAX_ANDROID_JRE_DOWNLOAD_BYTES, "JRE Android 17")
        try:
            with zipfile.ZipFile(artifact) as zf:
                names = zf.namelist()
                bad = [n for n in names if not _safe_zip_member(n)]
                if bad:
                    raise WorldEngineUnavailable(f"JRE Android contiene rutas inseguras: {bad[0]}")
                tar_name = next((n for n in names if n.lower().endswith(".tar.xz")), None)
                if tar_name is None:
                    raise WorldEngineUnavailable("El artefacto JRE Android no contiene un .tar.xz válido.")
                tar_path = work / "jre.tar.xz"
                with zf.open(tar_name) as src, tar_path.open("wb") as dst:
                    shutil.copyfileobj(src, dst, 1024 * 1024)
        except zipfile.BadZipFile as exc:
            raise WorldEngineUnavailable(f"Artefacto JRE Android inválido: {exc}") from exc

        unpack = work / "unpacked"
        unpack.mkdir()
        try:
            with tarfile.open(tar_path, mode="r:xz") as tf:
                tf.extractall(unpack, filter="data")
        except Exception as exc:
            raise WorldEngineUnavailable(f"No se pudo extraer el JRE Android: {exc}") from exc

        release = _find_release_file(unpack)
        if release is None:
            raise WorldEngineUnavailable("El JRE Android extraído no contiene el archivo release.")
        actual_root = release.parent
        java = actual_root / "bin" / "java"
        if not java.is_file():
            raise WorldEngineUnavailable("El JRE Android extraído no contiene bin/java.")
        try:
            java.chmod(java.stat().st_mode | 0o111)
        except OSError:
            pass

        staged = work / "runtime-final"
        shutil.copytree(actual_root, staged, symlinks=True)
        old = runtime_root.with_name(runtime_root.name + ".old")
        shutil.rmtree(old, ignore_errors=True)
        if runtime_root.exists():
            runtime_root.rename(old)
        staged.rename(runtime_root)
        shutil.rmtree(old, ignore_errors=True)

    env = _android_java_env(runtime_root)
    java = runtime_root / "bin" / "java"
    major = _java_major(str(java), env)
    if major is None or major < 17:
        shutil.rmtree(runtime_root, ignore_errors=True)
        raise WorldEngineUnavailable("El JRE Android instalado no pudo iniciar Java 17+ correctamente.")
    return java, env


def _android_heap_option() -> str:
    """Keep Chunker from taking the desktop-style 75% heap on phones."""
    try:
        page = os.sysconf("SC_PAGE_SIZE")
        pages = os.sysconf("SC_PHYS_PAGES")
        ram_mb = max(512, (page * pages) // (1024 * 1024))
    except (OSError, ValueError):
        ram_mb = 4096
    # Chunker is memory-heavy; reserve a large portion of RAM for Android.
    heap_mb = max(768, min(4096, int(ram_mb * 0.45)))
    return f"-Xmx{heap_mb}m"


def _android_engine_info(jar_path: Path) -> EngineInfo:
    runtime_root = _android_runtime_root(jar_path.parent)
    java, env = _install_android_jre(runtime_root)
    digest = _sha256(jar_path)
    if digest != CHUNKER_SHA256:
        raise WorldEngineUnavailable("El JAR de Chunker no pasó la verificación SHA-256.")
    return EngineInfo(
        version=CHUNKER_VERSION,
        jar=str(jar_path),
        java=str(java),
        sha256=digest,
        env=env,
        runtime="android",
    )


def find_engine(explicit: str | Path | None = None) -> EngineInfo | None:
    for candidate in _candidate_paths(explicit):
        if not candidate.is_file():
            continue
        digest = _sha256(candidate)
        if digest != CHUNKER_SHA256:
            continue
        if _is_android_runtime():
            try:
                return _android_engine_info(candidate)
            except WorldEngineUnavailable:
                return None
        java = shutil.which("java")
        if _java_major(java) is None or _java_major(java) < 17:
            return None
        return EngineInfo(version=CHUNKER_VERSION, jar=str(candidate), java=java, sha256=digest)
    return None


def engine_status(explicit: str | Path | None = None) -> dict:
    if _is_android_runtime():
        arch = platform.machine().lower() or "unknown"
        try:
            arch_norm = _android_arch()
            supported = True
            url = _android_jre_url()
        except WorldEngineUnavailable:
            arch_norm = arch
            supported = False
            url = None
        return {
            "available": False,
            "runtime": "android",
            "can_prepare": supported,
            "android_arch": arch_norm,
            "jre17_source": url,
            "reason": "Se instalará automáticamente un JRE Android 17 y Chunker CLI verificado al convertir." if supported else "La arquitectura Android actual no dispone de un JRE 17 móvil compatible.",
        }
    java = shutil.which("java")
    java_major = _java_major(java)
    invalid_candidate = None
    for candidate in _candidate_paths(explicit):
        if candidate.is_file():
            digest = _sha256(candidate)
            if digest == CHUNKER_SHA256 and java_major is not None and java_major >= 17:
                return {"available": True, "version": CHUNKER_VERSION, "jar": str(candidate), "java": java, "java_major": java_major, "sha256": digest}
            invalid_candidate = candidate
    if invalid_candidate is not None:
        reason = "Chunker JAR exists but failed SHA-256 verification."
        if java_major is None:
            reason = "Chunker JAR exists, but Java 17+ is unavailable."
        elif java_major < 17:
            reason = f"Chunker JAR exists, but Java {java_major} is too old; Java 17+ is required."
        return {"available": False, "reason": reason, "jar": str(invalid_candidate), "java": java or None, "java_major": java_major}
    return {"available": False, "can_prepare": True, "reason": "Verified Chunker CLI not installed; se puede preparar automáticamente." if _is_android_runtime() else "Verified Chunker CLI not installed; run tools/fetch_world_engine.py.", "java": java or None, "java_major": java_major}


def fetch_verified_engine(destination: str | Path) -> EngineInfo:
    """Download/install the pinned world engine and a mobile JRE when required."""
    dest = Path(destination).expanduser().resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)

    if _is_android_runtime():
        if dest.is_file() and _sha256(dest) == CHUNKER_SHA256:
            return _android_engine_info(dest)
        _download_to(dest, CHUNKER_URL, MAX_ENGINE_DOWNLOAD_BYTES, "Chunker CLI")
        digest = _sha256(dest)
        if digest != CHUNKER_SHA256:
            dest.unlink(missing_ok=True)
            raise WorldEngineUnavailable(f"Chunker SHA-256 mismatch: got {digest}, expected {CHUNKER_SHA256}")
        return _android_engine_info(dest)

    if dest.is_file() and _sha256(dest) == CHUNKER_SHA256:
        java = shutil.which("java")
        java_major = _java_major(java)
        if java_major is not None and java_major >= 17:
            return EngineInfo(version=CHUNKER_VERSION, jar=str(dest), java=java, sha256=CHUNKER_SHA256)
        raise WorldEngineUnavailable("Java 17+ is required to run the Chunker CLI.")

    _download_to(dest, CHUNKER_URL, MAX_ENGINE_DOWNLOAD_BYTES, "Chunker CLI")
    digest = _sha256(dest)
    if digest != CHUNKER_SHA256:
        dest.unlink(missing_ok=True)
        raise WorldEngineUnavailable(f"Chunker SHA-256 mismatch: got {digest}, expected {CHUNKER_SHA256}")
    java = shutil.which("java")
    java_major = _java_major(java)
    if java_major is None or java_major < 17:
        raise WorldEngineUnavailable("Java 17+ is required to run the Chunker CLI.")
    return EngineInfo(version=CHUNKER_VERSION, jar=str(dest), java=java, sha256=CHUNKER_SHA256)


def run_conversion(input_dir: str | Path, output_dir: str | Path, *, target: str = DEFAULT_TARGET,
                   chunker_jar: str | Path | None = None, timeout: int = 1800,
                   converter_settings: str | None = None) -> tuple[Path, EngineInfo, str]:
    info = find_engine(chunker_jar)
    if info is None:
        raise WorldEngineUnavailable(engine_status(chunker_jar)["reason"])
    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    cmd: list[str] = [info.java]
    if info.runtime == "android":
        cmd.append(_android_heap_option())
    cmd.extend(["-jar", info.jar, "-i", str(source), "-f", target, "-o", str(output)])
    if converter_settings:
        cmd.extend(["-c", converter_settings])
    env = dict(info.env) if info.env is not None else os.environ.copy()
    env.setdefault("JAVA_TOOL_OPTIONS", "-Dfile.encoding=UTF-8")
    proc = subprocess.run(
        cmd,
        cwd=str(Path(info.jar).parent),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
    )
    log = proc.stdout[-200_000:]
    if proc.returncode != 0:
        raise RuntimeError(f"Chunker CLI failed with exit code {proc.returncode}.\n{log}")
    return output, info, log
