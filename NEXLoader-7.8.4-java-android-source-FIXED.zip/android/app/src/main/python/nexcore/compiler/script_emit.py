import json, re
from .runtime_emit import runtime_modules
from nex.version import NEXLOADER_VERSION


def _js(s):
    return json.dumps(s, ensure_ascii=False)


def _safe_ident(s):
    out=''.join(ch if (ch.isalnum() or ch=='_') else '_' for ch in str(s))
    return out.strip('_') or 'operation'

def _unique_js_name(base, used):
    """Return a deterministic module-level identifier that is not already used."""
    base=_safe_ident(base)
    candidate=base
    i=2
    while candidate in used:
        candidate=f'{base}_{i}'
        i+=1
    used.add(candidate)
    return candidate

def _sound_helper(o, idx=None):
    idx=(idx or _safe_ident(f'{o.args.get("method", "play")}_{o.id}'))[:70]
    sid=o.args.get('resolved_sound_id') or o.args.get('sound_hint') or ''
    return [
        f'export function nex_sound_{idx}(dimension, location, player, options = {{}}) {{',
        f'  const soundId = {_js(sid)};',
        '  if (player?.playSound) return playSoundToPlayer(player, soundId, options);',
        '  return playSoundAt(dimension, soundId, location, options);',
        '}', ''
    ]

def _scoreboard_helper(o, idx=None):
    idx=(idx or _safe_ident(f'{o.args.get("method", "scoreboard")}_{o.id}'))[:70]
    method=o.args.get('method','')
    if method == 'getObjective':
        return [f'export function nex_scoreboard_{idx}(id) {{', '  return getObjective(world, id);', '}', '']
    if method == 'addObjective':
        return [f'export function nex_scoreboard_{idx}(id, displayName = id) {{', '  return ensureObjective(world, id, displayName);', '}', '']
    if method == 'removeObjective':
        return [f'export function nex_scoreboard_{idx}(id) {{', '  return removeObjective(world, id);', '}', '']
    if method == 'setScore':
        return [f'export function nex_scoreboard_{idx}(objective, participant, value) {{', '  return setScore(objective, participant, value);', '}', '']
    if method == 'addScore':
        return [f'export function nex_scoreboard_{idx}(objective, participant, value) {{', '  return addScore(objective, participant, value);', '}', '']
    if method == 'getScore':
        return [f'export function nex_scoreboard_{idx}(objective, participant) {{', '  return getScore(objective, participant);', '}', '']
    return [f'// ADAPTABLE SCOREBOARD METHOD: {method} — the call was detected, but argument semantics were not recoverable.', '']


def _action_helper(o, idx=None):
    cap=o.id
    idx=(idx or _safe_ident(f'{o.args.get("name", "cap")}_{o.id}'))[:70]
    hints=o.args.get('constant_hints') or o.args.get('near_strings') or []
    hjson=_js(hints)
    if cap=='effects.add':
        return [
            f'export function nex_action_{idx}(ctx, effect, duration, amplifier = 0, showParticles = true) {{',
            f'  // Java call: {o.args.get("owner")}.{o.args.get("name")}{o.args.get("descriptor","")} hints={hjson}',
            '  if (!effect || duration == null) throw new Error("[NEX] effects.add requires effect and duration");',
            '  return addEffect(ctx, effect, duration, amplifier, showParticles);', '}', ''
        ]
    if cap=='effects.remove':
        return [f'export function nex_action_{idx}(ctx, effect) {{', f'  // Java call: {o.args.get("owner")}.{o.args.get("name")}{o.args.get("descriptor","")}', '  if (!effect) throw new Error("[NEX] effects.remove requires effect");', '  return removeEffect(ctx, effect);', '}', '']
    if cap=='entity.teleport':
        return [f'export function nex_action_{idx}(ctx, location, dimension) {{', f'  // Java call: {o.args.get("owner")}.{o.args.get("name")}{o.args.get("descriptor","")}', '  if (!location) throw new Error("[NEX] entity.teleport requires location");', '  return teleport(ctx, location, dimension);', '}', '']
    if cap=='entity.damage':
        return [f'export function nex_action_{idx}(ctx, amount, cause) {{', f'  // Java call: {o.args.get("owner")}.{o.args.get("name")}{o.args.get("descriptor","")}', '  if (amount == null) throw new Error("[NEX] entity.damage requires amount");', '  return damage(ctx, amount, cause);', '}', '']
    if cap=='entity.impulse':
        return [f'export function nex_action_{idx}(ctx, vector) {{', f'  // Java call: {o.args.get("owner")}.{o.args.get("name")}{o.args.get("descriptor","")}', '  if (!vector) throw new Error("[NEX] entity.impulse requires vector");', '  return impulse(ctx, vector);', '}', '']
    if cap=='entity.command':
        return [f'export function nex_action_{idx}(ctx, command) {{', f'  // Java call: {o.args.get("owner")}.{o.args.get("name")}{o.args.get("descriptor","")}', '  if (!command) throw new Error("[NEX] entity.command requires command");', '  return runCommand(ctx, command);', '}', '']
    if cap in {'entity.dynamic_state','world.dynamic_state'}:
        return [f'export function nex_action_{idx}(ctx, key, value) {{', f'  // Java call: {o.args.get("owner")}.{o.args.get("name")}{o.args.get("descriptor","")}', '  if (!key) throw new Error("[NEX] dynamic state requires key");', '  return setDynamicState(ctx, key, value);', '}', '']
    if cap == 'tick.schedule':
        return [f'export function nex_action_{idx}(ticks, callback, repeating = false) {{', f'  // Java scheduler call: {o.args.get("owner")}.{o.args.get("name")}{o.args.get("descriptor","")}', '  return schedule(ticks, callback, repeating);', '}', '']
    return [f'// ADAPTABLE CAPABILITY HELPER: {o.id} — exported helper not automatically wired because Java receiver/arguments were not semantically recoverable.', '']


def emit(program, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    actions = {}
    for o in program.operations:
        if o.op == 'world_message' and o.status in {'convertible', 'emulated'}:
            actions.setdefault(o.args.get('method'), []).append(o.args.get('message'))

    imports = ['import { world, system } from "@minecraft/server";']
    mods = runtime_modules(program)
    if 'effects' in mods: imports.append('import { addEffect, removeEffect } from "./nex_runtime/effects.js";')
    if 'actions' in mods: imports.append('import { addEffect as actionAddEffect, removeEffect as actionRemoveEffect, teleport, damage, impulse, runCommand, setDynamicState, schedule } from "./nex_runtime/actions.js";')
    if 'state' in mods: imports.append('import { setEntityState, setWorldState } from "./nex_runtime/state.js";')
    if 'scheduler' in mods: imports.append('import { every, later } from "./nex_runtime/scheduler.js";')
    if 'physics' in mods: imports.append('import { startPhysics, spawnPhysicsBody } from "./nex_runtime/physics.js";')
    if 'input' in mods: imports.append('import { bindButton, INPUT_BUTTONS } from "./nex_runtime/input.js";')
    if 'ui' in mods: imports.append('import { showMenu } from "./nex_runtime/ui.js";')
    if 'particles' in mods: imports.append('import { spawnParticle } from "./nex_runtime/particles.js";')
    if 'sounds' in mods: imports.append('import { playSoundAt, playSoundToPlayer, broadcastSound } from "./nex_runtime/sounds.js";')
    if 'scoreboard' in mods: imports.append('import { getObjective, ensureObjective, setScore, addScore, getScore, removeObjective } from "./nex_runtime/scoreboard.js";')
    if 'inspection' in mods: imports.append('import { startInspection } from "./nex_runtime/inspection.js";')
    if 'map_hud' in mods: imports.append('import { startMapHud } from "./nex_runtime/map_hud.js";')

    lines=[f'// Generated by NEX Loader {NEXLOADER_VERSION}', *imports, '']
    action_plan=[]
    inspection_profiles=[o for o in program.operations if o.op=='feature_profile' and o.args.get('kind')=='hud_inspection' and o.status in {'emulated','convertible'}]
    if inspection_profiles:
        profile=inspection_profiles[0]
        lines.append(f'startInspection(world, {{ intervalTicks: {int(profile.args.get("interval_ticks",4))}, maxDistance: {int(profile.args.get("max_distance",8))} }});')
        lines.append('')
        action_plan.append({'id':profile.id,'status':profile.status,'lowering':'jade_style_view_inspection','source':profile.source})
    minimap_profiles=[o for o in program.operations if o.op=='feature_profile' and o.args.get('kind')=='minimap' and o.status in {'emulated','convertible','adaptable'}]
    if minimap_profiles:
        profile=minimap_profiles[0]
        lines.append('startMapHud(world, { intervalTicks: 10 });')
        lines.append('')
        action_plan.append({'id':profile.id,'status':profile.status,'lowering':'minimap_safe_hud_runtime','source':profile.source})
    # Initialize scoreboards whose objective id is explicitly recoverable. This is
    # safer than attempting to replay arbitrary Java arguments we cannot prove.
    for so in [x for x in program.operations if x.op=='scoreboard_op' and x.status in {'convertible','emulated'} and x.args.get('method')=='addObjective']:
        hints=[x for x in (so.args.get('hints') or []) if isinstance(x,str) and re.fullmatch(r'[A-Za-z0-9_.-]{1,64}',x)]
        if hints:
            obj=next((x for x in reversed(hints) if x.lower() not in {'scoreboard','objective','addobjective'}),None)
            if obj:
                lines.append(f'ensureObjective(world, {_js(program.mod_id+"_"+obj)}, {_js(obj)});')
    if any(o.op=='feature_profile' and o.args.get('kind') in {'hud_inspection','minimap'} for o in program.operations):
        # HUD modules each call startHud; calls are idempotent only by construction
        # in the generated source, so do not add a third interval here.
        pass
    emitted=set()
    declared_js_names=set()
    seen_cap_comments=set()

    # Java entity lifecycle sound calls can be lowered safely when the analyzer
    # identified their caller as hurt/death and linked the entity class. We do not
    # guess arbitrary sounds/timers.
    lifecycle_sounds={}
    for so in program.operations:
        if so.op != 'sound_play' or so.args.get('sound_role') not in {'hurt','death'}:
            continue
        sid=so.args.get('resolved_sound_id')
        if sid and so.args.get('entity_ids'):
            lifecycle_sounds.setdefault(so.args.get('sound_role'), []).append((sid, sorted(set(so.args.get('entity_ids') or []))))
    for role, recs in sorted(lifecycle_sounds.items()):
        event_name='entityHurt' if role=='hurt' else 'entityDie'
        lines.append(f'world.afterEvents.{event_name}.subscribe((ev) => {{')
        for sid, ids in recs:
            if event_name=='entityHurt': expr='ev.hurtEntity'
            else: expr='ev.deadEntity'
            lines.append(f'  if ({_js(ids)}.includes({expr}?.typeId)) playSoundAt({expr}?.dimension, {_js(sid)}, {expr}?.location, {{ volume: 1, pitch: 1 }});')
        lines.append('});')
        lines.append('')
        action_plan.append({'lowering':'entity_lifecycle_sound','role':role,'sounds':len(recs)})

    for o in program.operations:
        if o.op == 'capability' and o.status in {'convertible','emulated'} and o.id in {'effects.add','effects.remove','entity.teleport','entity.damage','entity.impulse','entity.command','entity.dynamic_state','world.dynamic_state','tick.schedule'}:
            helper_base=_safe_ident(f'{o.args.get("name", "cap")}_{o.id}')[:60]
            helper_idx=_unique_js_name(helper_base, declared_js_names)
            lines.extend(_action_helper(o, helper_idx))
            action_plan.append({'id':o.id,'status':o.status,'lowering':'exported_helper','source':o.source})
            emitted.add(o.id)
            continue
        elif o.op == 'sound_play' and o.status in {'convertible','emulated'}:
            helper_base=_safe_ident(f'{o.args.get("method", "play")}_{o.id}')[:60]
            helper_idx=_unique_js_name(helper_base, declared_js_names)
            lines.extend(_sound_helper(o, helper_idx))
            action_plan.append({'id':o.id,'status':o.status,'lowering':'sound_helper','sound_id':o.args.get('resolved_sound_id'),'source':o.source})
            emitted.add(o.id)
        elif o.op == 'scoreboard_op' and o.status in {'convertible','emulated'}:
            helper_base=_safe_ident(f'{o.args.get("method", "scoreboard")}_{o.id}')[:60]
            helper_idx=_unique_js_name(helper_base, declared_js_names)
            lines.extend(_scoreboard_helper(o, helper_idx))
            action_plan.append({'id':o.id,'status':o.status,'lowering':'scoreboard_helper','method':o.args.get('method'),'source':o.source})
            emitted.add(o.id)
        if o.op == 'keybind' and o.status == 'emulated' and o.args.get('button_hint'):
            button=o.args.get('button_hint')
            lines.append(f'bindButton(INPUT_BUTTONS.{button}, (player, state) => {{ /* Java keybind {o.id} */ }});')
            action_plan.append({'id':o.id,'status':o.status,'lowering':'input_subscription','source':o.source})
            emitted.add(o.id)
        elif o.op == 'keybind' and o.status == 'adaptable':
            lines.append(f'// ADAPTABLE KEYBIND: {o.id} — map the Java key to a Bedrock InputButton in nex_runtime/input.js')
            action_plan.append({'id':o.id,'status':o.status,'lowering':'manual_mapping','source':o.source})
        elif o.op == 'ui_screen':
            title=o.args.get('title_hint') or o.id
            lines.append(f'// UI reconstruction: {o.id}')
            show_idx=_unique_js_name(f'show_{len(emitted)}', declared_js_names)
            lines.append(f'export async function nex_{show_idx}(player) {{ return showMenu(player, {_js(title)}, "Reconstructed Java screen", []); }}')
            action_plan.append({'id':o.id,'status':o.status,'lowering':'server_ui_form','source':o.source})
            emitted.add(o.id)
        elif o.op == 'particle' and o.status in {'convertible','emulated'}:
            effect=o.args.get('particle_hint')
            particle_idx=_unique_js_name(f'particle_{len(emitted)}', declared_js_names)
            lines.append(f'export function nex_{particle_idx}(dimension, location, molangVariables) {{')
            lines.append(f'  return spawnParticle(dimension, {_js(effect or "")}, location, molangVariables);')
            lines.append('}')
            if not effect:
                lines.append(f'// ADAPTABLE PARTICLE: {o.id} — effect identifier was not recoverable from Java bytecode.')
            action_plan.append({'id':o.id,'status':o.status,'lowering':'particle_bridge','source':o.source})
            emitted.add(o.id)
        elif o.op == 'event':
            cb=o.args.get('callback') or {}; cb_name=cb.get('name')
            if o.id == 'server_tick' and cb_name:
                fn=_unique_js_name('nex_'+_safe_ident(cb_name), declared_js_names)
                lines.append(f'function {fn}() {{')
                for msg in actions.get(cb_name, []):
                    if msg is not None: lines.append(f'  world.sendMessage({_js(msg)});')
                for sound in program.operations:
                    if sound.op=='sound_play' and sound.args.get('bound_event_method')==cb_name and sound.args.get('resolved_sound_id'):
                        lines.append(f'  broadcastSound(world.getAllPlayers(), {_js(sound.args["resolved_sound_id"])}, {{ volume: 1, pitch: 1 }});')
                lines.append('}')
                lines.append(f'system.runInterval({fn}, 1);')
                lines.append('')
                action_plan.append({'id':o.id,'status':o.status,'lowering':'server_tick_interval','source':o.source})
                emitted.add(cb_name)
            elif o.source_loader in {'forge','neoforge'}:
                event_kind=o.args.get('event_kind')
                event_map={
                    'entity_hurt':('entityHurt','ev.hurtEntity'),
                    'entity_die':('entityDie','ev.deadEntity'),
                    'entity_spawn':('entitySpawn','ev.entity'),
                    'player_spawn':('playerSpawn','ev.player'),
                }
                mapped=event_map.get(event_kind)
                if mapped and cb_name:
                    event_name, subject=mapped
                    lines.append(f'world.afterEvents.{event_name}.subscribe((ev) => {{')
                    emitted_sounds=0
                    for sound in program.operations:
                        if sound.op=='sound_play' and sound.args.get('bound_event_method')==cb_name and sound.args.get('resolved_sound_id'):
                            lines.append(f'  try {{ playSoundAt({subject}?.dimension, {_js(sound.args["resolved_sound_id"])}, {subject}?.location, {{ volume: 1, pitch: 1 }}); }} catch (_) {{}}')
                            emitted_sounds += 1
                    for msg in actions.get(cb_name, []):
                        if msg is not None and event_kind=='player_spawn':
                            lines.append(f'  try {{ {subject}?.onScreenDisplay?.setActionBar?.({_js(msg)}); }} catch (_) {{}}')
                    lines.append('});')
                    lines.append('')
                    action_plan.append({'id':o.id,'status':o.status,'lowering':'forge_native_event_subscription','event_kind':event_kind,'callback':cb_name,'sounds_bound':emitted_sounds,'source':o.source})
                else:
                    lines.append(f'// Forge/NeoForge event adapter: {o.id} -> NEX event bridge (manual body reconstruction required)')
                    action_plan.append({'id':o.id,'status':o.status,'lowering':'event_bridge_review','event_kind':event_kind,'source':o.source})

    physics_bodies=[o for o in program.operations if o.op=='spawn_body' and o.status=='emulated']
    if physics_bodies:
        lines.append('const nexPhysicsBodies = [];')
        for idx,o in enumerate(physics_bodies):
            fragments=int(o.args.get('fragments', o.args.get('count', 1)))
            gravity=float(o.args.get('gravity',0.08)); restitution=float(o.args.get('restitution',0.25)); drag=float(o.args.get('drag',0.98))
            entity_type=o.args.get('entity_type') or o.args.get('entityType') or f'{program.mod_id}:nex_physics_fragment'
            lifetime=int(o.args.get('lifetime',0)); spread=float(o.args.get('spread',0.03)); upward=float(o.args.get('upward',0))
            body_idx=_unique_js_name(f'spawn_body_{idx}', declared_js_names)
            lines.append(f'export function nex_{body_idx}(dimension, location, overrides = {{}}) {{')
            lines.append(f'  const body = spawnPhysicsBody(dimension, location, {{ entityType: {_js(entity_type)}, fragments: {fragments}, gravity: {gravity}, restitution: {restitution}, drag: {drag}, lifetime: {lifetime}, spread: {spread}, upward: {upward}, ...overrides }});')
            lines.append('  if (body) nexPhysicsBodies.push(body);')
            lines.append('  return body;')
            lines.append('}')
        lines.append('startPhysics(world, () => nexPhysicsBodies);')
        lines.append('')
        action_plan.append({'id':'physics.runtime','status':'emulated','lowering':'physics_proxy_entities','source':'nex_runtime'})

    for o in program.operations:
        if o.op == 'capability' and o.status == 'incompatible':
            key=('incompatible',o.id)
            if key not in seen_cap_comments:
                lines.append(f'// INCOMPATIBLE: {o.id} ({o.args.get("reason", "no Bedrock equivalent")})')
                seen_cap_comments.add(key)
        elif o.op == 'capability' and o.status == 'adaptable':
            key=('adaptable',o.id)
            if key not in seen_cap_comments:
                lines.append(f'// ADAPTABLE: {o.id} -> {o.args.get("target", "Bedrock reconstruction required")}')
                seen_cap_comments.add(key)
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return {'path': str(path), 'action_plan': action_plan}
