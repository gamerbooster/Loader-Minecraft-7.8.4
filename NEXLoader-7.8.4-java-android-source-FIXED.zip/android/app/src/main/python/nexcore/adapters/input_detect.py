from __future__ import annotations
import json, zipfile
from pathlib import Path, PurePosixPath
from .loader import detect


def _zip_names(path):
    try:
        with zipfile.ZipFile(path) as z:
            return set(z.namelist())
    except Exception:
        return set()


def _normalized_zip_names(names):
    """Return logical archive names after stripping one harmless top-level folder.

    Java resource packs are frequently zipped as ``FolderName/pack.mcmeta`` plus
    ``FolderName/assets/...``. Bedrock/Java pack detection must inspect the pack
    root rather than the user's enclosing folder name. The physical member names
    are handled separately by resourcepack.compile_resource_pack().
    """
    clean = [str(n).replace('\\','/').lstrip('/') for n in names if str(n).strip()]
    files = [n for n in clean if not n.endswith('/')]
    if not files:
        return set()
    tops={n.split('/',1)[0] for n in files}
    if len(tops) == 1:
        top=next(iter(tops))
        # Do not strip a real pack root such as assets/, data/, mods/ or shaders/.
        # Only remove an arbitrary enclosing wrapper directory (e.g. MyPack/).
        preserved_roots = {'assets', 'data', 'mods', 'shaders', 'META-INF'}
        if top not in preserved_roots and any('/' in n for n in files) and all(n == top or n.startswith(top + '/') for n in files):
            logical=set()
            for n in files:
                logical.add(n[len(top)+1:] if n.startswith(top + '/') else n)
            return logical
    return set(files)


def detect_input_kind(path: str|Path, force_modpack: bool=False) -> str:
    """Classify an input before conversion so ZIP/MCpack/resource packs are not
    accidentally routed through the ModPack path."""
    p=Path(path)
    if force_modpack:
        return 'modpack'
    if p.is_dir():
        if (p/'pack.mcmeta').is_file() and (p/'assets').is_dir():
            return 'java_resource_pack'
        mf=p/'manifest.json'
        if mf.is_file():
            try:
                d=json.loads(mf.read_text(encoding='utf-8'))
                types={str(m.get('type')) for m in (d.get('modules') or []) if isinstance(m,dict)}
                if 'resources' in types and 'data' not in types:
                    return 'bedrock_resource_pack'
            except Exception:
                pass
        return 'modpack'
    ext=p.suffix.lower()
    if ext=='.jar': return 'java_mod'
    if ext=='.mrpack' or ext=='.modpack': return 'modpack'
    if ext=='.mcpack': return 'bedrock_resource_pack'
    if ext=='.mcaddon': return 'bedrock_addon'
    if ext=='.zip':
        physical_names=_zip_names(p)
        names=_normalized_zip_names(physical_names)
        if 'modrinth.index.json' in names or any(n.startswith('mods/') and n.lower().endswith('.jar') for n in names):
            return 'modpack'
        if ('shaders/' in names or 'shaders' in {n.split('/')[0] for n in names}) and any(PurePosixPath(n).suffix.lower() in {'.vsh','.fsh','.glsl','.vert','.frag','.geom','.comp','.tesc','.tese'} for n in names):
            return 'java_shaderpack'
        if 'pack.mcmeta' in names and any(n.startswith('assets/') for n in names):
            return 'java_resource_pack'
        # Some Java texture packs omit pack.mcmeta but still have the standard assets/textures tree.
        if any(n.startswith('assets/') and '/textures/' in n for n in names):
            return 'java_resource_pack'
        if 'manifest.json' in names:
            try:
                with zipfile.ZipFile(p) as z:
                    # The logical name is known; recover its physical member by comparing
                    # against the normalized archive set and a single optional wrapper.
                    physical=z.namelist()
                    top_files=[str(x).replace('\\','/').lstrip('/') for x in physical if str(x) and not str(x).endswith('/')]
                    tops={x.split('/',1)[0] for x in top_files}
                    if len(tops)==1 and all(x==next(iter(tops)) or x.startswith(next(iter(tops))+'/') for x in top_files):
                        t=next(iter(tops)); manifest_member= t+'/manifest.json' if t+'/manifest.json' in physical else 'manifest.json'
                    else:
                        manifest_member='manifest.json'
                    d=json.loads(z.read(manifest_member).decode('utf-8'))
                types={str(m.get('type')) for m in (d.get('modules') or []) if isinstance(m,dict)}
                if 'resources' in types and 'data' not in types:
                    return 'bedrock_resource_pack'
                if 'resources' in types and 'data' in types:
                    return 'bedrock_addon'
            except Exception:
                pass
        # A ZIP containing a loader manifest is still a standalone Java mod.
        if {'fabric.mod.json','quilt.mod.json'} & names or 'META-INF/mods.toml' in names or 'META-INF/neoforge.mods.toml' in names:
            return 'java_mod'
        return 'modpack'
    return 'java_mod'
