from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path, PurePosixPath


SHADER_EXTENSIONS = {'.vsh', '.fsh', '.glsl', '.vert', '.frag', '.geom', '.comp', '.tesc', '.tese'}

# Features with a documented Bedrock/Vibrant Visuals representation.
NATIVE_FEATURES = {
    'shadows': ('shadow', 'shadowmap', 'shadow_casting', 'shadow_culling'),
    'water': ('water', 'refraction', 'reflection', 'caustic'),
    'atmosphere': ('sky', 'atmosphere', 'mie', 'rayleigh', 'sun_glare'),
    'volumetric_fog': ('volumetric_light', 'volumetric', 'light_shafts', 'godray', 'fog'),
    'color_grading': ('tone_map', 'tonemap', 'color_grading', 'color_conversion', 'saturation', 'contrast'),
    'pbr_materials': ('material', 'roughness', 'metalness', 'metallic', 'emissive', 'normalmap', 'normal_map'),
}

APPROXIMATE_FEATURES = {
    'ambient_occlusion': ('ao', 'ambient_occlusion', 'ssao'),
    'bloom': ('bloom', 'glow', 'brightpass'),
    'clouds': ('cloud', 'clouds'),
}

UNEXPOSED_FEATURES = {
    'taa': ('taa', 'temporal_antialias', 'temporal_aa'),
    'depth_of_field': ('dof', 'depth_of_field', 'bokeh'),
    'motion_blur': ('motion_blur', 'velocity_buffer'),
    'chromatic_aberration': ('chromatic_aberration', 'chroma_aber', 'aberration'),
    'auto_exposure': ('auto_exposure', 'auto-exposure', 'exposure'),
}

PROFILE_FEATURE_ALIASES = {
    'shadows': {'SHADOW_CASTING'},
    'water': {'REFRACTION', 'SUN_REFLECTION', 'VANILLA_WATER'},
    'clouds': {'V_CLOUDS', 'CLOUD_REFLECTION'},
    'bloom': {'BLOOM'},
    'ambient_occlusion': {'AO'},
    'depth_of_field': {'DOF'},
    'motion_blur': {'MOTION_BLUR'},
    'chromatic_aberration': {'CHROMA_ABER'},
    'volumetric_fog': {'VOL_LIGHT'},
    'pbr_materials': {'MATERIAL_GLOSS'},
}


def _safe_rel(name: str) -> str:
    return str(name).replace('\\', '/').lstrip('/')


def _properties_lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]


def _find_profile_options(properties: list[str]) -> dict[str, dict[str, object]]:
    profiles: dict[str, dict[str, object]] = {}
    for line in properties:
        m = re.match(r'profile\.([A-Za-z0-9_.-]+)\s*=\s*(.*)$', line)
        if not m:
            continue
        name = m.group(1)
        rhs = m.group(2)
        enabled: set[str] = set()
        disabled: set[str] = set()
        values: dict[str, str] = {}
        for token in rhs.split():
            if token.startswith('!') and len(token) > 1:
                disabled.add(token[1:].split('=', 1)[0].upper())
            elif '=' in token:
                key, value = token.split('=', 1)
                values[key.upper()] = value
                enabled.add(key.upper())
            elif re.match(r'^[A-Za-z][A-Za-z0-9_]*$', token):
                enabled.add(token.upper())
        profiles[name] = {
            'enabled': sorted(enabled),
            'disabled': sorted(disabled),
            'values': dict(sorted(values.items())),
            'token_count': len(rhs.split()),
        }
    return profiles


def _scan_source_text(text_by_path: dict[str, str]) -> tuple[dict[str, bool], dict[str, int], list[str], set[str]]:
    joined_names = '\n'.join(text_by_path.keys()).lower()
    joined_text = '\n'.join(text_by_path.values()).lower()
    features: dict[str, bool] = {}
    scores: dict[str, int] = {}
    evidence: list[str] = []

    for feature, terms in NATIVE_FEATURES.items():
        hits = sum(joined_names.count(term) + joined_text.count(term) for term in terms)
        scores[feature] = hits
        features[feature] = hits > 0
        if hits:
            evidence.append(f'{feature}:{hits}')

    for feature, terms in APPROXIMATE_FEATURES.items():
        hits = sum(joined_names.count(term) + joined_text.count(term) for term in terms)
        scores[feature] = hits
        features[feature] = hits > 0
        if hits:
            evidence.append(f'{feature}:{hits}')

    for feature, terms in UNEXPOSED_FEATURES.items():
        hits = sum(joined_names.count(term) + joined_text.count(term) for term in terms)
        scores[feature] = hits
        features[feature] = hits > 0
        if hits:
            evidence.append(f'{feature}:{hits}')

    passes: set[str] = set()
    for path in text_by_path:
        stem = PurePosixPath(path).stem.lower()
        if stem.startswith('gbuffers_'):
            passes.add(stem)
        elif stem in {'shadow', 'shadowcomp', 'prepare', 'deferred', 'composite', 'composite1', 'composite2', 'final'}:
            passes.add(stem)
    return features, scores, sorted(evidence), passes


def _apply_profile_features(features: dict[str, bool], scores: dict[str, int], evidence: list[str], profiles: dict[str, dict[str, object]]) -> None:
    """Use shader-pack profile declarations as a second detection channel.

    This matters for packs where an effect is configured in shaders.properties
    but the GLSL source is heavily macro-generated or uses custom filenames.
    """
    for profile_name, profile in profiles.items():
        enabled = set(profile.get('enabled', []))
        disabled = set(profile.get('disabled', []))
        for feature, aliases in PROFILE_FEATURE_ALIASES.items():
            hits = len(enabled & aliases)
            if hits:
                features[feature] = True
                scores[feature] = max(scores.get(feature, 0), hits)
                evidence.append(f'profile.{profile_name}:{feature}:{hits}')
        # An explicit disabled-only profile must not erase the fact that another
        # profile may enable the feature. It is kept in profile data for audit.
        _ = disabled


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _rgb_triplet(r: float, g: float, b: float) -> list[int]:
    """Return an [r, g, b] list of ints in 0-255.

    Bedrock Vibrant Visuals documents colors as "an array of three numerical
    values in the range of 0-255, or a six-digit hexadecimal string". Values that
    look normalized (all within 0..1) are scaled up first.
    """
    vals = [r, g, b]
    if all(0.0 <= v <= 1.0 for v in vals):
        vals = [v * 255.0 for v in vals]
    return [int(round(_clamp(v, 0.0, 255.0))) for v in vals]


def _extract_rgb(text: str, prefix: str) -> list[int] | None:
    """Find an RGB color declared for `prefix` in shader source.

    Supports `PREFIX_R = x; PREFIX_G = y; PREFIX_B = z` (also `#define PREFIX_R x`)
    and `PREFIX = vec3(x, y, z)`. Detection is heuristic and only used to tint the
    documented baseline palette; nothing is guessed when no declaration is found.
    """
    num = r'([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)'
    split = re.compile(
        rf'{re.escape(prefix)}[_ ]?R\s*=?\s*{num}.*?'
        rf'{re.escape(prefix)}[_ ]?G\s*=?\s*{num}.*?'
        rf'{re.escape(prefix)}[_ ]?B\s*=?\s*{num}',
        re.I | re.S,
    )
    vec = re.compile(
        rf'{re.escape(prefix)}\s*=\s*vec3\(\s*{num}\s*,\s*{num}\s*,\s*{num}\s*\)',
        re.I,
    )
    for pat in (vec, split):
        m = pat.search(text)
        if m:
            try:
                return _rgb_triplet(float(m.group(1)), float(m.group(2)), float(m.group(3)))
            except ValueError:
                continue
    return None


def _kf_const(value):
    """Constant time-of-day keyframes: {"0.0": v, "1.0": v}.

    The documented atmospherics schema types every field as TimeKeyframes (an
    object keyed by time_of_day in 0..1), and the official examples always use
    that form. A bare float there is what produced "Expected keyframes".
    """
    return {'0.0': value, '1.0': value}


# Time-of-day keyframes taken from Microsoft's documented example
# (learn.microsoft.com .../vibrantvisuals/atmosphericscustomization). Time 0.0 is
# midday, 0.25 dusk, 0.5 midnight, 0.75 dawn.
_BASE_ATMOSPHERE = {
    'horizon_blend_stops': {
        'min': {'0.0': 0.0, '0.25': 0.0, '0.34': 0.11, '0.6': 0.027, '0.75': 0.0},
        'start': {'0.0': 0.25, '0.25': 0.213, '0.34': 0.401, '0.6': 0.23, '0.75': 0.199},
        'mie_start': {'0.0': 0.5, '0.25': 0.5, '0.34': 0.501, '0.6': 0.167, '0.75': 0.55},
        'max': {'0.0': 0.25, '0.25': 0.0, '0.34': 0.467, '0.6': 0.2, '0.75': 0.214},
    },
    'rayleigh_strength': {'0.0': 1.026, '0.25': 0.162, '0.3': 0.162, '0.325': 0.162, '0.6': 0.5, '0.707': 0.198, '0.75': 0.125},
    'sun_mie_strength': {'0.0': 1.0, '0.25': 3.0, '0.3': 3.0, '0.325': 1.0, '0.6': 1.0, '0.75': 1.0},
    'moon_mie_strength': {'0.0': 0.0, '0.25': 0.0, '0.3': 0.0, '0.325': 1.0, '0.6': 1.0, '0.707': 0.0, '0.75': 0.0},
    'sun_glare_shape': {'0.0': 15.9, '0.25': 15.9, '0.3': 15.9, '0.325': 15.0, '0.6': 4.0, '0.75': 4.0},
}
_DEFAULT_SKY = {
    'zenith': {'day': [0, 125, 164], 'dusk': [11, 55, 97], 'night': [7, 10, 36], 'dawn': [50, 88, 170]},
    'horizon': {'day': [255, 255, 254], 'dusk': [255, 85, 85], 'night': [66, 98, 238], 'dawn': [238, 144, 124]},
}


def _sky_color_keyframes(palette: dict[str, list[int]]) -> dict[str, list[int]]:
    return {
        '0.0': list(palette['day']),
        '0.25': list(palette['dusk']),
        '0.5': list(palette['night']),
        '0.75': list(palette['dawn']),
        '1.0': list(palette['day']),
    }


def _default_visuals(features: dict[str, bool], text: str) -> dict[str, object]:
    # Everything below stays inside the documented Bedrock ranges. It is a
    # semantic recreation, not a source-level GLSL translation.

    # Sky colors: start from Microsoft's documented palette and override with
    # colors the Java pack declares (MakeUp-style *_COLOR_R/G/B macros). Which
    # ones were actually found is recorded for the report.
    zenith = {k: list(v) for k, v in _DEFAULT_SKY['zenith'].items()}
    horizon = {k: list(v) for k, v in _DEFAULT_SKY['horizon'].items()}
    color_sources: dict[str, str] = {}
    for kind, palette in (('ZENITH', zenith), ('HORIZON', horizon)):
        for macro, slots in (('DAY', ('day',)), ('SUNSET', ('dusk', 'dawn')), ('NIGHT', ('night',))):
            found = _extract_rgb(text, f'{kind}_{macro}_COLOR')
            if found:
                for slot in slots:
                    palette[slot] = found
                color_sources[f'{kind.lower()}_{macro.lower()}'] = 'java_pack'
    atmosphere: dict[str, object] = {k: json.loads(json.dumps(v)) for k, v in _BASE_ATMOSPHERE.items()}
    atmosphere['sky_zenith_color'] = _sky_color_keyframes(zenith)
    atmosphere['sky_horizon_color'] = _sky_color_keyframes(horizon)

    # lighting/global.json follows the documented 1.26.0 schema: `flash` is a
    # sibling of `orbital`, sun/moon/ambient colors are RGB triplets or 6-digit
    # hex. Sun illuminance uses the documented dawn/dusk keyframe table because
    # a constant ~100000 lux is "far too bright" outside midday.
    lighting = {
        'directional_lights': {
            'orbital': {
                'sun': {
                    'illuminance': {
                        '0.0': 109880.0,
                        '0.25': 20000.0,
                        '0.35': 400.0,
                        '0.5': 1.0,
                        '0.65': 400.0,
                        '0.75': 20000.0,
                        '1.0': 109880.0,
                    },
                    'color': [255.0, 255.0, 255.0],
                },
                'moon': {'illuminance': 0.27, 'color': [203.0, 215.0, 255.0]},
                'orbital_offset_degrees': 0.0,
            }
        },
        'emissive': {'desaturation': 0.10},
        'ambient': {'illuminance': 0.02, 'color': '#ffffff'},
        'sky': {'intensity': 1.0},
    }

    grading = {
        'midtones': {
            'contrast': [1.08, 1.08, 1.08],
            'gain': [1.0, 1.0, 1.0],
            'gamma': [2.2, 2.2, 2.2],
            'offset': [0.0, 0.0, 0.0],
            'saturation': [1.05 if features.get('color_grading') else 1.0] * 3,
        },
        'shadows': {
            'enabled': True,
            'shadowsMax': 0.45,
            'contrast': [1.04, 1.04, 1.04],
            'gain': [0.96, 0.97, 1.0],
            'gamma': [2.2, 2.2, 2.2],
            'offset': [0.0, 0.0, 0.0],
            'saturation': [1.0, 1.0, 1.02],
        },
        'highlights': {
            'enabled': True,
            'highlightsMin': 1.75,
            'contrast': [1.05, 1.05, 1.05],
            'gain': [1.03, 1.03, 1.03],
            'gamma': [2.2, 2.2, 2.2],
            'offset': [0.0, 0.0, 0.0],
            'saturation': [1.04, 1.04, 1.04],
        },
        'temperature': {
            'enabled': bool(re.search(r'(temperature|warm|cold|sunset)', text, re.I)),
            'temperature': 6500,
            'type': 'color_temperature',
        },
    }

    # Keys here are exactly those of the documented water schema (v4); there is
    # no `sampleWidth` in it.
    water = {
        'particle_concentrations': {
            'chlorophyll': 0.4 if features.get('water') else 0.0,
            'suspended_sediment': 0.6 if features.get('water') else 0.15,
            'cdom': 0.7 if features.get('water') else 0.2,
        },
        'waves': {
            'enabled': bool(features.get('water')),
            'depth': 1.0,
            'direction_increment': 80.0,
            'frequency': 1.0,
            'frequency_scaling': 1.2,
            'mix': 0.2,
            'octaves': 24,
            'pull': 0.38,
            'shape': 1.5,
            'speed': 2.0,
            'speed_scaling': 1.03,
        },
        'caustics': {
            'enabled': bool(features.get('water')),
            'frame_length': 0.05,
            'power': 2.0,
            'scale': 0.5,
        },
        'biome_water_color_contribution': 0.25 if features.get('water') else 0.15,
    }
    return {
        'lighting': lighting,
        'atmosphere': atmosphere,
        'grading': grading,
        'water': water,
        'color_sources': color_sources,
    }


def _native_support(features: dict[str, bool]) -> dict[str, str]:
    support: dict[str, str] = {}
    for feature in NATIVE_FEATURES:
        if features.get(feature):
            support[feature] = 'native'
    for feature in APPROXIMATE_FEATURES:
        if features.get(feature):
            support[feature] = 'approximate'
    for feature in UNEXPOSED_FEATURES:
        if features.get(feature):
            support[feature] = 'not_exposed'
    return support


def translate_shaderpack(source_files: dict[str, bytes], mod_id: str, pack_name: str) -> dict[str, object]:
    """Analyze a Java shaderpack and produce a Bedrock-native VV profile.

    Java GLSL is never executed by this function. The translator extracts render
    intent from shader pass names, GLSL text and option profiles, then emits data
    for the documented Bedrock Vibrant Visuals/PBR pipeline.
    """
    text_by_path: dict[str, str] = {}
    profile_texts: list[str] = []
    source_hashes: dict[str, str] = {}
    for name, raw in source_files.items():
        safe_name = _safe_rel(name)
        source_hashes[safe_name] = hashlib.sha256(raw).hexdigest()
        ext = PurePosixPath(name).suffix.lower()
        if ext in SHADER_EXTENSIONS or ext in {'.properties', '.json', '.txt', '.lang'}:
            text = raw.decode('utf-8', errors='replace')
            text_by_path[safe_name] = text
            if PurePosixPath(name).name.lower() in {'shaders.properties', 'shader.properties', 'optionsshaders.txt'}:
                profile_texts.extend(_properties_lines(text))

    features, scores, evidence, passes = _scan_source_text(text_by_path)
    profiles = _find_profile_options(profile_texts)
    _apply_profile_features(features, scores, evidence, profiles)
    evidence = sorted(set(evidence))

    profile_feature_summary: dict[str, list[str]] = {}
    for profile_name, profile in profiles.items():
        enabled = set(profile.get('enabled', []))
        summary: list[str] = []
        for feature, aliases in PROFILE_FEATURE_ALIASES.items():
            if enabled & aliases:
                summary.append(feature)
        profile_feature_summary[profile_name] = sorted(summary)

    all_text = '\n'.join(text_by_path.values())
    visuals = _default_visuals(features, all_text)
    support = _native_support(features)
    quality = 'native_profile' if not any(v in support.values() for v in ('approximate', 'not_exposed')) else 'hybrid_semantic_profile'

    limitations = []
    for feature in ('taa', 'depth_of_field', 'motion_blur', 'chromatic_aberration', 'auto_exposure'):
        if features.get(feature):
            limitations.append(feature)
    if features.get('bloom'):
        limitations.append('bloom')
    if features.get('clouds'):
        limitations.append('clouds:approximate')
    if features.get('ambient_occlusion'):
        limitations.append('ambient_occlusion:approximate')

    return {
        'schema_target': 'Vibrant Visuals',
        'schema_version': '1.26.0',
        'pack_name': pack_name,
        'mod_id': mod_id,
        'conversion_method': 'semantic_reimplementation',
        'quality': quality,
        'features': {k: bool(v) for k, v in sorted(features.items())},
        'feature_support': support,
        'feature_scores': dict(sorted(scores.items())),
        'evidence': evidence,
        'render_passes': sorted(passes),
        'profiles': profiles,
        'profile_feature_summary': profile_feature_summary,
        'limitations': sorted(set(limitations)),
        'source_file_count': len(source_files),
        'source_sha256': dict(sorted(source_hashes.items())),
        'original_runtime': 'Java OpenGL/Iris/OptiFine shader pipeline',
        'bedrock_runtime': 'Render Dragon / Vibrant Visuals PBR pipeline',
        'attribution_note': 'No Java GLSL source is activated. The generated profile is a Bedrock-native reimplementation of detected visual intent.',
        'lighting': visuals['lighting'],
        'atmosphere': visuals['atmosphere'],
        'grading': visuals['grading'],
        'water': visuals['water'],
        'atmosphere_color_sources': visuals['color_sources'],
        'atmosphere_baseline': 'Microsoft documented Vibrant Visuals example (time-of-day keyframes); sky colors overridden only where the Java pack declares them',
    }


# ---------------------------------------------------------------------------
# Strict validation against the documented Vibrant Visuals schemas
# (learn.microsoft.com .../vibrantvisuals/* and bedrock.dev/docs/stable, 1.26.50).
# The goal is to fail closed in the generator instead of discovering schema
# mistakes inside Minecraft ("Expected keyframes", "missing required field", ...).
# ---------------------------------------------------------------------------

_VERSION_RE = re.compile(r'^\d+\.\d+\.\d+$')
_IDENT_RE = re.compile(r'^[a-z0-9_.-]+:[a-z0-9_./-]+$')
_HEX6_RE = re.compile(r'^#[0-9a-fA-F]{6}$')
_HEX8_RE = re.compile(r'^#[0-9a-fA-F]{8}$')


def _is_num(v: object) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _is_rgb3(v: object) -> bool:
    return isinstance(v, list) and len(v) == 3 and all(_is_num(x) and 0 <= x <= 255 for x in v)


def _is_color(v: object) -> bool:
    return _is_rgb3(v) or (isinstance(v, str) and bool(_HEX6_RE.match(v)))


def _is_keyframes(v: object) -> bool:
    if not isinstance(v, dict) or not v:
        return False
    for k in v:
        try:
            t = float(k)
        except (TypeError, ValueError):
            return False
        if not 0.0 <= t <= 1.0:
            return False
    return True


def _check_value(path: str, v: object, kind: str, lo: float | None, hi: float | None,
                 issues: list[str], *, allow_plain: bool, allow_keyframes: bool = True) -> None:
    """Validate a float/color that the schema marks as optkeyframe."""
    def one(x: object, where: str) -> None:
        if kind == 'color':
            if not _is_color(x):
                issues.append(f'{where}: color must be [r,g,b] (0-255) or a 6-digit hex string, got {x!r}')
        else:
            if not _is_num(x):
                issues.append(f'{where}: expected a number, got {x!r}')
            elif (lo is not None and x < lo) or (hi is not None and x > hi):
                issues.append(f'{where}: {x} outside documented range [{lo}, {hi}]')

    if _is_keyframes(v):
        if not allow_keyframes:
            issues.append(f'{path}: keyframes are not allowed here')
            return
        for k, x in v.items():
            one(x, f'{path}[{k}]')
        return
    if isinstance(v, dict):
        issues.append(f'{path}: keyframe keys must be numbers in 0..1')
        return
    if not allow_plain:
        issues.append(f'{path}: Expected keyframes ({{"0.0": value, "1.0": value}}), got {v!r}')
        return
    one(v, path)


def _check_keys(path: str, obj: object, allowed: set[str], issues: list[str], required: set[str] | None = None) -> bool:
    if not isinstance(obj, dict):
        issues.append(f'{path}: expected an object')
        return False
    for k in obj:
        if k not in allowed:
            issues.append(f'{path}: unknown field "{k}" (not in the documented schema)')
    for k in (required or set()):
        if k not in obj:
            issues.append(f'{path}: missing required field "{k}"')
    return True


def _check_description(path: str, settings: dict, issues: list[str], required: bool = True) -> None:
    desc = settings.get('description')
    if desc is None:
        if required:
            issues.append(f'{path}.description: missing required field')
        return
    if _check_keys(f'{path}.description', desc, {'identifier'}, issues, {'identifier'}):
        ident = desc.get('identifier')
        if not (isinstance(ident, str) and _IDENT_RE.match(ident)):
            issues.append(f'{path}.description.identifier: must be namespaced ("ns:name"), got {ident!r}')


def _check_vec3(path: str, v: object, lo: float, hi: float, issues: list[str]) -> None:
    if not (isinstance(v, list) and len(v) == 3 and all(_is_num(x) and lo <= x <= hi for x in v)):
        issues.append(f'{path}: expected [x, y, z] with values in [{lo}, {hi}], got {v!r}')


def vv_issues(rel: str, payload: object) -> list[str]:
    """Return every schema problem found in one Vibrant Visuals JSON file."""
    issues: list[str] = []
    if not isinstance(payload, dict):
        return [f'{rel}: root must be an object']
    fv = payload.get('format_version')
    if not (isinstance(fv, str) and _VERSION_RE.match(fv)):
        issues.append(f'{rel}: format_version must be a 3-part string, got {fv!r}')

    if rel == 'lighting/global.json' or rel.startswith('lighting/'):
        _check_keys(rel, payload, {'format_version', 'minecraft:lighting_settings'}, issues, {'minecraft:lighting_settings'})
        st = payload.get('minecraft:lighting_settings')
        if not _check_keys('lighting', st, {'description', 'directional_lights', 'emissive', 'ambient', 'sky'}, issues):
            return issues
        _check_description('lighting', st, issues)
        dl = st.get('directional_lights')
        if dl is not None and _check_keys('directional_lights', dl, {'orbital', 'flash'}, issues):
            orb = dl.get('orbital')
            if orb is not None and _check_keys('orbital', orb, {'sun', 'moon', 'orbital_offset_degrees'}, issues):
                for body in ('sun', 'moon'):
                    b = orb.get(body)
                    if b is None:
                        continue
                    if _check_keys(f'orbital.{body}', b, {'illuminance', 'color'}, issues):
                        if 'illuminance' in b:
                            _check_value(f'orbital.{body}.illuminance', b['illuminance'], 'num', 0.0, None, issues, allow_plain=True)
                        if 'color' in b:
                            _check_value(f'orbital.{body}.color', b['color'], 'color', None, None, issues, allow_plain=True)
                if 'orbital_offset_degrees' in orb:
                    _check_value('orbital.orbital_offset_degrees', orb['orbital_offset_degrees'], 'num', None, None, issues, allow_plain=True)
            fl = dl.get('flash')
            if fl is not None and _check_keys('flash', fl, {'illuminance', 'color'}, issues):
                if 'illuminance' in fl:
                    _check_value('flash.illuminance', fl['illuminance'], 'num', 0.0, None, issues, allow_plain=True, allow_keyframes=False)
                if 'color' in fl:
                    _check_value('flash.color', fl['color'], 'color', None, None, issues, allow_plain=True, allow_keyframes=False)
        em = st.get('emissive')
        if em is not None and _check_keys('emissive', em, {'desaturation'}, issues):
            if 'desaturation' in em:
                _check_value('emissive.desaturation', em['desaturation'], 'num', 0.0, 1.0, issues, allow_plain=True, allow_keyframes=False)
        amb = st.get('ambient')
        if amb is not None and _check_keys('ambient', amb, {'illuminance', 'color'}, issues, {'illuminance', 'color'}):
            if 'illuminance' in amb:
                _check_value('ambient.illuminance', amb['illuminance'], 'num', 0.0, 5.0, issues, allow_plain=True)
            if 'color' in amb:
                _check_value('ambient.color', amb['color'], 'color', None, None, issues, allow_plain=True)
        sky = st.get('sky')
        if sky is not None and _check_keys('sky', sky, {'intensity'}, issues):
            if 'intensity' in sky:
                _check_value('sky.intensity', sky['intensity'], 'num', 0.1, 1.0, issues, allow_plain=True)

    elif rel.startswith('atmospherics/'):
        _check_keys(rel, payload, {'format_version', 'minecraft:atmosphere_settings'}, issues, {'minecraft:atmosphere_settings'})
        st = payload.get('minecraft:atmosphere_settings')
        scalar_fields = {'rayleigh_strength', 'sun_mie_strength', 'moon_mie_strength', 'sun_glare_shape'}
        color_fields = {'sky_zenith_color', 'sky_horizon_color'}
        if not _check_keys('atmosphere', st, {'description', 'horizon_blend_stops'} | scalar_fields | color_fields, issues):
            return issues
        _check_description('atmosphere', st, issues)
        hbs = st.get('horizon_blend_stops')
        if hbs is not None and _check_keys('horizon_blend_stops', hbs, {'min', 'start', 'mie_start', 'max'}, issues):
            for k, v in hbs.items():
                _check_value(f'horizon_blend_stops.{k}', v, 'num', None, None, issues, allow_plain=False)
        for k in scalar_fields:
            if k in st:
                _check_value(k, st[k], 'num', 0.0, None, issues, allow_plain=False)
        for k in color_fields:
            if k in st:
                _check_value(k, st[k], 'color', None, None, issues, allow_plain=False)

    elif rel.startswith('color_grading/'):
        _check_keys(rel, payload, {'format_version', 'minecraft:color_grading_settings'}, issues, {'minecraft:color_grading_settings'})
        st = payload.get('minecraft:color_grading_settings')
        if not _check_keys('color_grading_settings', st, {'description', 'color_grading', 'tone_mapping'}, issues):
            return issues
        _check_description('color_grading_settings', st, issues, required=False)
        cg = st.get('color_grading')
        common = {'contrast': (0.0, 4.0), 'gain': (0.0, 10.0), 'gamma': (0.0, 4.0), 'offset': (0.0, 4.0), 'saturation': (0.0, 10.0)}
        if cg is not None and _check_keys('color_grading', cg, {'midtones', 'shadows', 'highlights', 'temperature'}, issues):
            for band, extra in (('midtones', {}), ('shadows', {'enabled': bool, 'shadowsMax': (0.1, 1.0)}), ('highlights', {'enabled': bool, 'highlightsMin': (1.0, 4.0)})):
                b = cg.get(band)
                if b is None:
                    continue
                if _check_keys(f'color_grading.{band}', b, set(common) | set(extra), issues):
                    for k, (lo, hi) in common.items():
                        if k in b:
                            _check_vec3(f'color_grading.{band}.{k}', b[k], lo, hi, issues)
                    for k, spec in extra.items():
                        if k not in b:
                            continue
                        if spec is bool:
                            if not isinstance(b[k], bool):
                                issues.append(f'color_grading.{band}.{k}: expected boolean')
                        else:
                            _check_value(f'color_grading.{band}.{k}', b[k], 'num', spec[0], spec[1], issues, allow_plain=True, allow_keyframes=False)
            t = cg.get('temperature')
            if t is not None and _check_keys('color_grading.temperature', t, {'enabled', 'temperature', 'type'}, issues):
                if 'enabled' in t and not isinstance(t['enabled'], bool):
                    issues.append('color_grading.temperature.enabled: expected boolean')
                if 'temperature' in t:
                    _check_value('color_grading.temperature.temperature', t['temperature'], 'num', 1000.0, 15000.0, issues, allow_plain=True, allow_keyframes=False)
                if 'type' in t and t['type'] not in {'white_balance', 'color_temperature'}:
                    issues.append(f'color_grading.temperature.type: invalid {t["type"]!r}')
        tm = st.get('tone_mapping')
        if tm is not None and _check_keys('tone_mapping', tm, {'operator'}, issues):
            if tm.get('operator') not in {'aces', 'hable', 'reinhard', 'reinhard_luma', 'reinhard_luminance', 'generic'}:
                issues.append(f'tone_mapping.operator: invalid {tm.get("operator")!r}')

    elif rel.startswith('water/'):
        _check_keys(rel, payload, {'format_version', 'minecraft:water_settings'}, issues, {'minecraft:water_settings'})
        st = payload.get('minecraft:water_settings')
        if not _check_keys('water_settings', st, {'description', 'particle_concentrations', 'waves', 'caustics', 'biome_water_color_contribution'}, issues, {'description'}):
            return issues
        _check_description('water_settings', st, issues)
        pc = st.get('particle_concentrations')
        if pc is not None and _check_keys('particle_concentrations', pc, {'chlorophyll', 'cdom', 'suspended_sediment'}, issues):
            for k, hi in (('chlorophyll', 10.0), ('cdom', 15.0), ('suspended_sediment', 300.0)):
                if k in pc:
                    _check_value(f'particle_concentrations.{k}', pc[k], 'num', 0.0, hi, issues, allow_plain=True, allow_keyframes=False)
        waves = st.get('waves')
        wspec = {'depth': (0.0, 3.0), 'direction_increment': (0.0, 360.0), 'frequency': (0.01, 3.0), 'frequency_scaling': (0.0, 2.0),
                 'mix': (0.0, 1.0), 'octaves': (1, 30), 'pull': (-1.0, 1.0), 'shape': (1.0, 10.0), 'speed': (0.01, 10.0), 'speed_scaling': (0.0, 2.0)}
        if waves is not None and _check_keys('waves', waves, set(wspec) | {'enabled'}, issues):
            if 'enabled' in waves and not isinstance(waves['enabled'], bool):
                issues.append('waves.enabled: expected boolean')
            for k, (lo, hi) in wspec.items():
                if k in waves:
                    _check_value(f'waves.{k}', waves[k], 'num', lo, hi, issues, allow_plain=True, allow_keyframes=False)
        ca = st.get('caustics')
        cspec = {'frame_length': (0.01, 5.0), 'power': (1.0, 6.0), 'scale': (0.1, 5.0)}
        if ca is not None and _check_keys('caustics', ca, set(cspec) | {'enabled', 'texture'}, issues):
            if 'enabled' in ca and not isinstance(ca['enabled'], bool):
                issues.append('caustics.enabled: expected boolean')
            if 'texture' in ca and not isinstance(ca['texture'], str):
                issues.append('caustics.texture: expected string')
            for k, (lo, hi) in cspec.items():
                if k in ca:
                    _check_value(f'caustics.{k}', ca[k], 'num', lo, hi, issues, allow_plain=True, allow_keyframes=False)
        if 'biome_water_color_contribution' in st:
            _check_value('biome_water_color_contribution', st['biome_water_color_contribution'], 'num', 0.0, 1.0, issues, allow_plain=True, allow_keyframes=False)

    elif rel.startswith('shadows/'):
        _check_keys(rel, payload, {'format_version', 'minecraft:shadow_settings'}, issues, {'minecraft:shadow_settings'})
        st = payload.get('minecraft:shadow_settings')
        if _check_keys('shadow_settings', st, {'shadow_style', 'texel_size'}, issues):
            if st.get('shadow_style') not in {'blocky_shadows', 'soft_shadows'}:
                issues.append(f'shadow_settings.shadow_style: must be blocky_shadows or soft_shadows, got {st.get("shadow_style")!r}')
            if 'texel_size' in st and not (isinstance(st['texel_size'], int) and not isinstance(st['texel_size'], bool) and st['texel_size'] > 0):
                issues.append('shadow_settings.texel_size: must be a positive integer')

    elif rel.startswith('pbr/'):
        _check_keys(rel, payload, {'format_version', 'minecraft:pbr_fallback_settings'}, issues, {'minecraft:pbr_fallback_settings'})
        st = payload.get('minecraft:pbr_fallback_settings')
        if _check_keys('pbr_fallback_settings', st, {'blocks', 'actors', 'particles', 'items'}, issues):
            for grp, body in st.items():
                if _check_keys(f'pbr.{grp}', body, {'global_metalness_emissive_roughness_subsurface'}, issues):
                    v = body.get('global_metalness_emissive_roughness_subsurface')
                    ok = (isinstance(v, list) and len(v) == 4 and all(_is_num(x) and 0 <= x <= 255 for x in v)) or \
                         (isinstance(v, str) and bool(_HEX6_RE.match(v) or _HEX8_RE.match(v)))
                    if not ok:
                        issues.append(f'pbr.{grp}.global_metalness_emissive_roughness_subsurface: expected [m,e,r,s] (0-255) or hex, got {v!r}')
    else:
        issues.append(f'{rel}: not a recognized Vibrant Visuals file')
    return issues


VV_FILES = (
    'lighting/global.json',
    'atmospherics/atmospherics.json',
    'color_grading/color_grading.json',
    'water/water.json',
    'shadows/global.json',
    'pbr/global.json',
)


def _validate_vv_payload(rel: str, payload: dict[str, object]) -> None:
    """Fail closed on schema mistakes before they ever reach Minecraft."""
    issues = vv_issues(rel, payload)
    if issues:
        raise ValueError('Vibrant Visuals schema violation in ' + rel + ': ' + '; '.join(issues))


def validate_vv_pack_dir(root: Path) -> list[str]:
    """Validate every Vibrant Visuals JSON present in a resource-pack folder."""
    problems: list[str] = []
    root = Path(root)
    for rel in VV_FILES:
        f = root / rel
        if not f.is_file():
            continue
        try:
            payload = json.loads(f.read_text(encoding='utf-8'))
        except (OSError, ValueError) as exc:
            problems.append(f'{rel}: invalid JSON ({exc})')
            continue
        problems.extend(vv_issues(rel, payload))
    return problems


def emit_vibrant_visuals_profile(root: Path, profile: dict[str, object], identifier_ns: str) -> list[str]:
    """Write the generated Bedrock VV JSON files and return their relative paths."""
    written: list[str] = []
    ns = re.sub(r'[^a-z0-9_.-]+', '_', identifier_ns.lower()).strip('_.-')[:60] or 'nex_shader'

    def emit(rel: str, payload: dict[str, object]) -> None:
        _validate_vv_payload(rel, payload)
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
        written.append(rel)

    emit('lighting/global.json', {
        'format_version': '1.26.0',
        'minecraft:lighting_settings': {
            'description': {'identifier': f'{ns}:default_lighting'},
            **profile['lighting'],
        },
    })
    emit('atmospherics/atmospherics.json', {
        'format_version': '1.21.40',
        'minecraft:atmosphere_settings': {
            'description': {'identifier': f'{ns}:default_atmospherics'},
            **profile['atmosphere'],
        },
    })
    emit('color_grading/color_grading.json', {
        'format_version': '1.21.90',
        'minecraft:color_grading_settings': {
            'description': {'identifier': f'{ns}:default_color_grading'},
            'color_grading': profile['grading'],
            'tone_mapping': {'operator': 'generic'},
        },
    })
    emit('water/water.json', {
        'format_version': '1.21.120',
        'minecraft:water_settings': {
            'description': {'identifier': f'{ns}:default_water'},
            **profile['water'],
        },
    })
    emit('shadows/global.json', {
        'format_version': '1.21.80',
        'minecraft:shadow_settings': {
            'shadow_style': 'soft_shadows',
        },
    })
    emit('pbr/global.json', {
        'format_version': '1.21.40',
        'minecraft:pbr_fallback_settings': {
            'blocks': {'global_metalness_emissive_roughness_subsurface': [0.0, 0.0, 255.0, 0.0]},
            'actors': {'global_metalness_emissive_roughness_subsurface': [0.0, 0.0, 255.0, 0.0]},
            'particles': {'global_metalness_emissive_roughness_subsurface': [0.0, 0.0, 255.0, 0.0]},
            'items': {'global_metalness_emissive_roughness_subsurface': [0.0, 0.0, 255.0, 0.0]},
        },
    })
    return written
