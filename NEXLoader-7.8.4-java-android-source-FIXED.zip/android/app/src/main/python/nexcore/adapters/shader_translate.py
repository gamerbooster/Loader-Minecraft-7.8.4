from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path, PurePosixPath


SHADER_EXTENSIONS = {'.vsh', '.fsh', '.glsl', '.vert', '.frag', '.geom', '.comp', '.tesc', '.tese'}

# Features with a documented Bedrock/Vibrant Visuals representation.
NATIVE_FEATURES = {
    'shadows': ('shadow', 'shadowmap', 'shadow_casting', 'shadow_culling'),
    'water': ('water', 'refraction', 'reflection', 'caustic'),
    'atmosphere': ('sky', 'atmosphere', 'mie', 'rayleigh', 'sun_glare'),
    'volumetric_fog': ('volumetric_light', 'volumetric', 'light_shafts', 'godray', 'fog'),
    'color_grading': ('tone_map', 'tonemap', 'color_grading', 'color_conversion', 'saturation', 'contrast'),
    'pbr_materials': ('material', 'roughness', 'metalness', 'metallic', 'emissive', 'normalmap', 'normal_map'),
}

APPROXIMATE_FEATURES = {
    'ambient_occlusion': ('ao', 'ambient_occlusion', 'ssao'),
    'bloom': ('bloom', 'glow', 'brightpass'),
    'clouds': ('cloud', 'clouds'),
}

UNEXPOSED_FEATURES = {
    'taa': ('taa', 'temporal_antialias', 'temporal_aa'),
    'depth_of_field': ('dof', 'depth_of_field', 'bokeh'),
    'motion_blur': ('motion_blur', 'velocity_buffer'),
    'chromatic_aberration': ('chromatic_aberration', 'chroma_aber', 'aberration'),
    'auto_exposure': ('auto_exposure', 'auto-exposure', 'exposure'),
}

PROFILE_FEATURE_ALIASES = {
    'shadows': {'SHADOW_CASTING'},
    'water': {'REFRACTION', 'SUN_REFLECTION', 'VANILLA_WATER'},
    'clouds': {'V_CLOUDS', 'CLOUD_REFLECTION'},
    'bloom': {'BLOOM'},
    'ambient_occlusion': {'AO'},
    'depth_of_field': {'DOF'},
    'motion_blur': {'MOTION_BLUR'},
    'chromatic_aberration': {'CHROMA_ABER'},
    'volumetric_fog': {'VOL_LIGHT'},
    'pbr_materials': {'MATERIAL_GLOSS'},
}


def _safe_rel(name: str) -> str:
    return str(name).replace('\\', '/').lstrip('/')


def _properties_lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]


def _find_profile_options(properties: list[str]) -> dict[str, dict[str, object]]:
    profiles: dict[str, dict[str, object]] = {}
    for line in properties:
        m = re.match(r'profile\.([A-Za-z0-9_.-]+)\s*=\s*(.*)$', line)
        if not m:
            continue
        name = m.group(1)
        rhs = m.group(2)
        enabled: set[str] = set()
        disabled: set[str] = set()
        values: dict[str, str] = {}
        for token in rhs.split():
            if token.startswith('!') and len(token) > 1:
                disabled.add(token[1:].split('=', 1)[0].upper())
            elif '=' in token:
                key, value = token.split('=', 1)
                values[key.upper()] = value
                enabled.add(key.upper())
            elif re.match(r'^[A-Za-z][A-Za-z0-9_]*$', token):
                enabled.add(token.upper())
        profiles[name] = {
            'enabled': sorted(enabled),
            'disabled': sorted(disabled),
            'values': dict(sorted(values.items())),
            'token_count': len(rhs.split()),
        }
    return profiles


def _scan_source_text(text_by_path: dict[str, str]) -> tuple[dict[str, bool], dict[str, int], list[str], set[str]]:
    joined_names = '\n'.join(text_by_path.keys()).lower()
    joined_text = '\n'.join(text_by_path.values()).lower()
    features: dict[str, bool] = {}
    scores: dict[str, int] = {}
    evidence: list[str] = []

    for feature, terms in NATIVE_FEATURES.items():
        hits = sum(joined_names.count(term) + joined_text.count(term) for term in terms)
        scores[feature] = hits
        features[feature] = hits > 0
        if hits:
            evidence.append(f'{feature}:{hits}')

    for feature, terms in APPROXIMATE_FEATURES.items():
        hits = sum(joined_names.count(term) + joined_text.count(term) for term in terms)
        scores[feature] = hits
        features[feature] = hits > 0
        if hits:
            evidence.append(f'{feature}:{hits}')

    for feature, terms in UNEXPOSED_FEATURES.items():
        hits = sum(joined_names.count(term) + joined_text.count(term) for term in terms)
        scores[feature] = hits
        features[feature] = hits > 0
        if hits:
            evidence.append(f'{feature}:{hits}')

    passes: set[str] = set()
    for path in text_by_path:
        stem = PurePosixPath(path).stem.lower()
        if stem.startswith('gbuffers_'):
            passes.add(stem)
        elif stem in {'shadow', 'shadowcomp', 'prepare', 'deferred', 'composite', 'composite1', 'composite2', 'final'}:
            passes.add(stem)
    return features, scores, sorted(evidence), passes


def _apply_profile_features(features: dict[str, bool], scores: dict[str, int], evidence: list[str], profiles: dict[str, dict[str, object]]) -> None:
    """Use shader-pack profile declarations as a second detection channel.

    This matters for packs where an effect is configured in shaders.properties
    but the GLSL source is heavily macro-generated or uses custom filenames.
    """
    for profile_name, profile in profiles.items():
        enabled = set(profile.get('enabled', []))
        disabled = set(profile.get('disabled', []))
        for feature, aliases in PROFILE_FEATURE_ALIASES.items():
            hits = len(enabled & aliases)
            if hits:
                features[feature] = True
                scores[feature] = max(scores.get(feature, 0), hits)
                evidence.append(f'profile.{profile_name}:{feature}:{hits}')
        # An explicit disabled-only profile must not erase the fact that another
        # profile may enable the feature. It is kept in profile data for audit.
        _ = disabled


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _color_hex(r: float, g: float, b: float) -> str:
    vals = [r, g, b]
    if all(0.0 <= v <= 1.0 for v in vals):
        vals = [v * 255.0 for v in vals]
    vals = [int(round(_clamp(v, 0.0, 255.0))) for v in vals]
    # Use an explicit 8-digit RGBA hex form. This is accepted by the current
    # Bedrock color parser and avoids the ambiguous 6-digit form that can
    # produce:
    #   Expected [r, g, b, a] ... or a hex value with 8 characters.
    return '#' + ''.join(f'{v:02x}' for v in vals) + 'ff'


def _extract_rgb(text: str, prefix: str) -> str | None:
    pat = re.compile(
        rf'{re.escape(prefix)}[_ ]?R\s*=\s*([-+0-9.eE]+).*?'
        rf'{re.escape(prefix)}[_ ]?G\s*=\s*([-+0-9.eE]+).*?'
        rf'{re.escape(prefix)}[_ ]?B\s*=\s*([-+0-9.eE]+)',
        re.I | re.S,
    )
    m = pat.search(text)
    if m:
        try:
            return _color_hex(float(m.group(1)), float(m.group(2)), float(m.group(3)))
        except ValueError:
            return None
    return None


def _default_visuals(features: dict[str, bool], text: str) -> dict[str, object]:
    # These values intentionally stay inside documented Bedrock ranges. They are
    # a semantic recreation, not a source-level GLSL translation.
    sun_illuminance = {
        '0.0': 110000.0,
        '0.25': 35000.0,
        '0.35': 400.0,
        '0.5': 1.5,
        '0.65': 400.0,
        '0.75': 35000.0,
        '1.0': 110000.0,
    }
    moon_illuminance = 0.35

    night_zenith = _extract_rgb(text, 'ZENITH_NIGHT_COLOR')
    night_horizon = _extract_rgb(text, 'HORIZON_NIGHT_COLOR')
    sunset_horizon = _extract_rgb(text, 'HORIZON_SUNSET_COLOR')

    atmosphere = {
        'horizon_blend_stops': {
            'min': 0.0,
            'start': 0.25,
            'mie_start': 0.5,
            'max': 0.8,
        },
        'rayleigh_strength': 0.55 if features.get('atmosphere') else 0.0,
        'sun_mie_strength': 0.05 if features.get('atmosphere') else 0.0,
        'moon_mie_strength': 0.015 if features.get('atmosphere') else 0.0,
        'sun_glare_shape': 8.0,
        'sky_zenith_color': night_zenith or '#5aa6ffff',
        'sky_horizon_color': night_horizon or '#ffd6a0ff',
    }
    if sunset_horizon:
        atmosphere['sky_horizon_color'] = sunset_horizon
    elif re.search(r'(SUNSET|HORIZON_SUNSET|LIGHT_SUNSET)', text, re.I):
        atmosphere['sky_horizon_color'] = '#ffad7aff'

    lighting = {
        'directional_lights': {
            'orbital': {
                'sun': {'illuminance': sun_illuminance, 'color': '#ffffffff'},
                'moon': {'illuminance': moon_illuminance, 'color': '#cbd7ffff'},
                'orbital_offset_degrees': 0.0,
            },
            'flash': {'illuminance': 5.0, 'color': '#ffffffff'},
        },
        'emissive': {'desaturation': 0.10},
        'ambient': {'illuminance': 0.02, 'color': '#ffffffff'},
        'sky': {'intensity': 1.0},
    }

    grading = {
        'midtones': {
            'contrast': [1.08, 1.08, 1.08],
            'gain': [1.0, 1.0, 1.0],
            'gamma': [2.2, 2.2, 2.2],
            'offset': [0.0, 0.0, 0.0],
            'saturation': [1.05 if features.get('color_grading') else 1.0] * 3,
        },
        'shadows': {
            'enabled': True,
            'shadowsMax': 0.45,
            'contrast': [1.04, 1.04, 1.04],
            'gain': [0.96, 0.97, 1.0],
            'gamma': [2.2, 2.2, 2.2],
            'offset': [0.0, 0.0, 0.0],
            'saturation': [1.0, 1.0, 1.02],
        },
        'highlights': {
            'enabled': True,
            'highlightsMin': 1.75,
            'contrast': [1.05, 1.05, 1.05],
            'gain': [1.03, 1.03, 1.03],
            'gamma': [2.2, 2.2, 2.2],
            'offset': [0.0, 0.0, 0.0],
            'saturation': [1.04, 1.04, 1.04],
        },
        'temperature': {
            'enabled': bool(re.search(r'(temperature|warm|cold|sunset)', text, re.I)),
            'temperature': 6500,
            'type': 'color_temperature',
        },
    }

    water = {
        'particle_concentrations': {
            'chlorophyll': 0.4 if features.get('water') else 0.0,
            'suspended_sediment': 0.6 if features.get('water') else 0.15,
            'cdom': 0.7 if features.get('water') else 0.2,
        },
        'waves': {
            'enabled': bool(features.get('water')),
            'depth': 1,
            'direction_increment': 80.0,
            'frequency': 1.0,
            'frequency_scaling': 1.2,
            'mix': 0.2,
            'octaves': 24,
            'pull': 0.38,
            'sampleWidth': 0.01,
            'shape': 1.5,
            'speed': 2.0,
            'speed_scaling': 1.03,
        },
        'caustics': {
            'enabled': bool(features.get('water')),
            'frame_length': 0.05,
            'power': 2,
            'scale': 0.5,
        },
        'biome_water_color_contribution': 0.25 if features.get('water') else 0.15,
    }
    return {'lighting': lighting, 'atmosphere': atmosphere, 'grading': grading, 'water': water}


def _native_support(features: dict[str, bool]) -> dict[str, str]:
    support: dict[str, str] = {}
    for feature in NATIVE_FEATURES:
        if features.get(feature):
            support[feature] = 'native'
    for feature in APPROXIMATE_FEATURES:
        if features.get(feature):
            support[feature] = 'approximate'
    for feature in UNEXPOSED_FEATURES:
        if features.get(feature):
            support[feature] = 'not_exposed'
    return support


def translate_shaderpack(source_files: dict[str, bytes], mod_id: str, pack_name: str) -> dict[str, object]:
    """Analyze a Java shaderpack and produce a Bedrock-native VV profile.

    Java GLSL is never executed by this function. The translator extracts render
    intent from shader pass names, GLSL text and option profiles, then emits data
    for the documented Bedrock Vibrant Visuals/PBR pipeline.
    """
    text_by_path: dict[str, str] = {}
    profile_texts: list[str] = []
    source_hashes: dict[str, str] = {}
    for name, raw in source_files.items():
        safe_name = _safe_rel(name)
        source_hashes[safe_name] = hashlib.sha256(raw).hexdigest()
        ext = PurePosixPath(name).suffix.lower()
        if ext in SHADER_EXTENSIONS or ext in {'.properties', '.json', '.txt', '.lang'}:
            text = raw.decode('utf-8', errors='replace')
            text_by_path[safe_name] = text
            if PurePosixPath(name).name.lower() in {'shaders.properties', 'shader.properties', 'optionsshaders.txt'}:
                profile_texts.extend(_properties_lines(text))

    features, scores, evidence, passes = _scan_source_text(text_by_path)
    profiles = _find_profile_options(profile_texts)
    _apply_profile_features(features, scores, evidence, profiles)
    evidence = sorted(set(evidence))

    profile_feature_summary: dict[str, list[str]] = {}
    for profile_name, profile in profiles.items():
        enabled = set(profile.get('enabled', []))
        summary: list[str] = []
        for feature, aliases in PROFILE_FEATURE_ALIASES.items():
            if enabled & aliases:
                summary.append(feature)
        profile_feature_summary[profile_name] = sorted(summary)

    all_text = '\n'.join(text_by_path.values())
    visuals = _default_visuals(features, all_text)
    support = _native_support(features)
    quality = 'native_profile' if not any(v in support.values() for v in ('approximate', 'not_exposed')) else 'hybrid_semantic_profile'

    limitations = []
    for feature in ('taa', 'depth_of_field', 'motion_blur', 'chromatic_aberration', 'auto_exposure'):
        if features.get(feature):
            limitations.append(feature)
    if features.get('bloom'):
        limitations.append('bloom')
    if features.get('clouds'):
        limitations.append('clouds:approximate')
    if features.get('ambient_occlusion'):
        limitations.append('ambient_occlusion:approximate')

    return {
        'schema_target': 'Vibrant Visuals',
        'schema_version': '1.26.0',
        'pack_name': pack_name,
        'mod_id': mod_id,
        'conversion_method': 'semantic_reimplementation',
        'quality': quality,
        'features': {k: bool(v) for k, v in sorted(features.items())},
        'feature_support': support,
        'feature_scores': dict(sorted(scores.items())),
        'evidence': evidence,
        'render_passes': sorted(passes),
        'profiles': profiles,
        'profile_feature_summary': profile_feature_summary,
        'limitations': sorted(set(limitations)),
        'source_file_count': len(source_files),
        'source_sha256': dict(sorted(source_hashes.items())),
        'original_runtime': 'Java OpenGL/Iris/OptiFine shader pipeline',
        'bedrock_runtime': 'Render Dragon / Vibrant Visuals PBR pipeline',
        'attribution_note': 'No Java GLSL source is activated. The generated profile is a Bedrock-native reimplementation of detected visual intent.',
        'lighting': visuals['lighting'],
        'atmosphere': visuals['atmosphere'],
        'grading': visuals['grading'],
        'water': visuals['water'],
    }


def _validate_vv_payload(rel: str, payload: dict[str, object]) -> None:
    """Fail closed on the common Bedrock VV JSON mistakes caught at runtime."""
    if rel == 'lighting/global.json':
        settings = payload.get('minecraft:lighting_settings')
        if not isinstance(settings, dict):
            raise ValueError('lighting schema missing minecraft:lighting_settings')
        directional = settings.get('directional_lights')
        if not isinstance(directional, dict) or not isinstance(directional.get('orbital'), dict):
            raise ValueError('lighting schema missing directional_lights.orbital')
        orbital = directional['orbital']
        for branch in ('sun', 'moon'):
            light = orbital.get(branch)
            if not isinstance(light, dict) or 'illuminance' not in light or 'color' not in light:
                raise ValueError(f'lighting schema missing orbital.{branch}.illuminance/color')
            color = light['color']
            if not (isinstance(color, str) and re.fullmatch(r'#[0-9a-fA-F]{8}', color)):
                raise ValueError(f'lighting orbital.{branch}.color must be an 8-digit hex color')
        flash = directional.get('flash')
        if not isinstance(flash, dict) or 'illuminance' not in flash or 'color' not in flash:
            raise ValueError('lighting schema missing directional_lights.flash')
        if not (isinstance(flash['color'], str) and re.fullmatch(r'#[0-9a-fA-F]{8}', flash['color'])):
            raise ValueError('lighting flash.color must be an 8-digit hex color')
        ambient = settings.get('ambient')
        if not isinstance(ambient, dict) or not (isinstance(ambient.get('color'), str) and re.fullmatch(r'#[0-9a-fA-F]{8}', ambient['color'])):
            raise ValueError('lighting ambient.color must be an 8-digit hex color')
    elif rel == 'atmospherics/atmospherics.json':
        settings = payload.get('minecraft:atmosphere_settings')
        if not isinstance(settings, dict):
            raise ValueError('atmospherics schema missing minecraft:atmosphere_settings')
        for key in ('sky_zenith_color', 'sky_horizon_color'):
            color = settings.get(key)
            if not (isinstance(color, str) and re.fullmatch(r'#[0-9a-fA-F]{8}', color)) and not isinstance(color, (list, dict)):
                raise ValueError(f'atmospherics {key} is not a valid color/keyframe')

def emit_vibrant_visuals_profile(root: Path, profile: dict[str, object], identifier_ns: str) -> list[str]:
    """Write the generated Bedrock VV JSON files and return their relative paths."""
    written: list[str] = []
    ns = re.sub(r'[^a-z0-9_.-]+', '_', identifier_ns.lower())[:60] or 'nex_shader'

    def emit(rel: str, payload: dict[str, object]) -> None:
        _validate_vv_payload(rel, payload)
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
        written.append(rel)

    emit('lighting/global.json', {
        'format_version': '1.26.0',
        'minecraft:lighting_settings': {
            'description': {'identifier': f'{ns}:default_lighting'},
            **profile['lighting'],
        },
    })
    emit('atmospherics/atmospherics.json', {
        'format_version': '1.21.40',
        'minecraft:atmosphere_settings': {
            'description': {'identifier': f'{ns}:default_atmospherics'},
            **profile['atmosphere'],
        },
    })
    emit('color_grading/color_grading.json', {
        'format_version': '1.21.90',
        'minecraft:color_grading_settings': {
            'description': {'identifier': f'{ns}:default_color_grading'},
            'color_grading': profile['grading'],
            'tone_mapping': {'operator': 'generic'},
        },
    })
    emit('water/water.json', {
        'format_version': '1.26.0',
        'minecraft:water_settings': {
            'description': {'identifier': f'{ns}:default_water'},
            **profile['water'],
        },
    })
    emit('shadows/global.json', {
        'format_version': '1.21.80',
        'minecraft:shadow_settings': {
            'shadow_style': 'soft_shadows',
            'texel_size': 16,
        },
    })
    emit('pbr/global.json', {
        'format_version': '1.21.40',
        'minecraft:pbr_fallback_settings': {
            'blocks': {'global_metalness_emissive_roughness_subsurface': [0.0, 0.0, 255.0, 0.0]},
            'actors': {'global_metalness_emissive_roughness_subsurface': [0.0, 0.0, 255.0, 0.0]},
            'particles': {'global_metalness_emissive_roughness_subsurface': [0.0, 0.0, 255.0, 0.0]},
            'items': {'global_metalness_emissive_roughness_subsurface': [0.0, 0.0, 255.0, 0.0]},
        },
    })
    return written
