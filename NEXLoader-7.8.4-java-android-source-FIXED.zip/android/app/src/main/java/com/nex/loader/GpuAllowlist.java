package com.nex.loader;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pure-Java (no Android dependencies) decision of whether a GL_RENDERER string
 * belongs to a GPU that Minecraft Bedrock officially lists for Vibrant Visuals.
 *
 * Official Android list (minecraft.net/vibrant-visuals-update):
 *   Adreno 640, Mali-G68, Mali-G77, or Xclipse 530 or higher.
 *
 * The check is deliberately conservative: when a renderer cannot be positively
 * identified as supported, the caller falls back to the classic (non-PBR) pack,
 * which is the safe failure mode (no ResourcePack.incompatible.graphics.pbr).
 */
public final class GpuAllowlist {
    private GpuAllowlist() {}

    private static final Pattern ADRENO = Pattern.compile("adreno\\s*(?:\\(tm\\)\\s*)?(\\d+)");
    private static final Pattern XCLIPSE = Pattern.compile("xclipse\\s*(\\d+)");
    private static final Pattern MALI = Pattern.compile("(?:mali|immortalis)[- ]?g(\\d+)");

    public static boolean isVibrantVisualsSupported(String renderer) {
        if (renderer == null) return false;
        String s = renderer.toLowerCase(Locale.ROOT);

        Matcher a = ADRENO.matcher(s);
        if (a.find()) return parse(a.group(1)) >= 640;

        Matcher x = XCLIPSE.matcher(s);
        if (x.find()) return parse(x.group(1)) >= 530;

        Matcher m = MALI.matcher(s);
        if (m.find()) return isSupportedMali(parse(m.group(1)));

        return false;
    }

    /**
     * Mali-G68 and Mali-G77 are the listed minimums. Older Bifrost parts (G51, G52,
     * G71, G72, G76) are below the list. Newer parts are accepted when they are
     * clearly the same or a later generation: G78, and the 600/700-series
     * (G610, G615, G710, G715, G720, G725 and Immortalis variants). Low-end
     * newer-gen parts (G310, G510) are intentionally not accepted because the
     * official list does not name them.
     */
    static boolean isSupportedMali(int model) {
        return model == 68 || model == 77 || model == 78 || model >= 600;
    }

    private static int parse(String digits) {
        try {
            return Integer.parseInt(digits);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
