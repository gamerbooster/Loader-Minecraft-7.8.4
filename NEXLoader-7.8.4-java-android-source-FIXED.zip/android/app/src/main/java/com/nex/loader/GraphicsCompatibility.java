package com.nex.loader;

import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;


/**
 * Small runtime probe used to keep NEXLoader from importing PBR/Vibrant Visuals
 * shader packs on Android GPUs that Minecraft does not officially expose for VV.
 */
public final class GraphicsCompatibility {
    private GraphicsCompatibility() {}

    public static final class Info {
        public final String renderer;
        public final String version;
        public final boolean vibrantVisualsSupported;
        public final String profile;

        private Info(String renderer, String version, boolean supported) {
            this.renderer = renderer == null ? "unknown" : renderer;
            this.version = version == null ? "unknown" : version;
            this.vibrantVisualsSupported = supported;
            this.profile = supported ? "android_vv" : "android_legacy";
        }
    }

    public static Info probe() {
        EGLDisplay display = EGL14.EGL_NO_DISPLAY;
        EGLContext context = EGL14.EGL_NO_CONTEXT;
        EGLSurface surface = EGL14.EGL_NO_SURFACE;
        try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            if (display == EGL14.EGL_NO_DISPLAY) return new Info("unknown", "unknown", false);

            int[] version = new int[2];
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) {
                return new Info("unknown", "unknown", false);
            }

            int[] configAttrs = {
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                    EGL14.EGL_RED_SIZE, 8,
                    EGL14.EGL_GREEN_SIZE, 8,
                    EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_NONE
            };
            EGLConfig[] configs = new EGLConfig[1];
            int[] count = new int[1];
            if (!EGL14.eglChooseConfig(display, configAttrs, 0, configs, 0, 1, count, 0) || count[0] == 0) {
                return new Info("unknown", "unknown", false);
            }

            int[] contextAttrs = {
                    EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
                    EGL14.EGL_NONE
            };
            context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, contextAttrs, 0);
            if (context == EGL14.EGL_NO_CONTEXT) return new Info("unknown", "unknown", false);

            int[] surfaceAttrs = {
                    EGL14.EGL_WIDTH, 1,
                    EGL14.EGL_HEIGHT, 1,
                    EGL14.EGL_NONE
            };
            surface = EGL14.eglCreatePbufferSurface(display, configs[0], surfaceAttrs, 0);
            if (surface == EGL14.EGL_NO_SURFACE) return new Info("unknown", "unknown", false);
            if (!EGL14.eglMakeCurrent(display, surface, surface, context)) {
                return new Info("unknown", "unknown", false);
            }

            String renderer = GLES20.glGetString(GLES20.GL_RENDERER);
            String glVersion = GLES20.glGetString(GLES20.GL_VERSION);
            return new Info(renderer, glVersion, isOfficiallySupportedRenderer(renderer));
        } catch (Throwable ignored) {
            return new Info("unknown", "unknown", false);
        } finally {
            try {
                if (display != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                }
            } catch (Throwable ignored) {}
            try {
                if (display != EGL14.EGL_NO_DISPLAY && surface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface);
            } catch (Throwable ignored) {}
            try {
                if (display != EGL14.EGL_NO_DISPLAY && context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context);
            } catch (Throwable ignored) {}
            try {
                if (display != EGL14.EGL_NO_DISPLAY) EGL14.eglTerminate(display);
            } catch (Throwable ignored) {}
        }
    }

    private static boolean isOfficiallySupportedRenderer(String renderer) {
        // Decision logic lives in the pure-Java GpuAllowlist so it can be unit
        // tested off-device (see core/tests/test_127_gpu_allowlist.py).
        return GpuAllowlist.isVibrantVisualsSupported(renderer);
    }
}
