package com.nex.loader;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Local Java-world conversion engine for Android.
 *
 * NEXLoader does not depend on a desktop Java installation.  At build time the
 * APK receives Chunker CLI 1.21.0 and the Android OpenJDK 17 runtime for the
 * supported 64-bit ABIs.  At runtime this class extracts the correct JRE into
 * app-private storage, validates java -version, and launches Chunker through
 * its documented CLI interface.
 */
public final class WorldEngine {
    public static final String CHUNKER_VERSION = "1.21.0";
    public static final String CHUNKER_ASSET = "world_engine/chunker-cli-1.21.0.jar";
    public static final String TARGET_FORMAT = "BEDROCK_1_26_60";
    private static final long PROCESS_TIMEOUT_MINUTES = 90L;
    private static final long MAX_WORLD_ZIP_BYTES = 2L * 1024L * 1024L * 1024L;

    private WorldEngine() {
    }

    public static final class Result {
        public final File mcworld;
        public final String message;
        public final String logs;

        Result(File mcworld, String message, String logs) {
            this.mcworld = mcworld;
            this.message = message;
            this.logs = logs;
        }
    }

    public static boolean looksLikeWorld(File input) {
        if (input == null || !input.exists()) return false;
        if (input.isDirectory()) {
            return new File(input, "level.dat").isFile()
                    || new File(input, "level.dat_old").isFile() && hasWorldStorage(input);
        }
        if (!input.isFile()) return false;
        String lower = input.getName().toLowerCase(Locale.ROOT);
        if (!(lower.endsWith(".zip") || lower.endsWith(".mcworld"))) return false;
        return zipContainsWorld(input);
    }

    public static String probe(Context context, File input) {
        StringBuilder sb = new StringBuilder();
        sb.append("Motor de mundos: Chunker ").append(CHUNKER_VERSION).append('\n');
        sb.append("Destino: Bedrock 1.26.60\n");
        sb.append("Entrada: ").append(input == null ? "-" : input.getName()).append('\n');
        if (!looksLikeWorld(input)) {
            sb.append("Estado: no parece un mundo Java válido.\n");
            return sb.toString();
        }
        try {
            EngineFiles files = prepareEngine(context);
            ProcessResult javaCheck = runJavaProcess(files.javaBin, files.jreDir, "-version");
            sb.append("JRE Android 17: ")
                    .append(javaCheck.exitCode == 0 ? "PASS" : "FAIL")
                    .append('\n');
            if (!javaCheck.output.isEmpty()) {
                sb.append(javaCheck.output.trim()).append('\n');
            }
            ProcessResult chunkerHelp = runJavaProcess(
                    files.javaBin, files.jreDir,
                    "-jar", files.chunkerJar.getAbsolutePath(), "--help"
            );
            sb.append("Chunker CLI: ")
                    .append(chunkerHelp.exitCode == 0 ? "PASS" : "FAIL")
                    .append('\n');
            if (chunkerHelp.exitCode != 0 && !chunkerHelp.output.isEmpty()) {
                sb.append(chunkerHelp.output.trim()).append('\n');
            }
            if (javaCheck.exitCode != 0) {
                sb.append("Diagnóstico: el fallo ocurre en el JRE Android, antes de leer el mundo.\n");
            } else if (chunkerHelp.exitCode != 0) {
                sb.append("Diagnóstico: el JRE inicia, pero el CLI de Chunker no pudo arrancar.\n");
            } else {
                sb.append("Diagnóstico: motor listo para procesar el mundo.\n");
            }
        } catch (Exception e) {
            sb.append("Estado: FAIL\n");
            sb.append(e.getClass().getSimpleName()).append(": ")
                    .append(e.getMessage() == null ? "sin detalle" : e.getMessage()).append('\n');
        }
        return sb.toString();
    }

    public static Result convert(Context context, File input, File outputRoot) throws Exception {
        if (!looksLikeWorld(input)) {
            throw new IllegalArgumentException("La entrada no contiene un mundo Java reconocible (falta level.dat).");
        }
        if (outputRoot == null) throw new IllegalArgumentException("Output directory is null");
        if (!outputRoot.exists() && !outputRoot.mkdirs()) {
            throw new IOException("No se pudo crear la salida: " + outputRoot);
        }

        EngineFiles engine = prepareEngine(context);
        ProcessResult javaCheck = runJavaProcess(engine.javaBin, engine.jreDir, "-version");
        if (javaCheck.exitCode != 0) {
            throw new WorldEngineUnavailable(
                    "El JRE Android 17 no pudo iniciar correctamente. " + summarize(javaCheck.output)
            );
        }

        File preparedInput = input;
        File tempInput = null;
        if (!input.isDirectory()) {
            tempInput = new File(outputRoot.getParentFile(), "world-input-" + System.currentTimeMillis());
            if (!tempInput.mkdirs()) throw new IOException("No se pudo crear el staging del mundo");
            extractWorldZip(input, tempInput);
            preparedInput = findWorldRoot(tempInput);
        }

        File chunkerOutput = new File(outputRoot, "chunker_output");
        if (!chunkerOutput.mkdirs()) throw new IOException("No se pudo crear la salida de Chunker");

        ProcessResult result = runJavaProcess(engine.javaBin, engine.jreDir,
                "-Xmx" + recommendedHeapMb(context) + "m",
                "-Dfile.encoding=UTF-8",
                "-jar", engine.chunkerJar.getAbsolutePath(),
                "-i", preparedInput.getAbsolutePath(),
                "-f", TARGET_FORMAT,
                "-o", chunkerOutput.getAbsolutePath());

        if (tempInput != null) deleteRecursively(tempInput);
        if (result.exitCode != 0) {
            throw new WorldEngineUnavailable(
                    "Chunker no pudo convertir el mundo. Salida: " + summarize(result.output)
            );
        }

        File bedrockRoot = findBedrockOutput(chunkerOutput);
        File mcworld = new File(outputRoot, safeWorldName(input.getName()) + "-Bedrock-1.26.60.mcworld");
        zipDirectory(bedrockRoot, mcworld);
        return new Result(
                mcworld,
                "Mundo convertido con Chunker " + CHUNKER_VERSION + " → Bedrock 1.26.60",
                result.output
        );
    }

    private static int recommendedHeapMb(Context context) {
        long max = Runtime.getRuntime().maxMemory();
        long byRuntime = max / (1024L * 1024L);
        // The app itself should retain headroom.  Chunker can still use large
        // heaps on capable phones without forcing a fixed 75% of device RAM.
        long recommended = Math.max(768L, Math.min(4096L, byRuntime * 3L / 4L));
        return (int) recommended;
    }

    private static final class EngineFiles {
        final File jreDir;
        final File javaBin;
        final File chunkerJar;

        EngineFiles(File jreDir, File javaBin, File chunkerJar) {
            this.jreDir = jreDir;
            this.javaBin = javaBin;
            this.chunkerJar = chunkerJar;
        }
    }

    private static EngineFiles prepareEngine(Context context) throws Exception {
        String abi = selectAbi();
        String assetRoot = "world_engine/jre/" + abi;
        File base = new File(context.getFilesDir(), "world_engine/" + CHUNKER_VERSION + "/" + abi);
        File marker = new File(base, ".ready");
        File javaBin = new File(base, "bin/java");
        if (!marker.isFile() || !javaBin.isFile()) {
            if (base.exists()) deleteRecursively(base);
            if (!base.mkdirs()) throw new IOException("No se pudo crear JRE privado");
            copyAssetTree(context.getAssets(), assetRoot, base);
            makeExecutable(javaBin);
            marker.createNewFile();
        } else {
            makeExecutable(javaBin);
        }

        File chunkerJar = new File(new File(context.getFilesDir(), "world_engine"), "chunker-cli-" + CHUNKER_VERSION + ".jar");
        if (!chunkerJar.isFile()) {
            File parent = chunkerJar.getParentFile();
            if (!parent.exists() && !parent.mkdirs()) throw new IOException("No se pudo crear carpeta del motor");
            copyAssetFile(context.getAssets(), CHUNKER_ASSET, chunkerJar);
        }
        if (chunkerJar.length() < 10_000_000L) {
            throw new IOException("Chunker CLI embebido está incompleto: " + chunkerJar.length() + " bytes");
        }

        ProcessResult check = runJavaProcess(javaBin, base, "-version");
        if (check.exitCode != 0) {
            // Never keep a half-working extraction marked as ready.
            marker.delete();
            throw new WorldEngineUnavailable(
                    "El JRE Android instalado no pudo iniciar Java 17+ correctamente. " + summarize(check.output)
            );
        }
        return new EngineFiles(base, javaBin, chunkerJar);
    }

    private static String selectAbi() throws WorldEngineUnavailable {
        for (String abi : Build.SUPPORTED_ABIS) {
            if ("arm64-v8a".equals(abi)) return "arm64-v8a";
            if ("x86_64".equals(abi)) return "x86_64";
        }
        throw new WorldEngineUnavailable(
                "ABI no compatible: " + Arrays.toString(Build.SUPPORTED_ABIS) + ". Se requiere arm64-v8a o x86_64."
        );
    }

    private static void copyAssetTree(AssetManager assets, String assetRoot, File destination) throws Exception {
        String[] children = assets.list(assetRoot);
        if (children == null) children = new String[0];
        for (String child : children) {
            String source = assetRoot + "/" + child;
            String[] nested = assets.list(source);
            File out = new File(destination, child);
            if (nested != null && nested.length > 0) {
                if (!out.exists() && !out.mkdirs()) throw new IOException("No se pudo crear " + out);
                copyAssetTree(assets, source, out);
            } else {
                copyAssetFile(assets, source, out);
            }
        }
    }

    private static void copyAssetFile(AssetManager assets, String assetPath, File destination) throws Exception {
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("No se pudo crear " + parent);
        }
        try (InputStream in = assets.open(assetPath, AssetManager.ACCESS_STREAMING);
             OutputStream out = new FileOutputStream(destination)) {
            byte[] buffer = new byte[1024 * 1024];
            for (;;) {
                int n = in.read(buffer);
                if (n < 0) break;
                out.write(buffer, 0, n);
            }
        }
    }

    private static void makeExecutable(File file) throws IOException {
        if (!file.setReadable(true, true) || !file.setExecutable(true, true)) {
            throw new IOException("No se pudieron fijar permisos ejecutables de " + file);
        }
    }

    private static final class ProcessResult {
        final int exitCode;
        final String output;

        ProcessResult(int exitCode, String output) {
            this.exitCode = exitCode;
            this.output = output;
        }
    }

    private static ProcessResult runJavaProcess(File javaBin, File jreDir, String... javaArgs) throws Exception {
        List<String> command = new ArrayList<>();
        command.add(javaBin.getAbsolutePath());
        command.addAll(Arrays.asList(javaArgs));
        ProcessBuilder pb = new ProcessBuilder(command);
        java.util.Map<String, String> env = pb.environment();
        env.put("JAVA_HOME", jreDir.getAbsolutePath());
        env.put("JRE_HOME", jreDir.getAbsolutePath());
        env.put("HOME", jreDir.getParentFile().getParentFile().getAbsolutePath());
        env.put("PATH", new File(jreDir, "bin").getAbsolutePath() + File.pathSeparator + env.get("PATH"));
        String lib = new File(jreDir, "lib").getAbsolutePath();
        String server = new File(jreDir, "lib/server").getAbsolutePath();
        env.put("LD_LIBRARY_PATH", lib + File.pathSeparator + server + File.pathSeparator + env.get("LD_LIBRARY_PATH"));
        pb.redirectErrorStream(true);
        Process p = pb.start();
        StringBuilder output = new StringBuilder();
        Thread reader = new Thread(() -> {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    synchronized (output) {
                        if (output.length() < 500_000) output.append(line).append('\n');
                    }
                }
            } catch (IOException ignored) {
            }
        }, "nex-world-engine-output");
        reader.start();
        boolean done = p.waitFor(PROCESS_TIMEOUT_MINUTES, TimeUnit.MINUTES);
        if (!done) {
            p.destroyForcibly();
            reader.join(1000L);
            throw new IOException("La conversión excedió el límite de " + PROCESS_TIMEOUT_MINUTES + " minutos");
        }
        reader.join(5000L);
        return new ProcessResult(p.exitValue(), output.toString());
    }

    private static String summarize(String output) {
        if (output == null || output.trim().isEmpty()) return "sin salida del proceso";
        String s = output.trim();
        return s.length() > 1500 ? s.substring(s.length() - 1500) : s;
    }

    private static boolean hasWorldStorage(File root) {
        return new File(root, "region").isDirectory()
                || new File(root, "entities").isDirectory()
                || new File(root, "poi").isDirectory();
    }

    private static boolean zipContainsWorld(File zip) {
        try (ZipFile z = new ZipFile(zip)) {
            for (java.util.Enumeration<? extends ZipEntry> e = z.entries(); e.hasMoreElements();) {
                String name = normalizeZipPath(e.nextElement().getName());
                if (name.equals("level.dat") || name.endsWith("/level.dat")) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private static void extractWorldZip(File zip, File destination) throws Exception {
        long total = 0L;
        try (ZipFile z = new ZipFile(zip)) {
            for (java.util.Enumeration<? extends ZipEntry> en = z.entries(); en.hasMoreElements();) {
                ZipEntry entry = en.nextElement();
                String name = normalizeZipPath(entry.getName());
                if (name.isEmpty()) continue;
                if (name.startsWith("/") || name.contains("../") || name.equals("..")) {
                    throw new IOException("Ruta insegura en ZIP: " + name);
                }
                File out = new File(destination, name);
                File canonicalRoot = destination.getCanonicalFile();
                File canonicalOut = out.getCanonicalFile();
                if (!canonicalOut.toPath().startsWith(canonicalRoot.toPath())) {
                    throw new IOException("Ruta ZIP fuera del staging: " + name);
                }
                if (entry.isDirectory()) {
                    if (!out.exists() && !out.mkdirs()) throw new IOException("No se pudo crear " + out);
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("No se pudo crear " + parent);
                try (InputStream in = z.getInputStream(entry); OutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[1024 * 1024];
                    for (;;) {
                        int n = in.read(buf);
                        if (n < 0) break;
                        total += n;
                        if (total > MAX_WORLD_ZIP_BYTES) throw new IOException("El mundo descomprimido excede el límite de seguridad");
                        os.write(buf, 0, n);
                    }
                }
            }
        }
    }

    private static File findWorldRoot(File staging) throws IOException {
        if (new File(staging, "level.dat").isFile()) return staging;
        File[] children = staging.listFiles();
        if (children != null) {
            for (File child : children) {
                if (child.isDirectory() && new File(child, "level.dat").isFile()) return child;
            }
        }
        throw new IOException("El ZIP contiene level.dat, pero no se pudo determinar la raíz del mundo");
    }

    private static File findBedrockOutput(File chunkerOutput) throws IOException {
        if (hasBedrockFiles(chunkerOutput)) return chunkerOutput;
        File[] children = chunkerOutput.listFiles();
        if (children != null) {
            for (File child : children) {
                if (child.isDirectory() && hasBedrockFiles(child)) return child;
            }
        }
        throw new IOException("Chunker terminó sin generar un mundo Bedrock reconocible");
    }

    private static boolean hasBedrockFiles(File root) {
        return new File(root, "level.dat").isFile() && new File(root, "db").isDirectory();
    }

    private static void zipDirectory(File sourceDir, File destination) throws Exception {
        List<File> files = new ArrayList<>();
        collectFiles(sourceDir, sourceDir, files);
        files.sort(Comparator.comparing(File::getAbsolutePath));
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(destination))) {
            byte[] buf = new byte[1024 * 1024];
            for (File file : files) {
                String relative = sourceDir.toPath().relativize(file.toPath()).toString().replace(File.separatorChar, '/');
                ZipEntry entry = new ZipEntry(relative);
                zos.putNextEntry(entry);
                try (InputStream in = new FileInputStream(file)) {
                    int n;
                    while ((n = in.read(buf)) >= 0) {
                        if (n > 0) zos.write(buf, 0, n);
                    }
                }
                zos.closeEntry();
            }
        }
    }

    private static void collectFiles(File root, File current, List<File> files) {
        File[] children = current.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) collectFiles(root, child, files);
            else files.add(child);
        }
    }

    private static String safeWorldName(String name) {
        String base = name;
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        base = base.replaceAll("[^A-Za-z0-9._-]", "_");
        return base.isEmpty() ? "World" : base;
    }

    private static String normalizeZipPath(String path) {
        return path.replace('\\', '/').replaceAll("^/+", "");
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) deleteRecursively(child);
        }
        // Best effort cleanup. Conversion failure must not hide the real error.
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    public static final class WorldEngineUnavailable extends IOException {
        public WorldEngineUnavailable(String message) {
            super(message);
        }
    }
}
