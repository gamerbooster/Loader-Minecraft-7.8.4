# NEXLoader 7.8.4 — Shader Semantic Bridge (M3)

NEXLoader now treats Java shaderpacks as a dedicated input kind and lowers their
render intent into Bedrock Vibrant Visuals/PBR resource-pack settings.

## Pipeline

`Java shaderpack (Iris/OptiFine/OpenGL)`

→ shader pass/config audit

→ feature detection and profile extraction

→ `lighting/global.json`, `atmospherics/atmospherics.json`,
`color_grading/color_grading.json`, `water/water.json`,
`shadows/global.json`, `pbr/global.json`

→ `nex_shader/profile.json`

→ Bedrock `.mcpack` / `.mcaddon`

The Java `.vsh`, `.fsh`, `.glsl` and related files are retained under
`nex_untranslated/shaderpack` for audit and traceability. They are **not** copied
into an active Bedrock shader pipeline and Iris is **not** installed or required.

## Compatibility model

Features with direct Vibrant Visuals controls are lowered natively, including
lighting, atmosphere, water, shadows, color grading and PBR fallback values.
Ambient occlusion, bloom and clouds are reported as semantic/approximate where
there is no one-to-one public setting. TAA, depth of field, motion blur,
chromatic aberration and auto-exposure are explicitly reported when detected
rather than being falsely marked as converted.

On Android, NEXLoader probes the real OpenGL renderer before conversion. When
the renderer does not meet Minecraft's current official Vibrant Visuals GPU\+requirements, NEXLoader uses `android_legacy`: it removes the `pbr` capability
and does not emit deferred/Vibrant Visuals JSON files, preventing
`ResourcePack.incompatible.graphics.pbr`. Java GLSL remains audit-only because
the Classic Bedrock renderer cannot execute the Java Iris/OptiFine pipeline.

The current official Minecraft Android requirement lists Adreno 640, Mali-G68,
Mali-G77, Xclipse 530 or higher; the Moto G15 uses an Arm Mali-G52 MC2 GPU, so
it falls into the automatic compatibility fallback.

## MakeUp Ultra Fast test target

The test suite includes a MakeUp-like shaderpack fixture with the same style of
profile options used by MakeUp-family packs (`SHADOW_CASTING`, `V_CLOUDS`,
`BLOOM`, `REFRACTION`, `SUN_REFLECTION`, `AO`, `VOL_LIGHT`,
`MATERIAL_GLOSS`, `MOTION_BLUR`, `CHROMA_ABER`). The fixture validates that
NEXLoader produces a real Bedrock VV resource-pack structure and preserves the
Java shader source for audit.

## Status (7.8.4 shader fix)

Schemas are now validated strictly against the official documentation (see FIX_NOTES.md). Not yet verified in-game. On Mali-G52 (Moto G15) the output is a classic pack with no pbr capability and no visual shader effect. The earlier claim that all lowered settings are "native" does not guarantee a visible change in vanilla biomes (biome-level settings take precedence since 1.21.90).
