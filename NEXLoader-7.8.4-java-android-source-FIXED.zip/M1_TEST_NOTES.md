# NEXLoader 7.8.4 — M1 test notes

## What was actually verified
- Core regression suite: 80 PASS / 0 FAIL.
- The same Cubic Leaves compatibility `.mcpack` in the library is detected as an existing Bedrock resource pack and is copied as-is; it is not a valid test of Java->Bedrock resource-pack translation. Its archive contains only 3 active PNG texture files while many Java models/blockstates are retained under `nex_untranslated/`, so vanilla leaves cannot be expected to change from this already-wrapped artifact alone.
- Goblin Traders `goblintraders-neoforge-26.2-1.12.0.jar` is detected as NeoForge and remains a partial conversion. M1 now recovers `goblin_trader` and `vein_goblin_trader` entities from matching source entity textures + Java class names when direct registration recovery is unavailable. The behavior entities are emitted, but the custom Java renderer/model still requires Bedrock-native reconstruction, so this is not claimed as a fully faithful visual conversion.

## Important install identification
The Android application title is intentionally changed to:

`NEXLoader 7.8.4 • MANTENIMIENTO M1`

The Python bridge reports:

`7.8.4-M1-MAINT-2026-10-05`

If an installed APK does not show this exact M1 marker, it is not this maintenance build.


M2: el bloqueo Android de JVM de escritorio fue reemplazado por bootstrap JRE Android 17 + Chunker CLI verificado.
