# NEXLoader 7.8.4 M2 — Android JRE 17

Se corrige el bloqueo `WorldEngineUnavailable` que aparecía al convertir mundos Java en Android.

## Flujo M2

1. Detectar arquitectura Android (aarch64/x86_64).
2. Descargar el artefacto JRE 17 móvil correspondiente desde el build Android de FCL-Team.
3. Extraerlo de forma segura al almacenamiento privado de la app.
4. Verificar que contiene `release` y `bin/java`.
5. Ejecutar `java -version` y exigir Java 17+.
6. Descargar Chunker CLI 1.21.0 y verificar SHA-256.
7. Ejecutar Chunker con el JRE móvil.
8. Validar `level.dat + db/` y empaquetar `.mcworld`.

El JRE se reutiliza después del primer uso.
