# NEXLoader 7.8.4 — M3 World Engine

This patch fixes the world path that previously reported `WorldEngineUnavailable` before processing a Java world.

## What changed

`MainActivity.java` detects Java worlds by `level.dat` and routes them to `WorldEngine.java`. It no longer sends a world folder to the ModPack resolver.

`WorldEngine.java`:

- selects `arm64-v8a` or `x86_64`;
- extracts an Android OpenJDK 17 runtime into app-private storage;
- executes `java -version` as a real preflight;
- executes Chunker CLI `--help` as a second preflight;
- converts Java worlds to `BEDROCK_1_26_60`;
- accepts folders and world ZIPs;
- rejects unsafe ZIP paths and decompressed input above 2 GiB;
- verifies that Chunker produced a Bedrock `level.dat` + `db/`;
- creates a `.mcworld` output.

## Build-time supply chain

The Android Gradle script downloads the pinned Chunker 1.21.0 CLI and two Android JRE 17 archives. SHA-256 is checked before the files are packaged. The APK therefore does not depend on a Java installation already present on the phone.

## Important test status

Core test suite: 78/78 PASS. Android source lint after M3 changes: 23/23 PASS. The Android runtime itself has not been executed in this workspace because an Android SDK/Gradle environment is not installed here.

The GitHub Actions build remains the build authority for the final APK. The existing `Main.yml` was not changed by this patch.
