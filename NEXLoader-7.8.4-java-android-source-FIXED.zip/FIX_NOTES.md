# NEXLoader 7.8.4 - shader fix (FASE 1)

Verified against Microsoft Learn (Vibrant Visuals) and bedrock.dev stable 1.26.50. NOT yet tested in real Bedrock.

1. atmospherics.json: every field is now time-of-day keyframes ({"0.0": v, "1.0": v}); colors are [r,g,b] ints. Plain floats / 8-digit hex caused "Expected keyframes".
2. water.json: removed invented `sampleWidth`; format_version 1.21.120.
3. lighting/global.json: sun illuminance uses the documented dawn/dusk keyframes; schema 1.26.0 (RGB3/hex6, flash sibling of orbital, ambient needs color+illuminance).
4. Strict validator (shader_translate.vv_issues / validate_vv_pack_dir) for all 6 JSON files; delivery gate in compile_resource_pack fails if a legacy pack contains pbr or VV files.
5. GpuAllowlist.java (pure Java, tested by test_127): G71/G72/G76/G310 no longer accepted. Moto G15 (Mali-G52) -> android_legacy.
6. test_129 fails if core/ and android/.../nexcore are out of sync (tests run before sync in Main.yml).

Known limits: classic fallback changes nothing visually; since 1.21.90 vanilla per-biome VV settings take precedence over global JSON; origin of "Expected [r,g,b,a]" unconfirmed.
