# NEXLoader 7.8.4 — World Engine JRE URL fix

The Android world-engine bootstrap previously referenced a stale GitHub release URL:
`releases/download/release/...`.

The JRE 17 assets are published under the `download_jre17` release tag. NEXLoader now uses those canonical browser download URLs for `arm64-v8a` and `x86_64`, while keeping the existing SHA-256 pins.

No change is required in `Main.yml`.
