#!/usr/bin/env python3
from __future__ import annotations
import re, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ANDROID=ROOT/'android'
APP=ANDROID/'app'
MAIN=APP/'src/main/java/com/nex/loader/MainActivity.java'
PACK=APP/'src/main/java/com/nex/loader/MainActivity.java'
MANIFEST=APP/'src/main/AndroidManifest.xml'
BUILD=APP/'build.gradle'
SETTINGS=ANDROID/'settings.gradle'
WRAPPER=ANDROID/'gradle/wrapper/gradle-wrapper.properties'
WORLD=APP/'src/main/java/com/nex/loader/WorldEngine.java'

checks=[]
def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))

check('Android project files present', all(p.is_file() for p in [MAIN,MANIFEST,BUILD,SETTINGS,WRAPPER]))
main=MAIN.read_text(encoding='utf-8'); pack=MAIN.read_text(encoding='utf-8'); manifest=MANIFEST.read_text(encoding='utf-8'); build=BUILD.read_text(encoding='utf-8'); settings=SETTINGS.read_text(encoding='utf-8'); wrapper=WRAPPER.read_text(encoding='utf-8'); world=WORLD.read_text(encoding='utf-8') if WORLD.is_file() else ''
check('AGP 8.11.1 declared', "com.android.application' version '8.11.1'" in (ANDROID/'build.gradle').read_text())
check('Gradle 8.13 distribution declared', 'gradle-8.13-bin.zip' in wrapper)
check('Java 17 build environment expected', 'compileSdk 36' in build)
check('Chaquopy 17 + Python 3.13', "com.chaquo.python'" in (ANDROID/'build.gradle').read_text() and "version = '3.13'" in build)
check('compile SDK 36 / target SDK 35', 'compileSdk 36' in build and 'targetSdk 35' in build)
check('Chaquopy ABIs are 64-bit', all(x in build for x in ["'arm64-v8a'","'x86_64'"]))
check('exported launcher', 'android:exported="true"' in manifest)
check('FileProvider not exported', 'android:exported="false"' in manifest and 'FileProvider' in manifest)
check('HTTPS permission', 'android.permission.INTERNET' in manifest)
check('bounded Java input reader', 'copyLimited(' in main and 'MAX_SELECTED_INPUT_BYTES' in main)
check('bounded Android input copy', 'copyLimited(' in main and 'MAX_SELECTED_INPUT_BYTES' in main)
check('folder byte/file ceilings', 'MAX_SELECTED_TREE_FILES' in main and 'MAX_SELECTED_TREE_BYTES' in main)
check('background worker captures fetch flag', 'fetchMissingExternals = fetchExternals.isChecked' in main and 'fetchMissingExternals' in main)
# Fail the source lint if new unbounded patterns are introduced in the Android analyzer/input copy.
check('no Kotlin sources remain in Android shell', not any(APP.rglob('*.kt')))
check('bounded Java input reader', 'copyLimited(' in main and 'MAX_SELECTED_INPUT_BYTES' in main)
check('embedded Python core has io_limits', (APP/'src/main/python/nexcore/nex/io_limits.py').is_file())
core=(ROOT/'core/nex/io_limits.py').read_bytes(); android_core=(APP/'src/main/python/nexcore/nex/io_limits.py').read_bytes()
check('core ↔ Android io_limits identical', core==android_core)
check('native world engine source present', WORLD.is_file())
check('world engine pins Chunker 1.21.0', 'CHUNKER_VERSION = \"1.21.0\"' in world and 'chunker-cli-1.21.0.jar' in build)
check('world engine pins SHA-256 assets', 'chunkerSha256' in build and 'jreArm64Sha256' in build and 'jreX8664Sha256' in build)
check('world engine launches Android JRE', 'runJavaProcess' in world and 'JAVA_HOME' in world and 'LD_LIBRARY_PATH' in world)
check('world folders bypass ModPack resolver', 'isJavaWorld(src)' in main and 'if (isJavaWorld(src)) return false' in main)
failed=[x for x in checks if not x[1]]
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' '+name+(f' — {detail}' if detail else ''))
print(f'ANDROID SOURCE LINT: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: raise SystemExit(1)
