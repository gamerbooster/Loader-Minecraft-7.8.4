from __future__ import annotations

import tempfile
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from world.probe import _count_chunks, _dimension_id, _discover_dimensions
from world.chunker_engine import CHUNKER_SHA256, WorldEngineUnavailable, fetch_verified_engine, engine_status
import world.chunker_engine as ce

with tempfile.TemporaryDirectory(prefix="nex_world_maint_") as td:
    root = Path(td)
    custom = root / "dimensions" / "example" / "sky" / "region"
    custom.mkdir(parents=True)
    (custom / "r.0.0.mca").write_bytes(b"\x00" * 8192 + b"\x00" * 4096)
    (root / "tooling" / "region").mkdir(parents=True)

    assert _dimension_id(Path("dimensions/example/sky/region")) == "example:sky"
    assert _dimension_id(Path("dimensions/example/a/b/region")) == "example:a:b"
    dims = _discover_dimensions(root)
    assert [d.id for d in dims] == ["example:sky"]

    valid = bytearray(8192 + 4096)
    valid[0:3] = (2).to_bytes(3, "big")
    valid[3] = 1
    region_file = root / "valid.mca"
    region_file.write_bytes(valid)
    assert _count_chunks(region_file) == 1

    invalid = bytearray(8192 + 4096)
    invalid[0:3] = (1).to_bytes(3, "big")
    invalid[3] = 1
    invalid_file = root / "invalid.mca"
    invalid_file.write_bytes(invalid)
    assert _count_chunks(invalid_file) == 0


# Existing verified engine files are accepted without a network round-trip.
# This keeps the regression deterministic while still checking the integrity gate.
with tempfile.TemporaryDirectory(prefix="nex_engine_maint_") as td:
    destination = Path(td) / "engine.jar"
    destination.write_bytes(b"verified-test-engine")
    original_hash = ce.CHUNKER_SHA256
    original_sha = ce._sha256
    try:
        ce._sha256 = lambda _path: original_hash
        info = fetch_verified_engine(destination)
        assert info.jar == str(destination.resolve())
        assert info.sha256 == original_hash
    finally:
        ce._sha256 = original_sha

print("WORLD MAINTENANCE INTEGRITY: PASS")

# M2: Android no longer depends on a desktop JVM. The bootstrap path is tested without network.
original_platform = ce.sys.platform
original_machine = ce.platform.machine
original_download = ce._download_to
original_sha256 = ce._sha256
original_android_info = ce._android_engine_info
try:
    ce.sys.platform = "android"
    ce.platform.machine = lambda: "aarch64"
    status = engine_status(None)
    assert status["available"] is False
    assert status["runtime"] == "android"
    assert status["can_prepare"] is True

    destination = Path(tempfile.gettempdir()) / "nex_android_engine_test.jar"
    destination.write_bytes(b"bootstrap-test")
    ce._sha256 = lambda _path: CHUNKER_SHA256
    fake = ce.EngineInfo(version=ce.CHUNKER_VERSION, jar=str(destination.resolve()), java="/fake/jre/bin/java", sha256=CHUNKER_SHA256, runtime="android")
    ce._android_engine_info = lambda _path: fake
    info = fetch_verified_engine(destination)
    assert info.runtime == "android"
    assert info.version == ce.CHUNKER_VERSION
    destination.unlink(missing_ok=True)
finally:
    ce.sys.platform = original_platform
    ce.platform.machine = original_machine
    ce._download_to = original_download
    ce._sha256 = original_sha256
    ce._android_engine_info = original_android_info

print("ANDROID WORLD JVM GUARD + BOOTSTRAP: PASS")

# Desktop Java version gating must reject Java < 17 and parse legacy Java 8 correctly.
original_which = ce.shutil.which
original_run = ce.subprocess.run
try:
    ce.shutil.which = lambda name: "/fake/java" if name == "java" else None
    class FakeProc:
        def __init__(self, output):
            self.stdout = output
    ce.subprocess.run = lambda *args, **kwargs: FakeProc('openjdk version "11.0.24" 2024-07-16\n')
    assert ce._java_major("/fake/java") == 11

    ce.subprocess.run = lambda *args, **kwargs: FakeProc('openjdk version "1.8.0_472" 2025-10-21\n')
    assert ce._java_major("/fake/java") == 8
finally:
    ce.shutil.which = original_which
    ce.subprocess.run = original_run

print("JAVA VERSION PARSER/GATE: PASS")


# M2: Android world engine is now prepared with a mobile JRE instead of being hard-blocked.
original_platform = ce.sys.platform
original_machine = ce.platform.machine
try:
    ce.sys.platform = "android"
    ce.platform.machine = lambda: "aarch64"
    status = engine_status(None)
    assert status["runtime"] == "android"
    assert status["can_prepare"] is True
    assert status["android_arch"] == "aarch64"
    assert "nightly.link/FCL-Team/Android-OpenJDK-Build" in status["jre17_source"]
finally:
    ce.sys.platform = original_platform
    ce.platform.machine = original_machine

print("ANDROID JRE17 AUTO-BOOTSTRAP GATE: PASS")


heap = ce._android_heap_option()
assert heap.startswith("-Xmx") and heap.endswith("m")
print("ANDROID CHUNKER HEAP GUARD: PASS")
