from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT / "android/app/src/main/java/com/nex/loader/MainActivity.java"
WORLD = ROOT / "android/app/src/main/java/com/nex/loader/WorldEngine.java"
BUILD = ROOT / "android/app/build.gradle"

main = MAIN.read_text(encoding="utf-8")
world = WORLD.read_text(encoding="utf-8")
build = BUILD.read_text(encoding="utf-8")

assert WORLD.is_file()
assert "if (isJavaWorld(src)) return false;" in main
assert "WorldEngine.probe(MainActivity.this, src)" in main
assert "WorldEngine.convert(MainActivity.this, src, convertedRoot)" in main
assert 'CHUNKER_VERSION = "1.21.0"' in world
assert 'TARGET_FORMAT = "BEDROCK_1_26_60"' in world
assert '"-version"' in world
assert 'runJavaProcess(files.javaBin, files.jreDir, "-version")' in world
assert '"-jar", files.chunkerJar.getAbsolutePath(), "--help"' in world
assert '"-f", TARGET_FORMAT' in world
assert 'new File(root, "level.dat").isFile() && new File(root, "db").isDirectory()' in world
assert 'chunkerSha256' in build
assert 'jreArm64Sha256' in build
assert 'jreX8664Sha256' in build
assert "tasks.named('preBuild').configure" in build
print("WORLD ENGINE M3 STATIC CONTRACT: PASS")
