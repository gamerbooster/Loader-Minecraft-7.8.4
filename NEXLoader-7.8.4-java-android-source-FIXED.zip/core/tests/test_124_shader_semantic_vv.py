from pathlib import Path
import json
import tempfile
import zipfile
import sys

sys.path.insert(0, str(Path(__file__).parents[1]))

from adapters.input_detect import detect_input_kind
from adapters.resourcepack import compile_resource_pack
from adapters.shader_translate import translate_shaderpack


MAKEUP_LIKE_PROPERTIES = '''
profile.no_effects=!SHADOW_CASTING !DOF !MOTION_BLUR !BLOOM !V_CLOUDS AO=0
profile.medium=SHADOW_CASTING SHADOW_DISTANCE_SLIDER=1 REFRACTION=1 SUN_REFLECTION=1 AO=1 V_CLOUDS=1 BLOOM VOL_LIGHT MATERIAL_GLOSS
profile.high=SHADOW_CASTING V_CLOUDS BLOOM VOL_LIGHT MATERIAL_GLOSS CHROMA_ABER MOTION_BLUR
program.shadow.enabled=SHADOW_CASTING
'''

with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    sp = td / 'MakeUp-UltraFast-like.zip'
    with zipfile.ZipFile(sp, 'w') as z:
        z.writestr('pack.mcmeta', json.dumps({'pack': {'pack_format': 99, 'description': 'MakeUp Ultra Fast test'}}))
        z.writestr('shaders/shaders.properties', MAKEUP_LIKE_PROPERTIES)
        z.writestr('shaders/gbuffers_terrain.vsh', 'uniform vec3 normal; // sky light')
        z.writestr('shaders/gbuffers_terrain.fsh', 'float ao = 1.0; // ambient occlusion')
        z.writestr('shaders/gbuffers_water.vsh', 'void waterVertex(){}')
        z.writestr('shaders/gbuffers_water.fsh', 'vec3 reflection = vec3(1.0); vec3 refraction = reflection;')
        z.writestr('shaders/shadow.vsh', 'void shadowPass(){}')
        z.writestr('shaders/shadow.fsh', 'float shadowMap = 1.0;')
        z.writestr('shaders/deferred.fsh', 'vec3 material = vec3(1.0); float roughness = 1.0; float metalness = 0.0;')
        z.writestr('shaders/composite.fsh', 'vec3 bloomed = vec3(1.0); // bloom')
        z.writestr('shaders/final.fsh', 'vec3 toneMapped = vec3(1.0); // tone_map exposure')
        z.writestr('shaders/lib/volumetric_clouds.glsl', 'float cloudDensity = 1.0;')
        z.writestr('shaders/lib/fast_taa.glsl', 'vec2 taaOffset = vec2(0.0);')
        z.writestr('shaders/lib/motion_blur.glsl', 'float motion_blur_strength = 1.0;')
        z.writestr('shaders/lib/aberration.glsl', 'float chroma_aber = 1.0;')

    assert detect_input_kind(sp) == 'java_shaderpack'

    source_files = {
        'shaders/shaders.properties': MAKEUP_LIKE_PROPERTIES.encode(),
        'shaders/gbuffers_terrain.vsh': b'void main(){}',
        'shaders/gbuffers_water.fsh': b'refraction reflection water',
        'shaders/shadow.fsh': b'shadow shadowMap',
        'shaders/lib/fast_taa.glsl': b'taa temporal',
        'shaders/lib/motion_blur.glsl': b'motion_blur',
    }
    direct = translate_shaderpack(source_files, 'makeup_test', 'MakeUp Ultra Fast test')
    assert direct['conversion_method'] == 'semantic_reimplementation'
    assert direct['features']['shadows']
    assert direct['features']['water']
    assert direct['features']['volumetric_fog']
    assert direct['features']['clouds']
    assert direct['features']['taa']
    assert direct['features']['motion_blur']
    assert 'medium' in direct['profile_feature_summary']
    assert 'shadows' in direct['profile_feature_summary']['medium']
    assert direct['feature_support']['shadows'] == 'native'
    assert direct['feature_support']['water'] == 'native'
    assert direct['feature_support']['taa'] == 'not_exposed'

    out = compile_resource_pack(sp, td / 'shader_out', 'java_shaderpack')
    report = json.loads((out / 'conversion_report.json').read_text(encoding='utf-8'))
    manifest = json.loads((out / 'resource_pack' / 'manifest.json').read_text(encoding='utf-8'))

    assert report['source_kind'] == 'java_shaderpack'
    assert report['shader_activation'] == 'bedrock_vibrant_visuals_semantic_profile'
    assert report['generated_shader_files']
    assert report['shader_profile']['conversion_method'] == 'semantic_reimplementation'
    assert 'taa' in report['shader_profile']['limitations']
    assert 'motion_blur' in report['shader_profile']['limitations']
    assert 'clouds:approximate' in report['shader_profile']['limitations']
    assert manifest['capabilities'] == ['pbr']
    assert report['pbr_enabled'] is True
    assert report['manifest_capabilities'] == ['pbr']
    assert report['shader_engine'] == 'bedrock_vibrant_visuals'

    expected = [
        'lighting/global.json',
        'atmospherics/atmospherics.json',
        'color_grading/color_grading.json',
        'water/water.json',
        'shadows/global.json',
        'pbr/global.json',
        'nex_shader/profile.json',
        'nex_shader/README.txt',
    ]
    for rel in expected:
        assert (out / 'resource_pack' / rel).is_file(), rel

    lighting = json.loads((out / 'resource_pack/lighting/global.json').read_text())
    assert set(lighting['minecraft:lighting_settings']['directional_lights']) == {'orbital'}
    sun_lux = lighting['minecraft:lighting_settings']['directional_lights']['orbital']['sun']['illuminance']
    # documented dawn/dusk keyframes: bright at midday, dim at dusk, ~1 lux at midnight
    assert isinstance(sun_lux, dict) and sun_lux['0.0'] > 100000.0 and sun_lux['0.5'] <= 1.0 and sun_lux['0.25'] < sun_lux['0.0']
    assert lighting['minecraft:lighting_settings']['directional_lights']['orbital']['sun']['color'] == [255.0, 255.0, 255.0]
    assert lighting['minecraft:lighting_settings']['ambient']['color'] == '#ffffff'

    water = json.loads((out / 'resource_pack/water/water.json').read_text())
    assert water['minecraft:water_settings']['waves']['enabled'] is True
    assert water['minecraft:water_settings']['caustics']['enabled'] is True

    preserved = out / 'resource_pack/nex_untranslated/shaderpack/shaders/gbuffers_terrain.vsh'
    assert preserved.is_file()


    legacy_out = compile_resource_pack(sp, td / 'shader_legacy_out', 'java_shaderpack', 'android_legacy')
    legacy_report = json.loads((legacy_out / 'conversion_report.json').read_text(encoding='utf-8'))
    legacy_manifest = json.loads((legacy_out / 'resource_pack' / 'manifest.json').read_text(encoding='utf-8'))
    assert legacy_manifest.get('capabilities', []) == []
    assert legacy_report['pbr_enabled'] is False
    assert legacy_report['shader_engine'] == 'bedrock_classic_compatibility_fallback'
    assert not (legacy_out / 'resource_pack' / 'lighting' / 'global.json').exists()
    assert 'vibrant_visuals_gpu_not_supported' in legacy_report['shader_profile']['limitations']

    with zipfile.ZipFile(out / report['primary_pack']) as z:
        members = set(z.namelist())
        assert 'manifest.json' in members
        assert 'lighting/global.json' in members
        assert 'nex_shader/profile.json' in members

print('SHADER SEMANTIC VV M3 TEST: PASS')
