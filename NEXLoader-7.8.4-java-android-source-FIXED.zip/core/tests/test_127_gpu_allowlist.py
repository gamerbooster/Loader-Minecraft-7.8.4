"""Compile and run the real GpuAllowlist.java (pure Java, no Android deps).

Official Android Vibrant Visuals list: Adreno 640, Mali-G68, Mali-G77, Xclipse 530 or higher.
The Moto G15 (Mali-G52 MC2) must NOT be accepted so it receives the classic fallback.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / 'android' / 'app' / 'src' / 'main' / 'java' / 'com' / 'nex' / 'loader' / 'GpuAllowlist.java'
assert SRC.is_file(), SRC

CASES = [
    # (GL_RENDERER string, expected supported)
    ('Mali-G52 MC2', False),            # Moto G15 -> must fall back
    ('Mali-G52', False),
    ('Mali-G57 MC2', False),
    ('Mali-G71 MP20', False),
    ('Mali-G72 MP3', False),            # Bifrost, below the official list (old code accepted it)
    ('Mali-G76 MC4', False),            # Bifrost, below the official list (old code accepted it)
    ('Mali-G68 MC4', True),
    ('Mali-G77 MC9', True),
    ('Mali-G78 MP14', True),
    ('Mali-G610 MC6', True),
    ('Mali-G710 MC10', True),
    ('Mali-G715-Immortalis MC11', True),
    ('Immortalis-G720 MC12', True),
    ('Mali-G310', False),               # not named by the official list -> conservative
    ('Adreno (TM) 610', False),
    ('Adreno (TM) 619', False),
    ('Adreno (TM) 640', True),
    ('Adreno (TM) 730', True),
    ('Adreno (TM) 750', True),
    ('Xclipse 920', True),
    ('Xclipse 530', True),
    ('Xclipse 500', False),
    ('PowerVR Rogue GE8320', False),
    ('Intel(R) UHD Graphics', False),
    ('unknown', False),
    ('', False),
]

HARNESS = """
import com.nex.loader.GpuAllowlist;
import java.io.*;
public class Harness {
    public static void main(String[] a) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        String line;
        while ((line = r.readLine()) != null) {
            System.out.println(GpuAllowlist.isVibrantVisualsSupported(line));
        }
        System.out.println(GpuAllowlist.isVibrantVisualsSupported(null));
    }
}
"""

javac = shutil.which('javac')
java = shutil.which('java')
assert javac and java, 'javac/java are required (CI uses Temurin JDK 17)'

with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    (td / 'Harness.java').write_text(HARNESS, encoding='utf-8')
    out = td / 'out'
    out.mkdir()
    r = subprocess.run([javac, '-d', str(out), str(SRC), str(td / 'Harness.java')], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    stdin = '\n'.join(c[0] for c in CASES) + '\n'
    r = subprocess.run([java, '-cp', str(out), 'Harness'], input=stdin, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    lines = r.stdout.split()
    assert len(lines) == len(CASES) + 1, lines
    bad = []
    for (name, expected), got in zip(CASES, lines):
        if (got == 'true') != expected:
            bad.append(f'{name!r}: expected {expected}, got {got}')
    assert lines[-1] == 'false', 'null renderer must not be supported'
    assert not bad, '\n'.join(bad)

# GraphicsCompatibility must delegate to the tested class instead of keeping a second copy.
gc = (SRC.parent / 'GraphicsCompatibility.java').read_text(encoding='utf-8')
assert 'GpuAllowlist.isVibrantVisualsSupported(renderer)' in gc

print(f'GPU ALLOWLIST ({len(CASES)} renderers, compiled Java): PASS')
