from pathlib import Path
import ast
import re
import subprocess
import tempfile
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from nex.ir import Program, Operation
from nex.compiler import compile_program

with tempfile.TemporaryDirectory() as td:
    p = Program('inventoryhud_collision')
    # Same operation IDs are intentionally repeated: older NEXLoader emitted the
    # same module-level export more than once and Bedrock rejected the module.
    for _ in range(3):
        p.add(Operation('sound_play', 'inventoryhud:play', {'method':'playSound','resolved_sound_id':'minecraft:ui.button.click'}, 'convertible', 'java', 'InventoryHud.class'))
    for _ in range(3):
        p.add(Operation('scoreboard_op', 'inventoryhud:score', {'method':'getScore'}, 'convertible', 'java', 'InventoryHud.class'))
    out = compile_program(p, Path(td) / 'out')
    bridge = out / 'behavior_pack/scripts/nex_bridge.js'
    text = bridge.read_text(encoding='utf-8')
    names = re.findall(r'export function\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\(', text)
    assert len(names) == len(set(names)), names
    # Parse with Node as an ECMAScript module; this catches duplicate top-level
    # bindings before a pack reaches Minecraft.
    probe = Path(td) / 'bridge.mjs'
    probe.write_text(text, encoding='utf-8')
    cp = subprocess.run(['node', '--check', str(probe)], capture_output=True, text=True)
    assert cp.returncode == 0, cp.stderr
print('JS MODULE IDENTIFIER COLLISION REGRESSION: PASS')
