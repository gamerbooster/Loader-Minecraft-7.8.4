"""core/ and the embedded Android copy must be identical.

The test-suite (and the APK) import `nexcore` from android/app/src/main/python.
If core/ was edited without running `python tools/sync_android_core.py`, other tests
would silently exercise OLD code. Fail early with a clear message instead.
"""
import filecmp
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CORE = ROOT / 'core'
ANDROID = ROOT / 'android' / 'app' / 'src' / 'main' / 'python' / 'nexcore'
assert ANDROID.is_dir(), f'missing {ANDROID}'


def files(base: Path) -> set[str]:
    out = set()
    for p in base.rglob('*'):
        rel = p.relative_to(base)
        if not p.is_file() or '__pycache__' in rel.parts or p.suffix == '.pyc':
            continue
        if rel.parts and rel.parts[0] == 'tests':
            continue
        out.add(rel.as_posix())
    return out


a, b = files(CORE), files(ANDROID)
problems = [f'only in core: {x}' for x in sorted(a - b)] + [f'only in android: {x}' for x in sorted(b - a)]
problems += [f'differs: {x}' for x in sorted(a & b) if not filecmp.cmp(CORE / x, ANDROID / x, shallow=False)]
assert not problems, 'core and android/.../nexcore are out of sync; run `python tools/sync_android_core.py`:\n' + '\n'.join(problems[:20])
print(f'CORE <-> ANDROID SYNC ({len(a)} files identical): PASS')
