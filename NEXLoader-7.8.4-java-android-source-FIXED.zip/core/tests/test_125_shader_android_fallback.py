from pathlib import Path
import json
import tempfile
import zipfile
import sys

sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resourcepack import compile_resource_pack

with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    sp = td / 'makeup.zip'
    with zipfile.ZipFile(sp, 'w') as z:
        z.writestr('pack.mcmeta', json.dumps({'pack': {'description': 'MakeUp UltraFast test'}}))
        z.writestr('shaders/shaders.properties', 'profile.high=SHADOW_CASTING BLOOM V_CLOUDS')
        z.writestr('shaders/shadow.fsh', 'float shadowMap = 1.0;')
        z.writestr('shaders/final.fsh', 'float bloom = 1.0;')

    legacy = compile_resource_pack(sp, td / 'legacy', 'java_shaderpack', 'android_legacy')
    manifest = json.loads((legacy / 'resource_pack' / 'manifest.json').read_text())
    report = json.loads((legacy / 'conversion_report.json').read_text())
    assert manifest.get('capabilities', []) == []
    assert report['pbr_enabled'] is False
    assert report['shader_activation'] == 'classic_resource_pack_fallback_no_pbr'
    assert not (legacy / 'resource_pack' / 'lighting' / 'global.json').exists()

    vv = compile_resource_pack(sp, td / 'vv', 'java_shaderpack', 'android_vv')
    vv_manifest = json.loads((vv / 'resource_pack' / 'manifest.json').read_text())
    lighting = json.loads((vv / 'resource_pack' / 'lighting' / 'global.json').read_text())
    assert vv_manifest.get('capabilities') == ['pbr']
    settings = lighting['minecraft:lighting_settings']
    assert settings['directional_lights']['orbital']['sun']['color'] == '#ffffffff'
    assert settings['directional_lights']['flash']['color'] == '#ffffffff'
    assert settings['ambient']['color'] == '#ffffffff'

print('SHADER ANDROID FALLBACK + COLOR SCHEMA TEST: PASS')
