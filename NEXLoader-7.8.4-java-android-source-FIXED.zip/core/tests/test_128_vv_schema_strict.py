"""Strict Vibrant Visuals schema checks (official docs: learn.microsoft.com + bedrock.dev 1.26.50).

Regression guards for the real in-game errors:
  [Lighting][error] Expected keyframes / missing required field / Expected [r,g,b,a]...
  ResourcePack.incompatible.graphics.pbr
"""
import json
import sys
import tempfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resourcepack import compile_resource_pack
from adapters.shader_translate import VV_FILES, validate_vv_pack_dir, vv_issues

ATMOS = 'atmospherics/atmospherics.json'


def make_pack(td: Path, name: str, files: dict[str, str]) -> Path:
    p = td / f'{name}.zip'
    with zipfile.ZipFile(p, 'w') as z:
        z.writestr('pack.mcmeta', json.dumps({'pack': {'pack_format': 99, 'description': name}}))
        for k, v in files.items():
            z.writestr(k, v)
    return p


with tempfile.TemporaryDirectory() as td:
    td = Path(td)

    variants = {
        'minimal': {'shaders/shaders.properties': 'profile.low=!SHADOW_CASTING'},
        'water_shadow': {
            'shaders/shaders.properties': 'profile.high=SHADOW_CASTING REFRACTION V_CLOUDS BLOOM',
            'shaders/shadow.fsh': 'float shadowMap=1.0;',
            'shaders/gbuffers_water.fsh': 'vec3 reflection; vec3 refraction;',
        },
        'colored_sky': {
            'shaders/shaders.properties': 'profile.x=SHADOW_CASTING',
            'shaders/lib/sky.glsl': 'vec3 ZENITH_NIGHT_COLOR = vec3(0.02, 0.03, 0.10);\n#define HORIZON_SUNSET_COLOR_R 1.0\n#define HORIZON_SUNSET_COLOR_G 0.5\n#define HORIZON_SUNSET_COLOR_B 0.25\n',
        },
    }

    for vname, files in variants.items():
        sp = make_pack(td, vname, files)

        # --- VV-capable device: every emitted JSON must satisfy the documented schema.
        vv = compile_resource_pack(sp, td / f'{vname}_vv', 'java_shaderpack', 'android_vv')
        rp = vv / 'resource_pack'
        for rel in VV_FILES:
            assert (rp / rel).is_file(), (vname, rel)
        assert validate_vv_pack_dir(rp) == [], (vname, validate_vv_pack_dir(rp))
        manifest = json.loads((rp / 'manifest.json').read_text())
        assert manifest.get('capabilities') == ['pbr']

        atm = json.loads((rp / ATMOS).read_text())['minecraft:atmosphere_settings']
        for field in ('rayleigh_strength', 'sun_mie_strength', 'moon_mie_strength', 'sun_glare_shape',
                      'sky_zenith_color', 'sky_horizon_color'):
            assert isinstance(atm[field], dict) and atm[field], f'{vname}: {field} must be keyframes'
        for field in ('min', 'start', 'mie_start', 'max'):
            assert isinstance(atm['horizon_blend_stops'][field], dict), f'{vname}: horizon {field}'
        for kf in atm['sky_zenith_color'].values():
            assert isinstance(kf, list) and len(kf) == 3 and all(isinstance(c, int) and 0 <= c <= 255 for c in kf)

        water = json.loads((rp / 'water/water.json').read_text())['minecraft:water_settings']
        assert 'sampleWidth' not in water['waves']

        lighting = json.loads((rp / 'lighting/global.json').read_text())['minecraft:lighting_settings']
        assert set(lighting['directional_lights']) == {'orbital'}
        assert lighting['ambient']['color'] == '#ffffff' and 'illuminance' in lighting['ambient']

        # --- Moto G15 class device: no PBR capability and no VV files at all.
        legacy = compile_resource_pack(sp, td / f'{vname}_legacy', 'java_shaderpack', 'android_legacy')
        lrp = legacy / 'resource_pack'
        assert json.loads((lrp / 'manifest.json').read_text()).get('capabilities', []) == []
        for rel in VV_FILES:
            assert not (lrp / rel).exists(), (vname, 'legacy must not emit', rel)
        report = json.loads((legacy / 'conversion_report.json').read_text())
        assert report['pbr_enabled'] is False
        assert 'pbr' not in json.dumps(json.loads((lrp / 'manifest.json').read_text()).get('capabilities', []))

    # Colors declared by the Java pack must reach the Bedrock keyframes (night zenith 0.02/0.03/0.10 -> 5/8/26).
    cs = json.loads((td / 'colored_sky_vv/resource_pack' / ATMOS).read_text())['minecraft:atmosphere_settings']
    assert cs['sky_zenith_color']['0.5'] == [5, 8, 26], cs['sky_zenith_color']
    assert cs['sky_horizon_color']['0.25'] == [255, 128, 64] and cs['sky_horizon_color']['0.75'] == [255, 128, 64]
    prof = json.loads((td / 'colored_sky_vv/resource_pack/nex_shader/profile.json').read_text())
    assert prof['atmosphere_color_sources'].get('zenith_night') == 'java_pack'

# --- The exact mistakes seen in-game must be rejected by the validator.
good_atmos = {
    'format_version': '1.21.40',
    'minecraft:atmosphere_settings': {
        'description': {'identifier': 'ns:atm'},
        'rayleigh_strength': {'0.0': 1.0, '1.0': 1.0},
        'sky_zenith_color': {'0.0': [0, 125, 164], '1.0': [0, 125, 164]},
    },
}
assert vv_issues(ATMOS, good_atmos) == []
for mutate, needle in [
    (lambda d: d['minecraft:atmosphere_settings'].__setitem__('rayleigh_strength', 0.55), 'Expected keyframes'),
    (lambda d: d['minecraft:atmosphere_settings'].__setitem__('sky_zenith_color', '#5aa6ffff'), 'Expected keyframes'),
    (lambda d: d['minecraft:atmosphere_settings'].__setitem__('sky_zenith_color', {'0.0': '#5aa6ffff'}), '6-digit hex'),
    (lambda d: d['minecraft:atmosphere_settings'].__setitem__('sky_zenith_color', {'0.0': [1, 2, 3, 255]}), '[r,g,b]'),
    (lambda d: d['minecraft:atmosphere_settings'].__setitem__('sky_zenith_color', {'noon': [1, 2, 3]}), 'keyframe keys'),
    (lambda d: d['minecraft:atmosphere_settings'].__setitem__('bogus', 1), 'unknown field'),
    (lambda d: d['minecraft:atmosphere_settings']['description'].__setitem__('identifier', 'nonamespace'), 'namespaced'),
]:
    import copy
    d = copy.deepcopy(good_atmos)
    mutate(d)
    msgs = ' | '.join(vv_issues(ATMOS, d))
    assert needle in msgs, (needle, msgs)

good_light = {
    'format_version': '1.26.0',
    'minecraft:lighting_settings': {
        'description': {'identifier': 'ns:l'},
        'directional_lights': {'orbital': {'sun': {'illuminance': 1000.0, 'color': [255, 255, 255]}, 'moon': {'illuminance': 0.27, 'color': '#ffffff'}}},
        'ambient': {'illuminance': 0.02, 'color': '#ffffff'},
        'sky': {'intensity': 1.0},
    },
}
assert vv_issues('lighting/global.json', good_light) == []
import copy
for mutate, needle in [
    (lambda d: d['minecraft:lighting_settings']['ambient'].pop('color'), 'missing required field "color"'),
    (lambda d: d['minecraft:lighting_settings']['ambient'].pop('illuminance'), 'missing required field "illuminance"'),
    (lambda d: d['minecraft:lighting_settings']['ambient'].__setitem__('color', '#ffffffff'), '6-digit hex'),
    (lambda d: d['minecraft:lighting_settings']['directional_lights']['orbital']['sun'].__setitem__('color', [255, 255, 255, 255]), '[r,g,b]'),
    (lambda d: d['minecraft:lighting_settings']['directional_lights']['orbital'].__setitem__('flash', {'illuminance': 5.0, 'color': [255, 255, 255]}), 'unknown field "flash"'),
    (lambda d: d['minecraft:lighting_settings']['sky'].__setitem__('intensity', 0.0), 'outside documented range'),
    (lambda d: d['minecraft:lighting_settings']['ambient'].__setitem__('illuminance', 9.0), 'outside documented range'),
]:
    d = copy.deepcopy(good_light)
    mutate(d)
    msgs = ' | '.join(vv_issues('lighting/global.json', d))
    assert needle in msgs, (needle, msgs)

# flash is valid as a SIBLING of orbital (documented placement)
d = copy.deepcopy(good_light)
d['minecraft:lighting_settings']['directional_lights']['flash'] = {'illuminance': 5.0, 'color': [255, 255, 255]}
assert vv_issues('lighting/global.json', d) == []


# --- Delivery gate: reports its validation, and really blocks a bad pack.
import adapters.resourcepack as rpmod
with tempfile.TemporaryDirectory() as td2:
    td2 = Path(td2)
    sp = make_pack(td2, 'gate', {'shaders/shaders.properties': 'profile.x=SHADOW_CASTING'})
    ok = compile_resource_pack(sp, td2 / 'ok', 'java_shaderpack', 'android_vv')
    rep = json.loads((ok / 'conversion_report.json').read_text())
    assert rep['output_validation']['checked'] is True and rep['output_validation']['vv_schema_problems'] == []
    leg = compile_resource_pack(sp, td2 / 'leg', 'java_shaderpack', 'android_legacy')
    rep = json.loads((leg / 'conversion_report.json').read_text())
    assert rep['output_validation']['legacy_invariants'].startswith('ok'), rep['output_validation']

    real_emit = rpmod.emit_vibrant_visuals_profile
    def broken_emit(root, profile, ns):  # simulates the OLD generator: plain floats + hex8 colors, skipping its own check
        written = real_emit(root, profile, ns)
        f = Path(root) / ATMOS
        d = json.loads(f.read_text())
        d['minecraft:atmosphere_settings']['rayleigh_strength'] = 0.55
        d['minecraft:atmosphere_settings']['sky_zenith_color'] = '#5aa6ffff'
        f.write_text(json.dumps(d))
        return written
    rpmod.emit_vibrant_visuals_profile = broken_emit
    try:
        compile_resource_pack(sp, td2 / 'bad', 'java_shaderpack', 'android_vv')
        raise AssertionError('delivery gate must reject a pack with the old atmospherics mistakes')
    except ValueError as exc:
        assert 'Expected keyframes' in str(exc), exc
    finally:
        rpmod.emit_vibrant_visuals_profile = real_emit

    # A legacy device must never end up with PBR data, even if something upstream leaks it.
    def leaky_emit(root, profile, ns):
        return real_emit(root, profile, ns)
    rpmod.emit_vibrant_visuals_profile = leaky_emit
    try:
        out = compile_resource_pack(sp, td2 / 'leg2', 'java_shaderpack', 'android_legacy')
        assert not (out / 'resource_pack' / 'lighting' / 'global.json').exists()
    finally:
        rpmod.emit_vibrant_visuals_profile = real_emit

# --- Final output validator (used by the compiler/preflight) also checks NEX shader output.
from nex.output_validate import validate_compiled_output
with tempfile.TemporaryDirectory() as td3:
    td3 = Path(td3)
    sp = make_pack(td3, 'ov', {'shaders/shaders.properties': 'profile.x=SHADOW_CASTING'})
    out = compile_resource_pack(sp, td3 / 'o', 'java_shaderpack', 'android_vv')
    (out / 'behavior_pack').mkdir(exist_ok=True)  # the addon validator requires both packs to exist
    f = out / 'resource_pack' / ATMOS
    d = json.loads(f.read_text()); d['minecraft:atmosphere_settings']['rayleigh_strength'] = 0.55; f.write_text(json.dumps(d))
    errs = [e for e in validate_compiled_output(out) if 'Vibrant Visuals schema' in e]
    assert errs and 'Expected keyframes' in errs[0], errs

print('VV SCHEMA STRICT (generator + validator + legacy fallback): PASS')
