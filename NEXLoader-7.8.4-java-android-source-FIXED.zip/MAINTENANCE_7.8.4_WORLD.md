# NEXLoader 7.8.4 — mantenimiento integral / World

## Resultado

Se hizo una auditoría completa sobre el paquete `NEXLoader-7.8.4-WORLD-NEXTLEVEL-source.zip`, seguida de una segunda ejecución después de las correcciones.

- 183 archivos Python parseados con `ast`: PASS.
- Suite NEXLoader final: **79 PASS / 0 FAIL**.
- Android source lint: **18/18 PASS**.
- `VERSION CHECK`: **7.8.4 PASS**.
- Release preflight: PASS.
- Workflow YAML: parseable.
- Bash syntax: PASS.
- Core Python → Android Python sincronizado después de los cambios.
- Guard Android/ART + validación de Java 17+: PASS.

## Errores reales encontrados y corregidos

### 1. Detección de dimensiones Java
El detector trataba cualquier carpeta llamada `region/` anidada como una dimensión potencial. Ahora solo acepta Overworld, Nether, End y la estructura estándar `dimensions/<namespace>/<path>/region`. Las dimensiones personalizadas conservan su identidad `namespace:path`.

### 2. Conteo falso de chunks
El analizador contaba entradas no válidas de la tabla Anvil como chunks. Ahora valida offset, número de sectores y tamaño físico del archivo.

### 3. ZIP de mundos
Se agregó límite de miembros, detección de nombres duplicados y limpieza determinista del directorio temporal cuando la extracción falla.

### 4. Conversión de mundos dentro de Android
Se detectó una limitación funcional real: el APK usa Android/ART y no incluye una JVM Java SE 17+ capaz de ejecutar el Chunker CLI. La versión mantenida ahora lo detecta explícitamente y bloquea la conversión antes de descargar/ejecutar un JAR de escritorio; esto quedó cubierto por una regresión automática. En desktop/CI, el motor sigue pudiendo prepararse en un directorio escribible, con SHA-256, límite de 64 MiB y reemplazo atómico.

### 5. Detector de compilación Android
`tools/android_build_probe.sh` tenía un error lógico: podía detectar correctamente Gradle del sistema y luego intentar ejecutar `./gradlew`, aunque el wrapper no existiera. Ahora usa el wrapper cuando está disponible y `gradle` cuando es el fallback real.

### 6. Texto de versión de la app
La interfaz decía `1.26.52.3` aunque el identificador interno usado por el motor era `BEDROCK_1_26_50`. Ahora muestra `Bedrock 1.26.x`, evitando una afirmación de compatibilidad exacta no demostrada.

### 7. CI
Se agregó una etapa de mantenimiento que ejecuta compilación sintáctica de Python, source lint Android y `bash -n` antes de compilar el APK.

## Motor de mundos

El motor está fijado a Chunker CLI 1.21.0 y se valida por SHA-256 antes de ejecución. El código exige Java 17+ y nunca intenta ejecutar el JAR desde Android/ART como si fuera una JVM de escritorio. La release 1.21.0 de Chunker lista soporte de Bedrock 1.26.0–1.26.60 y Java 26.1–26.3, y su CLI acepta formatos `EDITION_X_Y_Z`.

## Límite que sigue explícito

Las pruebas locales comprueban la arquitectura y las validaciones de NEXLoader. No se debe considerar demostrada una conversión exitosa de **cualquier** mundo Java modificado: la preservación de entidades/estructuras y contenido moddeado depende de las capacidades del motor y de los datos concretos del mundo.


M2: el bloqueo Android de JVM de escritorio fue reemplazado por bootstrap JRE Android 17 + Chunker CLI verificado.
