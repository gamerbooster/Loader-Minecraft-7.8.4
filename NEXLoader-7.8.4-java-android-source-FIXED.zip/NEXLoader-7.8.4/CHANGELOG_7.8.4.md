# NEXLoader 7.8.4

- Hardens malformed/null/list JSON handling to prevent conversion crashes such as `NoneType.get`.
- Preserves existing tag IDs while correctly resolving nested Java function tags.
- Validates generated manifests, custom entity references and tick/load function hooks before packaging.
- Strengthens Android version validation and aligns `versionCode`/`versionName` checks.
- Explicitly provisions Android SDK 36 in the GitHub Actions APK workflow.
- Adds regression tests for malformed JSON and nested function tags.
