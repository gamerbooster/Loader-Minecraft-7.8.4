# NEXLoader 7.8.4

- Hardens malformed/null/list JSON handling to prevent conversion crashes such as `NoneType.get`.
- Preserves existing tag IDs while correctly resolving nested Java function tags.
- Validates generated manifests, custom entity references and tick/load function hooks before packaging.
- Strengthens Android version validation and aligns `versionCode`/`versionName` checks.
- Explicitly provisions Android SDK 36 in the GitHub Actions APK workflow.
- Adds regression tests for malformed JSON and nested function tags.

## World Converter Next Level

- Added dedicated Java world detection and safe `level.dat` probing.
- Added Java-world folder/ZIP safety handling, dimension discovery and chunk occupancy statistics.
- Added verified Chunker CLI integration and `.mcworld` structural validation.
- Added standalone `core/nex_world_convert.py` analyze/convert commands.
- Added Android Java-world analysis routing and explicit engine-availability reporting.
- `Main.yml` remains unchanged.
