# NEXLoader 7.8.2

- Removed optional `metadata.generated_with` from generated Bedrock manifests.
- This avoids the Bedrock 1.26.x validation error: `/metadata/generated_with` has the wrong type.
- The field is optional in the Bedrock manifest schema, so generated packs remain valid without it.
- Synced the same compiler change into the Android embedded core.
