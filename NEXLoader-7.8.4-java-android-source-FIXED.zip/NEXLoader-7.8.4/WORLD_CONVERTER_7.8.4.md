# NEXLoader 7.8.4 — World Converter Next Level

## What was added

- Java-world detection before ModPack routing.
- Safe Java `level.dat` GZip/NBT reader with depth/node/size limits.
- World probe with dimensions, regions, populated chunk slots, playerdata and modded-world signals.
- `.zip` world import with wrapper-folder normalization and archive traversal/size protection.
- Verified Chunker CLI engine adapter with SHA-256 pinning.
- `tools/fetch_world_engine.py` to fetch the pinned world engine.
- Bedrock world validator and `.mcworld` packager requiring `level.dat` and `db/`.
- `core/nex_world_convert.py` standalone `analyze` / `convert` CLI.
- Android analysis routing for Java worlds.
- Android UI updated from “JAR / ModPack only” to include Java worlds.
- New regression coverage for folder/ZIP world detection, NBT, dimensions, chunk counting, engine availability and `.mcworld` packaging.

## Engine pin

- Chunker CLI: `1.21.0`
- SHA-256: `63148e587f5ee5a2ca7ebae1079b235c82ae4d1eff8f7a8a8a3398332513dda6`
- Default target: `BEDROCK_1_26_50`

## Safety policy

NEXLoader never treats a Java Anvil folder as a Bedrock world by renaming/copying files. The Bedrock output must be structurally validated as a Bedrock LevelDB world before `.mcworld` packaging.

## Android status

Analysis works inside the embedded Python core. Full conversion requires the pinned Chunker CLI plus a Java 17 runtime. The current APK source deliberately does not claim that this desktop JVM engine is available on Android.

## Existing workflow

`Main.yml` is intentionally untouched in this upgrade.
