# NEXLoader 7.8.1 — conversion/build fixes

## Fixed

- Modern Java data-pack paths:
  - `data/<namespace>/function/**` and legacy `functions/**`
  - `recipe` and legacy `recipes`
  - `loot_table` and legacy `loot_tables`
- `assets/<namespace>/items/*.json` is now treated as an item definition only when it is a direct child.
  Nested auxiliary files such as `items/ui/**` and `items/skins/**` are ignored instead of becoming phantom Bedrock items.
- Java advancements are preserved under `behavior_pack/nex_untranslated/advancements/` with an explicit diagnostic instead of being silently dropped.
- Entity emission always creates BP entity + RP client entity + geometry + a spawn egg definition. Java datapacks which use vanilla display entities (as From The Fog does) also get an explicit emulated `herobrine` proxy entity when detected. A matched texture is reused when available; otherwise a valid placeholder texture is generated so the pack does not reference a missing PNG.
- Entity English names and spawn-egg names are emitted when an entity operation exists.
- Android embedded Python core is synchronized from `core/`.
- Added a GitHub Actions build workflow which:
  - runs from `android/` (avoids the “does not contain a Gradle build” root-directory error),
  - uses JDK 17,
  - uses Gradle 8.13,
  - installs Python 3.13 for Chaquopy bytecode compilation,
  - builds `:app:assembleDebug`.

## Tests run locally

- `compileall` core: PASS
- `compileall` Android embedded core: PASS
- `test_all.py`: PASS (6/6)
- `test_modern_datapack_paths.py`: PASS
- `test_86.py`: PASS (4/4)
- `test_65_manifest_generated_with.py`: PASS
- `test_75.py`: PASS (9/9)
- `test_76.py`: PASS (8/8)

The actual Android Gradle build was not executed in this environment because the Android SDK/Gradle installation is not available here. The workflow is configured to execute it on GitHub Actions.
