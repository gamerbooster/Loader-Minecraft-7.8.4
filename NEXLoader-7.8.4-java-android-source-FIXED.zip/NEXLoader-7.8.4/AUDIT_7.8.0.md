# NEXLoader 7.8.0 — audit report

## Software validation

- `tools/check_versions.py`: PASS
- `tools/run_tests.py`: **42/42 PASS**
- `tools/release_preflight.py`: PASS
- `tools/android_source_lint.py`: **18/18 PASS**
- Python `compileall`: PASS through release preflight
- Embedded Android Python core: synchronized byte-for-byte for the hardened `nex` I/O module

## Android build attempts in this workspace

1. Gradle wrapper invocation: blocked because `android/gradlew` is not present.
2. System Gradle invocation: blocked because no `gradle` executable is installed.
3. Official Gradle 8.13 download: blocked by workspace DNS (`services.gradle.org` cannot be resolved).
4. Android SDK discovery: no `android.jar`, `aapt2`, or `sdkmanager` was found locally.
5. Official Android CLI endpoint check: blocked by workspace DNS (`dl.google.com` cannot be resolved).

## Toolchain consistency

The project is configured for AGP 8.11.1 + Gradle 8.13 + JDK 17+ + Kotlin 2.2.20 + Chaquopy 17.0.0 + Python 3.13. AGP 8.11 documents Gradle 8.13, Build Tools 35.0.0 and JDK 17. Chaquopy 17 documents Python 3.10–3.14 and AGP 7.3–9.2.

## Remaining unverified item

A real APK is **not** claimed until `assembleDebug` completes in an environment containing the Android SDK, Gradle 8.13 and the required Maven/Chaquopy dependencies, followed by installation/runtime validation on Android.
