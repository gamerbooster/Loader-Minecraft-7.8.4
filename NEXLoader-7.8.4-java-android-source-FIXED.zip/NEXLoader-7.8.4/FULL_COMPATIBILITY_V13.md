# NEXLoader 7.8.4 — Full Compatibility Strategy V13

## Principle
NEXLoader classifies first, lowers second, repairs third, validates last. Unsupported Java-only features are retained in an audit/quarantine area instead of becoming fake Bedrock content.

## Loader families
Fabric, Forge, NeoForge and Quilt metadata are analyzed independently; mixed ModPacks are merged only after dependency resolution. Embedded Jar-in-Jar and Modrinth artifacts are bounded and integrity-checked.

## Resource packs
Java `assets/*/textures/block` maps to Bedrock `textures/blocks`, Java `item` maps to `textures/items`, and common vanilla filename aliases are normalized. Real `pack.png` is reused as `pack_icon.png`. Common block `.mcmeta` animations are translated to `textures/flipbook_textures.json`. Java-only shader/font/model metadata is preserved for diagnostics instead of being loaded into an incompatible schema.

## Shaders / PBR
Java GLSL shaderpacks are detected but not falsely advertised as executable in Bedrock. Already Bedrock-compatible PBR/Vibrant Visuals resources are preserved and `pbr` is declared only when compatible PBR assets are actually present.

## Entities
Entity registration, client entity, geometry, texture and renderer references are linked across the entire source before lowering. Missing source visuals never cause a synthetic cube or placeholder texture. High-confidence Java goals can become Bedrock behaviors. Missing custom render controllers can fall back to Bedrock's built-in `controller.render.default` only when the rest of the client entity is safe.

## Sounds
Sound assets and definitions are not considered playable merely because they exist. `playSound`-style bytecode calls are analyzed, resolved to registered sound IDs when possible, and lifecycle hurt/death sounds can be bound to the recovered entity class. Arbitrary tick/ambient sound calls are not guessed into a repeating loop.

## HUD / minimap
Jade/Jode/Waila/Hwyla-like inspection is reconstructed with Bedrock raycasts and actionbar output. Xaero-style minimap rendering is not executed as Java OpenGL code; a lightweight Bedrock-native coordinate/direction HUD is used, while the original semantics remain in the audit report. Multiple reconstructed HUD features share one actionbar aggregator.

## Performance mods
Sodium, Iris/Oculus, Lithium, FerriteCore, ModernFix, ImmediatelyFast, EntityCulling, C2ME, Krypton and similar Java engine/renderer optimizers are detected as performance profiles. Their Java bytecode is not inserted into Bedrock; gameplay/resource contributions are retained and Java-only renderer/thread/memory hooks are recorded as non-portable.

## Scoreboards
Scoreboard APIs are preserved and namespaced. Explicitly recoverable objective registrations can be initialized in Bedrock; unresolved Java argument semantics stay as generated helpers/diagnostics instead of being guessed.

## Failure-first diagnostics
Diagnostics retain source class, method, line/bytecode offset when available, capability category, severity, repairability and the affected operation. The compiler performs bounded repair/validation passes before packaging.
