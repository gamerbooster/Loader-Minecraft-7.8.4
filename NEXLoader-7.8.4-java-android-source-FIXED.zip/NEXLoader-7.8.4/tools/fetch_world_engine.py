#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import os
import tempfile
import urllib.request
from pathlib import Path

CHUNKER_VERSION = "1.21.0"
URL = f"https://github.com/HiveGamesOSS/Chunker/releases/download/{CHUNKER_VERSION}/chunker-cli-{CHUNKER_VERSION}.jar"
EXPECTED_SHA256 = "63148e587f5ee5a2ca7ebae1079b235c82ae4d1eff8f7a8a8a3398332513dda6"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(description="Fetch and verify the NEXLoader world conversion engine")
    ap.add_argument("--output", default=None, help="destination JAR path")
    ap.add_argument("--url", default=URL)
    args = ap.parse_args()
    here = Path(__file__).resolve().parents[1]
    dest = Path(args.output) if args.output else here / "tools" / "world_engine" / f"chunker-cli-{CHUNKER_VERSION}.jar"
    dest = dest.expanduser().resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=dest.name + ".", suffix=".part", dir=str(dest.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        req = urllib.request.Request(args.url, headers={"User-Agent": "NEXLoader-World-Engine-Fetcher/7.8.4"})
        with urllib.request.urlopen(req, timeout=60) as response, tmp.open("wb") as f:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                f.write(block)
        digest = sha256(tmp)
        if digest != EXPECTED_SHA256:
            raise SystemExit(f"SHA-256 mismatch: got {digest}, expected {EXPECTED_SHA256}")
        tmp.replace(dest)
        print(f"Downloaded and verified: {dest}")
        print(f"SHA-256: {digest}")
        return 0
    finally:
        tmp.unlink(missing_ok=True)


if __name__ == "__main__":
    raise SystemExit(main())
