# NEXLoader World Engine

This directory is intentionally kept free of third-party binaries in the NEXLoader source package.

The fetch script pins the Chunker CLI release and verifies its SHA-256 before it is usable by the world converter:

```text
python tools/fetch_world_engine.py
```

Pinned engine:

- Chunker CLI `1.21.0`
- SHA-256 `63148e587f5ee5a2ca7ebae1079b235c82ae4d1eff8f7a8a8a3398332513dda6`

NEXLoader then invokes the verified JAR with Java 17+ and validates the resulting Bedrock world before packaging `.mcworld`.
