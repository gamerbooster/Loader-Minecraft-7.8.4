#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
printf 'NEXLoader %s Android build probe\n' "$(cat "$ROOT/VERSION")"
status=0
if command -v java >/dev/null 2>&1; then
  java -version 2>&1 | head -1
  major="$(java -version 2>&1 | awk -F'[".]' '/version/ {print $2; exit}')"
  if [[ "${major:-0}" =~ ^[0-9]+$ ]] && (( major >= 17 )); then echo 'JAVA: PASS'; else echo 'JAVA: FAIL (JDK 17+ required)'; status=1; fi
else echo 'JAVA: FAIL (missing)'; status=1; fi
if command -v python3.13 >/dev/null 2>&1; then echo "PYTHON: PASS ($(python3.13 --version 2>&1))"; else echo 'PYTHON: FAIL (Python 3.13 missing)'; status=1; fi
if [[ -x "$ROOT/android/gradlew" ]]; then echo 'GRADLE: PASS (wrapper)'; elif command -v gradle >/dev/null 2>&1; then echo 'GRADLE: PASS (system)'; else echo 'GRADLE: BLOCKED (no wrapper/system Gradle)'; status=1; fi
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -n "$SDK" && -d "$SDK" ]]; then
  echo "ANDROID_SDK_ROOT: PASS ($SDK)"
else
  echo 'ANDROID_SDK_ROOT: BLOCKED (missing)'; status=1
fi
if [[ "$status" -eq 0 ]]; then
  cd "$ROOT/android" && ./gradlew --no-daemon assembleDebug
fi
exit "$status"
