from __future__ import annotations
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / 'core'
ANDROID = ROOT / 'android' / 'app' / 'src' / 'main' / 'python' / 'nexcore'

if not CORE.is_dir():
    raise SystemExit(f'Missing core: {CORE}')
if ANDROID.exists():
    shutil.rmtree(ANDROID)
shutil.copytree(CORE, ANDROID, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'tests'))
print(f'SYNC OK: {ANDROID}')
