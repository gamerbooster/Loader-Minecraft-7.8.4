#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/android"
if [[ -z "${ANDROID_SDK_ROOT:-}" && -n "${ANDROID_HOME:-}" ]]; then export ANDROID_SDK_ROOT="$ANDROID_HOME"; fi
if [[ -z "${ANDROID_SDK_ROOT:-}" || ! -d "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ANDROID_SDK_ROOT is not configured or does not exist." >&2
  echo "Install Android SDK platform 35 + build-tools 35.0.0, then set ANDROID_SDK_ROOT." >&2
  exit 2
fi
if [[ -z "${JAVA_HOME:-}" ]]; then
  JAVA_BIN="$(command -v java || true)"
else
  JAVA_BIN="$JAVA_HOME/bin/java"
fi
[[ -x "$JAVA_BIN" ]] || { echo "Java runtime not found." >&2; exit 5; }
JAVA_MAJOR="$("$JAVA_BIN" -version 2>&1 | awk -F'[".]' '/version/ {print $2; exit}')"
[[ "${JAVA_MAJOR:-0}" =~ ^[0-9]+$ ]] && (( JAVA_MAJOR >= 17 )) || { echo "JDK 17+ required; found ${JAVA_MAJOR:-unknown}." >&2; exit 6; }
PY313="$(command -v python3.13 || true)"
[[ -n "$PY313" ]] || { echo "Python 3.13 is required by Chaquopy 17.0 for this project." >&2; exit 7; }
if [[ -x ./gradlew ]]; then
  GRADLE=(./gradlew)
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=(gradle)
else
  echo "Gradle 8.13 not available: provide android/gradlew or a Gradle 8.13 installation." >&2
  exit 3
fi
"${GRADLE[@]}" --no-daemon assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
[[ -f "$APK" ]] || { echo "APK was not generated: $APK" >&2; exit 4; }
cp "$APK" "$ROOT/NEXLoader-${NEX_VERSION:-$(cat "$ROOT/VERSION")}-debug.apk"
echo "APK: $ROOT/NEXLoader-${NEX_VERSION:-$(cat "$ROOT/VERSION")}-debug.apk"
