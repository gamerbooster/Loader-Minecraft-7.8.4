# NEXLoader 7.8.4 — V10 deep maintenance

V10 expands the pre-conversion analysis instead of treating every ZIP as a ModPack.

## New analysis surfaces
- Java resource packs and Bedrock resource packs are detected before ModPack resolution.
- Real `pack.png`/`pack_icon.png` is preserved; no synthetic artwork is created.
- PBR/Texture Sets are preserved and Bedrock `pbr` capability is declared when appropriate.
- Java shader files are never executed as Bedrock shader code; they are preserved under `nex_untranslated` with an explicit diagnostic.
- Renderer/performance mods (Sodium, Embeddium, Rubidium, OptiFine, Iris and related optimization families) receive an explicit performance profile instead of a fake conversion.
- Deep archive and class-surface audit records textures, models, sounds, functions, worldgen, mixins, shaders, PBR, fonts, configs, risky Java APIs and renderer surfaces.
- Program and final-output preflight runs before packaging is considered successful.
- The test suite no longer depends on Pillow; CI can run the maintenance asset test with the Python standard library only.

## Bedrock limitation handling
Java renderer replacements and shader pipelines cannot be loaded into Bedrock as JVM renderer code. NEXLoader therefore preserves the evidence and produces a reconstruction plan/report rather than inventing a visual result.

Jade/Waila-style HUDs are reconstruction candidates because Bedrock scripting can raycast the block/entity under the player's view and display information. Xaero/Sodium/Iris-class client renderer features remain adaptable rather than falsely marked complete.

## V12 maintenance additions
The maintenance pipeline now runs a failure-first prediction stage and a deterministic output-repair stage before final ZIP packaging. The converter never creates synthetic visual resources. Broken client entity visuals are either repaired from a unique source-derived identifier match or quarantined under `resource_pack/nex_untranslated/quarantined_visuals/`, while behavior remains intact.

Client-only mods receive profile-specific adapters where safe. A minimap-like profile gets a coordinate/facing HUD approximation; Java renderer replacement and Java shader pipelines remain explicitly adaptable rather than being falsely claimed as native Bedrock execution.

Java resource packs now activate only PNG textures and Ogg audio in the active Bedrock payload. Unsupported raster/audio formats are preserved for audit instead of being emitted as potentially invalid assets. OptiFine-like features and Java overlay trees are reported explicitly.
