# NEXLoader Android 7.8.4

The Android module is now wired to the real Python conversion core through Chaquopy 17.0.0.

## Current flow
1. Pick a `.jar`, `.zip`, `.mrpack` or `.modpack`, or pick a ModPack directory.
2. NEX performs the offline dependency preflight.
3. `nex_android_bridge.convert()` runs the same Python converter used by the CLI.
4. The app receives the generated `.mcaddon` and conversion report.
5. A FileProvider share action exposes the generated `.mcaddon` to another application.

The source project is configured for Python 3.13, minSdk 26 and arm64-v8a/x86_64. A real signed APK is not claimed in this workspace because Android SDK/Gradle dependencies are not installed here.
