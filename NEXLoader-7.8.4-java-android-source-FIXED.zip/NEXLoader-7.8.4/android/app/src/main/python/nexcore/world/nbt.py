from __future__ import annotations

import gzip
import struct
from pathlib import Path
from typing import Any

TAG_END = 0
TAG_BYTE = 1
TAG_SHORT = 2
TAG_INT = 3
TAG_LONG = 4
TAG_FLOAT = 5
TAG_DOUBLE = 6
TAG_BYTE_ARRAY = 7
TAG_STRING = 8
TAG_LIST = 9
TAG_COMPOUND = 10
TAG_INT_ARRAY = 11
TAG_LONG_ARRAY = 12

_DEFAULT_MAX_BYTES = 16 * 1024 * 1024
_DEFAULT_MAX_DEPTH = 64
_DEFAULT_MAX_NODES = 250_000


class NBTError(ValueError):
    pass


class _Reader:
    def __init__(self, data: bytes, *, max_depth: int, max_nodes: int) -> None:
        self.data = data
        self.pos = 0
        self.max_depth = max_depth
        self.max_nodes = max_nodes
        self.nodes = 0

    def take(self, n: int) -> bytes:
        if n < 0 or self.pos + n > len(self.data):
            raise NBTError(f"truncated NBT at offset {self.pos} (need {n} bytes)")
        out = self.data[self.pos : self.pos + n]
        self.pos += n
        return out

    def u8(self) -> int:
        return self.take(1)[0]

    def i8(self) -> int:
        return struct.unpack(">b", self.take(1))[0]

    def i16(self) -> int:
        return struct.unpack(">h", self.take(2))[0]

    def i32(self) -> int:
        return struct.unpack(">i", self.take(4))[0]

    def i64(self) -> int:
        return struct.unpack(">q", self.take(8))[0]

    def f32(self) -> float:
        return struct.unpack(">f", self.take(4))[0]

    def f64(self) -> float:
        return struct.unpack(">d", self.take(8))[0]

    def string(self) -> str:
        n = struct.unpack(">H", self.take(2))[0]
        if n > len(self.data) - self.pos:
            raise NBTError("invalid NBT string length")
        raw = self.take(n)
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise NBTError("invalid UTF-8 NBT string") from exc

    def node(self) -> None:
        self.nodes += 1
        if self.nodes > self.max_nodes:
            raise NBTError("NBT node limit exceeded")

    def payload(self, tag: int, depth: int) -> Any:
        if depth > self.max_depth:
            raise NBTError("NBT maximum depth exceeded")
        self.node()
        if tag == TAG_BYTE:
            return self.i8()
        if tag == TAG_SHORT:
            return self.i16()
        if tag == TAG_INT:
            return self.i32()
        if tag == TAG_LONG:
            return self.i64()
        if tag == TAG_FLOAT:
            return self.f32()
        if tag == TAG_DOUBLE:
            return self.f64()
        if tag == TAG_STRING:
            return self.string()
        if tag == TAG_BYTE_ARRAY:
            n = self.i32()
            if n < 0 or n > len(self.data) - self.pos:
                raise NBTError("invalid NBT byte-array length")
            return self.take(n)
        if tag == TAG_INT_ARRAY:
            n = self.i32()
            if n < 0 or n > (len(self.data) - self.pos) // 4:
                raise NBTError("invalid NBT int-array length")
            return list(struct.unpack(f">{n}i", self.take(n * 4))) if n else []
        if tag == TAG_LONG_ARRAY:
            n = self.i32()
            if n < 0 or n > (len(self.data) - self.pos) // 8:
                raise NBTError("invalid NBT long-array length")
            return list(struct.unpack(f">{n}q", self.take(n * 8))) if n else []
        if tag == TAG_LIST:
            child_tag = self.u8()
            n = self.i32()
            if n < 0:
                raise NBTError("invalid NBT list length")
            return [self.payload(child_tag, depth + 1) for _ in range(n)]
        if tag == TAG_COMPOUND:
            out: dict[str, Any] = {}
            while True:
                child_tag = self.u8()
                if child_tag == TAG_END:
                    return out
                if child_tag < TAG_BYTE or child_tag > TAG_LONG_ARRAY:
                    raise NBTError(f"unknown NBT tag {child_tag}")
                name = self.string()
                out[name] = self.payload(child_tag, depth + 1)
        raise NBTError(f"unsupported NBT tag {tag}")

    def root(self) -> dict[str, Any]:
        tag = self.u8()
        if tag != TAG_COMPOUND:
            raise NBTError(f"NBT root must be a compound, got tag {tag}")
        _name = self.string()
        value = self.payload(TAG_COMPOUND, 0)
        if not isinstance(value, dict):
            raise NBTError("NBT root is not a compound")
        return value


def parse_nbt(raw: bytes, *, max_bytes: int = _DEFAULT_MAX_BYTES, max_depth: int = _DEFAULT_MAX_DEPTH,
              max_nodes: int = _DEFAULT_MAX_NODES) -> dict[str, Any]:
    if len(raw) > max_bytes:
        raise NBTError(f"NBT input too large: {len(raw)} > {max_bytes}")
    return _Reader(raw, max_depth=max_depth, max_nodes=max_nodes).root()


def read_level_dat(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    raw = p.read_bytes()
    if len(raw) > _DEFAULT_MAX_BYTES:
        raise NBTError(f"level.dat too large: {len(raw)} > {_DEFAULT_MAX_BYTES}")
    try:
        decompressed = gzip.decompress(raw)
    except OSError as exc:
        raise NBTError("level.dat is not valid GZip-compressed NBT") from exc
    return parse_nbt(decompressed)
