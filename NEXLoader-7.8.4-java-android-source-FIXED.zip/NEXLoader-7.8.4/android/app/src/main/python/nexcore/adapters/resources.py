import json, zipfile
from pathlib import Path
from pathlib import PurePosixPath
from .loader import detect
from nex.ir import Program, Operation
from analyzer.behavior import analyze_classes
from .recipes import translate_recipe
from .localization import locale_code, parse_lang_json
from .sounds import translate_sound_event
from .loot import translate_loot_table
from .functions import translate_function, function_path_info
from nex.io_limits import ArchiveLimitError, MAX_CLASS_BYTES, MAX_JSON_BYTES, read_zip_member, read_zip_member_text

def rid(path, marker):
    p=PurePosixPath(path); parts=p.parts; i=parts.index(marker)
    ns=parts[1]; rel='/'.join(parts[i+1:])
    if '.' in PurePosixPath(rel).name:
        rel=rel.rsplit('.',1)[0]
    return f'{ns}:{rel}'


def _asset_item_definition(path: str) -> bool:
    """True only for actual Java item definition JSON files.

    Modern packs may keep arbitrary JSON below assets/<namespace>/items/.
    From The Fog uses items/skins and items/ui for auxiliary data; those
    files must never become phantom Bedrock items.
    """
    parts = PurePosixPath(path).parts
    return (
        len(parts) == 4 and parts[0] == 'assets' and parts[2] == 'items'
        and parts[-1].endswith('.json')
    )


def _data_member_info(path: str, *markers: str):
    """Return (namespace, relative_path, marker) for a data-pack member."""
    parts = PurePosixPath(path).parts
    for marker in markers:
        if marker in parts:
            i = parts.index(marker)
            if i >= 2 and i + 1 < len(parts):
                rel = '/'.join(parts[i + 1:])
                if rel:
                    return parts[1], rel, marker
    return None

def model_path(ref, namespace):
    if ':' in ref: ns,path=ref.split(':',1)
    else: ns,path=namespace,ref
    return f'assets/{ns}/models/{path}.json'

def texture_path(ref, namespace, names):
    if not isinstance(ref,str): return None
    if ref.startswith('#'): return None
    ns,path=ref.split(':',1) if ':' in ref else (namespace,ref)
    path=path.removesuffix('.png')
    for ext in ('.png','.jpg','.jpeg'):
        p=f'assets/{ns}/textures/{path}{ext}'
        if p in names: return p
    # TGA is intentionally not emitted: Bedrock pack generation requires a supported raster.
    tga=f'assets/{ns}/textures/{path}.tga'
    return tga if tga in names else None

def resolve_texture(ref, textures, namespace, seen=None):
    if not isinstance(ref,str): return None
    seen=set() if seen is None else seen
    cur=ref
    while cur.startswith('#'):
        key=cur[1:]
        if key in seen: return None
        seen.add(key); cur=textures.get(key)
        if cur is None: return None
    if ':' not in cur: cur=f'{namespace}:{cur}'
    return cur


def resolve_face_texture_records(model, namespace, names):
    tex_defs=model.get('textures') or {}
    out={}
    for face in ('up','down','north','south','east','west'):
        ref=tex_defs.get(face) or tex_defs.get('side') or tex_defs.get('all')
        resolved=resolve_texture(ref, tex_defs, namespace)
        path=texture_path(resolved,namespace,names) if resolved else None
        if path:
            out[face]={'texture_id':resolved,'texture_path':path,'texture_key':PurePosixPath(path).stem}
    return out

def resolve_face_textures(model, namespace, names):
    return {face:rec['texture_key'] for face,rec in resolve_face_texture_records(model,namespace,names).items()}

def resolve_model(z,path,cache=None,stack=None):
    cache={} if cache is None else cache; stack=set() if stack is None else stack
    if path in cache: return cache[path]
    if path in stack: raise ValueError('model parent cycle')
    stack.add(path)
    data=json.loads(read_zip_member_text(z,path,MAX_JSON_BYTES))
    if not isinstance(data,dict):
        raise ValueError('model root must be a JSON object')
    parent=data.get('parent')
    if parent is not None and not isinstance(parent,str):
        parent=None
    if parent:
        base_path=model_path(parent,path.split('/')[1])
        if base_path in z.namelist():
            base=resolve_model(z,base_path,cache,stack); merged=dict(base)
            tex=dict(base.get('textures',{})); tex.update(data.get('textures',{}))
            if tex: merged['textures']=tex
            for k,v in data.items():
                if k not in ('parent','textures'): merged[k]=v
            data=merged
    stack.remove(path); cache[path]=data; return data

def model_to_geo(namespace, model_rid, model):
    if not isinstance(model,dict): return None
    elems=model.get('elements',[])
    if not isinstance(elems,list): return None
    if not elems: return None
    cubes=[]
    for e in elems:
        if not isinstance(e,dict):
            continue
        a=e.get('from',[0,0,0]); b=e.get('to',[16,16,16])
        if not (isinstance(a,list) and len(a)==3 and isinstance(b,list) and len(b)==3):
            continue
        c={'origin':a,'size':[b[i]-a[i] for i in range(3)]}
        if 'uv' in e: c['uv']=e['uv']
        rot=e.get('rotation')
        if isinstance(rot,dict):
            axis=rot.get('axis','y'); angle=float(rot.get('angle',0)); origin=rot.get('origin',[8,8,8])
            c['rotation']=[angle if axis=='x' else 0, angle if axis=='y' else 0, angle if axis=='z' else 0]
            c['pivot']=origin
        cubes.append(c)
    identifier='geometry.'+namespace+'_'+model_rid.split(':',1)[1].replace('/','_').replace('-','_')
    return {'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':identifier,'texture_width':16,'texture_height':16},'bones':[{'name':'root','pivot':[0,0,0],'cubes':cubes}]}]},identifier

def parse_selector(selector):
    # Java selector: "facing=north,lit=true". Keep it lossless and deterministic.
    result=[]
    if selector=='': return result
    for part in selector.split(','):
        if '=' not in part: return None
        k,v=part.split('=',1)
        if not k or not v: return None
        result.append((k,v))
    return result

def build_ir(jar):
    info=detect(jar)
    meta=info['mods'][0] if info['mods'] else {'id':'unknown','version':'1.0.0','loader':'unknown'}
    p=Program(meta['id'], version=meta.get('version') or '1.0.0')
    loader=info['loader']
    with zipfile.ZipFile(jar) as z:
        names=set(z.namelist()); model_cache={}; models={}; blockstates={}; textures={}
        # Fabric/Quilt entrypoints and Mixin configs are behavior metadata rather than
        # Bedrock resources. Record them in NEX-IR so later lowerers can reconstruct
        # server/client startup hooks without silently dropping them.
        for ep_kind, raw_eps in sorted((meta.get('entrypoints') or {}).items()):
            eps = raw_eps if isinstance(raw_eps,list) else [raw_eps]
            for idx, raw_ep in enumerate(eps):
                value = raw_ep.get('value') if isinstance(raw_ep,dict) else raw_ep
                adapter = raw_ep.get('adapter') if isinstance(raw_ep,dict) else None
                if not value: continue
                status='adaptable'
                p.add(Operation('entrypoint',f'{meta["id"]}:{ep_kind}:{idx}',{
                    'kind':ep_kind,'value':str(value),'adapter':adapter,'loader':loader
                },status,loader,'fabric.mod.json' if loader=='fabric' else 'quilt.mod.json'))

        mixin_refs=[]
        raw_mixins = meta.get('mixins') or []
        if isinstance(raw_mixins,str): raw_mixins=[raw_mixins]
        for ref in raw_mixins:
            if isinstance(ref,str): mixin_refs.append(ref)
        for n in sorted(names):
            if not n.endswith('.mixins.json') and not n.endswith('mixins.json'): continue
            try: md=json.loads(read_zip_member_text(z,n,MAX_JSON_BYTES))
            except Exception as e:
                p.warn('MIXIN_CONFIG_PARSE_FAILED',str(e),n); continue
            if not isinstance(md,dict): continue
            package=str(md.get('package') or '')
            for group in ('mixins','client','server','common'):
                vals=md.get(group,[])
                if isinstance(vals,str): vals=[vals]
                if not isinstance(vals,list): continue
                for value in vals:
                    if not isinstance(value,str): continue
                    cls=(package+'.'+value) if package else value
                    status='adaptable'
                    p.add(Operation('mixin',f'{n}:{group}:{cls}',{
                        'config':n,'group':group,'class':cls,'required':bool(md.get('required',False)),
                        'minVersion':md.get('minVersion'),'compatibilityLevel':md.get('compatibilityLevel')
                    },status,loader,n))
            mixin_refs.append(n)
        if mixin_refs:
            p.diagnostics.append({'code':'MIXIN_METADATA','configs':sorted(set(mixin_refs))})

        for n in sorted(names):
            if '/textures/' in n and n.lower().endswith(('.png','.jpg','.jpeg','.tga')):
                textures[n]=read_zip_member(z,n)
        for n in names:
            if '/blockstates/' in n and n.endswith('.json'):
                try: blockstates[n]=json.loads(read_zip_member_text(z,n,MAX_JSON_BYTES))
                except Exception as e: p.warn('BLOCKSTATE_PARSE_FAILED',str(e),n)
            elif '/models/' in n and n.endswith('.json'): models[n]=None
        for n in sorted(models):
            try: models[n]=resolve_model(z,n,model_cache)
            except Exception as e: p.warn('MODEL_RESOLVE_FAILED',str(e),n)
        item_jsons={}
        for n in sorted(names):
            if _asset_item_definition(n):
                try:
                    item_jsons[n]=json.loads(read_zip_member_text(z,n,MAX_JSON_BYTES))
                except Exception as e:
                    p.warn('ITEM_DEF_PARSE_FAILED',str(e),n)
            elif n.startswith('assets/') and '/items/' in n and n.endswith('.json'):
                p.warn('ITEM_AUX_JSON_IGNORED',
                       'Nested JSON below assets/<namespace>/items/ is auxiliary data, not an item definition',
                       n)

        # Java data-pack tags are collected here. The compiler can attach tags to
        # custom Bedrock definitions while preserving vanilla-targeted tags as
        # adaptable metadata rather than emitting an unsupported global tag file.
        for n in sorted(names):
            if '/tags/' in n and n.endswith('.json'):
                try: data=json.loads(read_zip_member_text(z,n,MAX_JSON_BYTES))
                except Exception as e:
                    p.warn('TAG_PARSE_FAILED',str(e),n); continue
                parts=PurePosixPath(n).parts; ns=parts[1] if len(parts)>1 else meta.get('id','mod')
                marker=parts.index('tags'); rel='/'.join(parts[marker+1:]).rsplit('.',1)[0]
                category=parts[marker+1] if marker+1 < len(parts) else 'unknown'
                # Java tag identifiers omit the tag category directory, e.g.
                # data/ns/tags/function/common.json -> ns:common, while other
                # categories keep their path, e.g. blocks/machines.
                tag_rel='/'.join(rel.split('/')[1:]) if category=='function' and '/' in rel else rel
                tag_id=f'{ns}:{tag_rel or PurePosixPath(rel).name}'
                vals=data.get('values',[]) if isinstance(data,dict) else []
                p.add(Operation('register_tag',tag_id,{'category':category,'values':vals,'replace':bool(data.get('replace',False)) if isinstance(data,dict) else False,'namespace':ns,'path':rel},'convertible',loader,n))
        for n,data in sorted(blockstates.items()):
            ns=n.split('/')[1]; state_id=rid(n,'blockstates')
            if not isinstance(data,dict):
                p.warn('BLOCKSTATE_ROOT_INVALID','Blockstate JSON root must be an object',n); continue
            vals=data.get('variants',{})
            if not isinstance(vals,dict):
                p.warn('BLOCKSTATE_VARIANTS_INVALID','Blockstate variants must be an object',n); continue
            variant_defs=[]
            all_convertible=True
            for selector,raw in sorted(vals.items()):
                entries=raw if isinstance(raw,list) else [raw]
                for idx,v in enumerate(entries):
                    if isinstance(v,str): model_ref=v; opts={}
                    elif isinstance(v,dict): model_ref=v.get('model'); opts=v
                    else: model_ref=None; opts={}
                    parsed=parse_selector(selector)
                    rec={'selector':selector,'state_pairs':parsed,'model':model_ref,'x':opts.get('x',0),'y':opts.get('y',0),'uvlock':bool(opts.get('uvlock',False))}
                    if parsed is None or not model_ref:
                        rec['status']='adaptable'; all_convertible=False; variant_defs.append(rec); continue
                    mp=model_path(model_ref,ns)
                    if mp not in models or models[mp] is None:
                        rec['status']='adaptable'; rec['missing_model']=mp; all_convertible=False; variant_defs.append(rec); continue
                    m=models[mp]
                    if not isinstance(m,dict):
                        rec['status']='adaptable'; rec['missing_model']=mp; all_convertible=False; variant_defs.append(rec); continue
                    raw_textures=m.get('textures')
                    texdefs=raw_textures if isinstance(raw_textures,dict) else {}
                    texref=texdefs.get('all')
                    tex=resolve_texture(texref,texdefs,ns) if texref else None
                    tp=texture_path(tex,ns,names) if tex else None
                    face_records=resolve_face_texture_records(m,ns,names)
                    if not tp and face_records:
                        # A Java model may define only per-face textures. Use the first
                        # available face as the Bedrock default and retain the full face map.
                        first=face_records[sorted(face_records)[0]]
                        tex, tp = first['texture_id'], first['texture_path']
                    if not tp:
                        fallback_values=[v for v in texdefs.values() if isinstance(v,str)]
                        rec['status']='adaptable'; rec['missing_texture']=tex or (sorted(fallback_values)[0] if fallback_values else None); all_convertible=False
                    else:
                        rec['status']='convertible'; rec['texture_path']=tp; rec['texture_key']=PurePosixPath(tp).stem; rec['texture_id']=tex
                        rec['face_textures']={face:r['texture_key'] for face,r in face_records.items()}
                        rec['face_texture_records']=face_records
                        try:
                            geo=model_to_geo(ns,model_ref,m)
                        except (TypeError,ValueError,OverflowError) as exc:
                            p.warn('MODEL_GEO_INVALID',f'Invalid geometry data: {exc}',n)
                            geo=None
                        if geo: rec['geometry_data']=geo[0]; rec['geometry']=geo[1]
                        else: rec['geometry']='minecraft:geometry.full_block'
                    variant_defs.append(rec)
            p.add(Operation('register_blockstate',state_id,{
                'variants':variant_defs,
                'selectors':sorted(vals.keys()),
            },'convertible' if all_convertible and bool(vals) else 'adaptable',loader,n))
            # Keep only a single native block operation for the identifier; compiler creates permutations from variants.
            p.add(Operation('register_block',state_id,{
                'variants':variant_defs,
            },'convertible' if all_convertible and bool(variant_defs) else 'adaptable',loader,n))

        for n in sorted(names):
            if _asset_item_definition(n):
                item_id=rid(n,'items'); ns=n.split('/')[1]; short=item_id.split(':',1)[1].split('/')[-1]; icon=None; item_model=None; model_layers=[]
                raw_item=item_jsons.get(n) or {}
                model_ref=None
                if isinstance(raw_item,dict):
                    model_field=raw_item.get('model')
                    if isinstance(model_field,str): model_ref=model_field
                    elif isinstance(model_field,dict): model_ref=model_field.get('model')
                model_ref=model_ref or f'{ns}:item/{short}'
                mp=model_path(model_ref,ns)
                model=models.get(mp)
                if isinstance(model,dict):
                    raw_texmap=model.get('textures')
                    texmap=raw_texmap if isinstance(raw_texmap,dict) else {}
                    for key in sorted(texmap):
                        if key.startswith('layer') and isinstance(texmap[key],str):
                            resolved=resolve_texture(texmap[key],texmap,ns)
                            if resolved: model_layers.append(resolved)
                    if model_layers:
                        first=model_layers[0]
                        tp=texture_path(first,ns,names)
                        if tp:
                            icon={'path':tp,'key':PurePosixPath(tp).stem,'texture_id':first,'model_ref':model_ref,'layers':model_layers}
                            if len(model_layers)>1:
                                p.warn('ITEM_MULTILAYER_REDUCED',f'{item_id}: {len(model_layers)} Java item layers; Bedrock atlas currently uses layer0.',n)
                if icon is None:
                    for ext in ('.png','.jpg','.jpeg'):
                        cand=f'assets/{ns}/textures/item/{short}{ext}'
                        if cand in names:
                            icon={'path':cand,'key':PurePosixPath(cand).stem,'texture_id':f'{ns}:item/{short}'}
                            break
                p.add(Operation('register_item',item_id,{'icon':icon,'model_ref':model_ref,'model_layers':model_layers},'convertible',loader,n))
        # Java worldgen resources are indexed before functions. We preserve
        # the complete source JSON and emit a reconstruction plan rather than
        # pretending Java generator schemas are Bedrock-compatible.
        try:
            from .worldgen import scan_worldgen
            scan_worldgen(z, meta, p)
        except Exception as e:
            p.warn('WORLDGEN_SCAN_FAILED', str(e))

        # Detect Java display entities before translating functions so selectors
        # can target the generated Bedrock proxy entity.
        display_refs=[]
        for dn in sorted(names):
            if not dn.endswith('.mcfunction'):
                continue
            try:
                body=read_zip_member_text(z,dn,MAX_JSON_BYTES).lower()
            except Exception:
                continue
            if any(token in body for token in ('item_display','block_display','text_display','interaction')):
                display_refs.append(dn)
        display_proxy_id=None
        if display_refs:
            ns=meta.get('id','mod')
            proxy_id=f'{ns}:herobrine' if (
                'herobrine' in ns.lower() or 'watching' in ns.lower() or 'fog' in ns.lower() or
                any('herobrine' in (read_zip_member_text(z,dn,MAX_JSON_BYTES).lower())
                    for dn in display_refs[:8])
            ) else f'{ns}:display_proxy'
            display_proxy_id=proxy_id
            if not any(o.op=='register_entity' for o in p.operations):
                p.add(Operation('register_entity',proxy_id,{
                    'emulation':'java_display_entity_proxy',
                    'source_functions':display_refs[:32],
                    'entity_builder_detected':False
                },'emulated','java_datapack',display_refs[0]))
                p.warn('DISPLAY_ENTITY_PROXY',f'Java display entities detected; emitted Bedrock proxy {proxy_id}',display_refs[0])

        # Java data-pack functions -> Bedrock behavior-pack functions.
        # Unknown commands are kept as adaptable metadata rather than executed silently.
        for n in sorted(names):
            if not n.endswith('.mcfunction'):
                continue
            finfo=function_path_info(n, meta.get('id','mod'))
            if not finfo:
                p.warn('FUNCTION_PATH_INVALID',f'Unable to derive function namespace/path: {n}',n)
                continue
            namespace, rel=finfo
            try:
                text=read_zip_member_text(z,n,MAX_JSON_BYTES)
            except UnicodeDecodeError as e:
                p.add(Operation('register_function',f'{namespace}:{rel}',{'namespace':namespace,'path':rel,'text_raw_hex':read_zip_member(z,n,MAX_JSON_BYTES).hex()},'adaptable',loader,n))
                p.warn('FUNCTION_UTF8_INVALID',str(e),n)
                continue
            status,translated,diags=translate_function(text, display_proxy_id)
            args={'namespace':namespace,'path':rel,'text':translated,'diagnostics':diags}
            p.add(Operation('register_function',f'{namespace}:{rel}',args,status,loader,n))
            for d in diags:
                p.warn(d.get('code','FUNCTION_TRANSLATION'),json.dumps(d,ensure_ascii=False),n)

        # Modern data packs use singular directory names. Advancements do not
        # have a direct Bedrock system, but preserving them avoids silent loss.
        for n in sorted(names):
            if '/advancement/' in n and n.endswith('.json'):
                try:
                    data=json.loads(read_zip_member_text(z,n,MAX_JSON_BYTES))
                    adv_info=_data_member_info(n,'advancement')
                    if adv_info:
                        ns,rel,_=adv_info
                        aid=f'{ns}:{rel.rsplit(".",1)[0]}'
                        p.add(Operation('register_advancement',aid,
                                        {'java_json':data,'path':rel},
                                        'adaptable',loader,n))
                except Exception as e:
                    p.warn('ADVANCEMENT_PARSE_FAILED',str(e),n)

        for n in sorted(names):
            if ('/loot_tables/' in n or '/loot_table/' in n) and n.endswith('.json'):
                try: data=json.loads(read_zip_member_text(z,n,MAX_JSON_BYTES))
                except Exception as e:
                    p.warn('LOOT_PARSE_FAILED',str(e),n); continue
                parts=PurePosixPath(n).parts
                ns=parts[1] if len(parts)>1 else meta.get('id','mod')
                marker=next(i for i,part in enumerate(parts) if part in {'loot_table','loot_tables'})
                rel='/'.join(parts[marker+1:]).rsplit('.',1)[0]
                loot_id=f'{ns}:{rel}'
                status,bedrock,diags=translate_loot_table(data,loot_id)
                args={'java_json':data,'bedrock_json':bedrock,'translation_diagnostics':diags,'path':'/'.join(parts[marker+1:])}
                p.add(Operation('register_loot_table',loot_id,args,status,loader,n))
                for d in diags: p.warn(d.get('code','LOOT_TRANSLATION'),json.dumps(d,ensure_ascii=False),n)

        for n in sorted(names):
            if ('/recipes/' in n or '/recipe/' in n) and n.endswith('.json'):
                try: data=json.loads(read_zip_member_text(z,n,MAX_JSON_BYTES))
                except Exception as e:
                    p.warn('RECIPE_PARSE_FAILED',str(e),n); continue
                recipe_marker='recipe' if '/recipe/' in n else 'recipes'
                recipe_id=rid(n,recipe_marker)
                rstatus,bedrock,diags=translate_recipe(data,recipe_id)
                args={'java_json':data,'bedrock_json':bedrock,'translation_diagnostics':diags,'type':data.get('type') if isinstance(data,dict) else None}
                p.add(Operation('register_recipe',recipe_id,args,rstatus,loader,n))
                for d in diags: p.warn(d.get('code','RECIPE_TRANSLATION'),json.dumps(d,ensure_ascii=False),n)
        for n,b in sorted(textures.items()):
            p.add(Operation('register_texture',rid(n,'textures'),{'path':n,'bytes_hex':b.hex()},'convertible',loader,n))

        # Java localization JSON -> Bedrock texts/*.lang.
        for n in sorted(names):
            if '/lang/' in n and n.endswith('.json'):
                stem=PurePosixPath(n).stem
                locale=locale_code(stem)
                if not locale:
                    p.warn('LANG_UNSUPPORTED_LOCALE',f'Unsupported locale stem: {stem}',n); continue
                try:
                    values=parse_lang_json(read_zip_member(z,n,MAX_JSON_BYTES))
                    if not isinstance(values,dict):
                        p.warn('LANG_ROOT_INVALID','Language JSON root must be an object',n); continue
                    p.add(Operation('register_language',f'{info["mods"][0]["id"]}:{locale}',{'locale':locale,'values':values},'convertible',loader,n))
                except Exception as e:
                    p.warn('LANG_PARSE_FAILED',str(e),n)

        # Java assets/<ns>/sounds.json -> one Bedrock sound_definitions registry.
        for n in sorted(names):
            if n.startswith('assets/') and n.endswith('/sounds.json'):
                try: sound_data=json.loads(read_zip_member_text(z,n,MAX_JSON_BYTES))
                except Exception as e:
                    p.warn('SOUND_PARSE_FAILED',str(e),n); continue
                if not isinstance(sound_data,dict):
                    p.warn('SOUND_ROOT_INVALID','sounds.json root must be an object',n); continue
                ns=n.split('/')[1]
                for event_name,event in sorted(sound_data.items()):
                    if not isinstance(event,dict): continue
                    translated,diag=translate_sound_event(ns,event_name,event,names)
                    if translated:
                        translated['assets_bytes_hex']={asset: read_zip_member(z,asset).hex() for asset in translated.get('assets',[]) if asset in names}
                        p.add(Operation('register_sound',translated['identifier'],translated,'convertible',loader,n))
                    elif diag:
                        p.add(Operation('register_sound',f'{ns}:{event_name}',{'java_event':event_name,'diagnostic':diag},'adaptable',loader,n))
                        p.warn(diag.get('code','SOUND_TRANSLATION'),str(diag),n)
        classes=[n for n in names if n.endswith('.class')]
        if classes:
            entries=[]; skipped=0
            for class_name in sorted(classes):
                try:
                    entries.append((class_name,read_zip_member(z,class_name,MAX_CLASS_BYTES)))
                except ArchiveLimitError as exc:
                    skipped += 1
                    p.warn('CLASSFILE_SKIPPED_LIMIT',str(exc),class_name)
            if entries:
                semantic_diagnostics=[]
                semantic_ops=analyze_classes(entries, semantic_diagnostics, meta.get('id'))
                for diagnostic in semantic_diagnostics:
                    p.warn(diagnostic.get('code','CLASSFILE_PARSE_FAILED'), diagnostic.get('message','Unable to parse class file'), diagnostic.get('source'))
                p.operations.extend(semantic_ops)
            else:
                semantic_ops=[]
            p.warn('CLASSFILES_ANALYZED',f'{len(entries)} Java class files scanned; {skipped} skipped by safety limit; {len(semantic_ops)} semantic capability/event operations recovered.')
    p.diagnostics.append({'code':'LOADER_DETECTED','loader':info['loader'],'mods':info['mods']})
    return info,p
