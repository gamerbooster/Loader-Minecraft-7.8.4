from __future__ import annotations
from collections import Counter


def predict_failures(program):
    """Predict conversion failures before output packaging.

    This is intentionally conservative: it never fabricates a resource just to
    make the score look better. It identifies missing links, client-only inputs,
    platform blockers and things the lowerer can repair automatically.
    """
    ops = list(program.operations or [])
    by_id = {o.id: o for o in ops}
    entities = [o for o in ops if o.op == 'register_entity' and o.status in {'convertible', 'emulated', 'adaptable'}]
    visuals = [o for o in ops if o.op == 'register_entity_visual']
    visual_ids = {o.id for o in visuals}
    failures = []
    repairs = []

    def add(code, severity, message, source=None, repair=None):
        rec = {'code': code, 'severity': severity, 'message': message}
        if source: rec['source'] = source
        if repair:
            rec['repairable'] = True
            repairs.append({'code': code, 'action': repair})
        failures.append(rec)

    for e in entities:
        if e.id not in visual_ids:
            add(
                'ENTITY_VISUAL_UNRESOLVED', 'warning',
                f'{e.id} has behavior registration but no source-derived client visual yet.',
                e.source,
                'preserve_behavior_and_quarantine_invalid_visual_instead_of_generating_fake_assets',
            )

    for v in visuals:
        args = v.args or {}
        geo = args.get('geometry') or (args.get('raw_geometry') or args.get('geometry_data'))
        tex = args.get('texture_id') or args.get('texture_path')
        if args.get('geometry_data') and not args.get('geometry'):
            add('ENTITY_GEOMETRY_ID_MISSING', 'warning', f'{v.id} contains geometry data but no explicit identifier.', v.source,
                'derive_identifier_from_embedded_geometry_description')
        if geo and not tex:
            add('ENTITY_TEXTURE_UNRESOLVED', 'warning', f'{v.id} has geometry but no linked real texture.', v.source,
                'keep_geometry_and_do_not_invent_placeholder_texture')
        if tex and not geo:
            add('ENTITY_GEOMETRY_UNRESOLVED', 'warning', f'{v.id} has a texture but no linked real geometry.', v.source,
                'keep_behavior_and_do_not_invent_placeholder_geometry')

    for o in ops:
        if o.status == 'incompatible':
            add('INCOMPATIBLE_FEATURE', 'error', f'{o.op}:{o.id} cannot execute literally in Bedrock.', o.source,
                'preserve_diagnostic_and_continue_safe_lowering')
        elif o.status == 'adaptable':
            add('ADAPTABLE_FEATURE', 'warning', f'{o.op}:{o.id} requires Bedrock-side reconstruction.', o.source,
                'lower_safe_subset_and_archive_source_metadata')
        elif o.status == 'unknown':
            add('UNKNOWN_FEATURE', 'warning', f'{o.op}:{o.id} has no confident lowering yet.', o.source,
                'archive_operation_and_keep_other_safe_operations')

    # Resource-level break risks.
    for o in ops:
        if o.op == 'register_item' and not o.args.get('icon'):
            add('ITEM_ICON_MISSING', 'warning', f'{o.id} has no source-derived item icon.', o.source,
                'emit_item_only_when_a_real_texture_or_model_icon_can_be_resolved')
        if o.op == 'register_block':
            for v in o.args.get('variants', []) or []:
                if v.get('missing_texture'):
                    add('BLOCK_TEXTURE_MISSING', 'warning', f'{o.id} variant references missing texture {v.get("missing_texture")}.', o.source,
                        'skip_invalid_variant_and_keep_valid_variants')
                if v.get('missing_model'):
                    add('BLOCK_MODEL_MISSING', 'warning', f'{o.id} variant references missing model {v.get("missing_model")}.', o.source,
                        'skip_invalid_variant_and_keep_valid_variants')

    unresolved = [d for d in getattr(program, 'diagnostics', []) if d.get('code') in {
        'FUNCTION_REFERENCE_UNRESOLVED', 'FUNCTION_PATH_INVALID', 'ENTITY_GEOMETRY_GEO_INVALID',
        'MIXIN_CONFIG_PARSE_FAILED', 'SOUND_PARSE_FAILED', 'SOUND_TRANSLATION'
    }]
    for d in unresolved[:300]:
        add(d.get('code', 'ANALYZER_DIAGNOSTIC'), 'warning', str(d.get('message') or d.get('details') or d), d.get('source'))

    world_ops = sum(1 for o in ops if o.op in {
        'register_block', 'register_item', 'register_entity', 'register_recipe',
        'register_loot_table', 'register_function', 'register_worldgen', 'event',
        'spawn_body', 'register_advancement'
    })
    client_ops = sum(1 for o in ops if o.op in {
        'feature_profile', 'performance_profile', 'mixin', 'entrypoint', 'hud_overlay',
        'ui_screen', 'keybind'
    })
    if world_ops == 0 and client_ops:
        add('CLIENT_SURFACE_ONLY', 'warning',
            'No directly spawnable world content was recovered; input appears client/UI/renderer/optimization focused.',
            repair='generate_bedrock_native_adapter_when_a_safe_profile_exists')

    counts = Counter(f['severity'] for f in failures)
    # Deduplicate deterministic diagnostics.
    dedup=[]; seen=set()
    for f in failures:
        key=(f.get('code'), f.get('message'), f.get('source'))
        if key in seen: continue
        seen.add(key); dedup.append(f)
    repair_keys=[]; seen_rep=set()
    for r in repairs:
        key=(r.get('code'), r.get('action'))
        if key in seen_rep: continue
        seen_rep.add(key); repair_keys.append(r)

    severity_rank={'error':0,'warning':1,'info':2}
    dedup.sort(key=lambda x:(severity_rank.get(x['severity'],9), x.get('code',''), x.get('message',''), x.get('source','')))
    repair_keys.sort(key=lambda x:(x.get('code',''), x.get('action','')))
    return {
        'analysis': 'failure-first',
        'predicted_error_count': counts.get('error', 0),
        'predicted_warning_count': counts.get('warning', 0),
        'repairable_count': len(repair_keys),
        'world_content_operations': world_ops,
        'client_surface_operations': client_ops,
        'findings': dedup[:1500],
        'repair_actions': repair_keys[:500],
    }
