from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path
from typing import Iterable


def find_bedrock_world_root(output_dir: str | Path) -> Path | None:
    root = Path(output_dir)
    if (root / "level.dat").is_file() and (root / "db").is_dir():
        return root
    matches: list[Path] = []
    for level in root.rglob("level.dat"):
        parent = level.parent
        if (parent / "db").is_dir():
            matches.append(parent)
    if not matches:
        return None
    matches.sort(key=lambda p: (len(p.parts), str(p)))
    return matches[0]


def validate_bedrock_world_root(root: str | Path) -> list[str]:
    p = Path(root)
    errors: list[str] = []
    if not (p / "level.dat").is_file():
        errors.append("Bedrock world level.dat missing")
    if not (p / "db").is_dir():
        errors.append("Bedrock world db/ LevelDB directory missing")
    if (p / "db").is_dir() and not any((p / "db").iterdir()):
        errors.append("Bedrock world db/ is empty")
    return errors


def package_mcworld(world_root: str | Path, output_path: str | Path) -> Path:
    root = Path(world_root).resolve()
    errors = validate_bedrock_world_root(root)
    if errors:
        raise ValueError("cannot package invalid Bedrock world: " + "; ".join(errors))
    out = Path(output_path).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    temp = out.with_suffix(out.suffix + ".part")
    if temp.exists():
        temp.unlink()
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(root).as_posix()
            z.write(path, rel)
    temp.replace(out)
    # Final integrity check: an mcworld must be a valid ZIP and contain the Bedrock world root markers.
    with zipfile.ZipFile(out) as z:
        bad = z.testzip()
        if bad:
            out.unlink(missing_ok=True)
            raise ValueError(f"generated .mcworld contains corrupt member: {bad}")
        names = set(z.namelist())
        if "level.dat" not in names or not any(n == "db/" or n.startswith("db/") for n in names):
            out.unlink(missing_ok=True)
            raise ValueError("generated .mcworld is missing level.dat or db/")
    return out
