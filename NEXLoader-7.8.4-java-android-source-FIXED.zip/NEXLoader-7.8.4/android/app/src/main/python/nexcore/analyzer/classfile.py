import struct

INVOKES={182:'invokevirtual',183:'invokespecial',184:'invokestatic',185:'invokeinterface',186:'invokedynamic'}

def u2(b,p): return struct.unpack_from('>H',b,p)[0]
def u4(b,p): return struct.unpack_from('>I',b,p)[0]

def utf(cp,i):
    e=cp[i] if i and i<len(cp) else None
    return e[1] if e and e[0]=='Utf8' else ''

def class_name(cp,i):
    e=cp[i]
    return utf(cp,e[1]).replace('/','.') if e and e[0]==7 else ''

def ref(cp,i):
    e=cp[i] if i and i<len(cp) else None
    if not e or e[0] not in (9,10,11): return None
    ce=cp[e[1]]; nt=cp[e[2]]
    if not ce or not nt or nt[0]!=12: return None
    return {'owner':utf(cp,ce[1]),'name':utf(cp,nt[1]),'descriptor':utf(cp,nt[2])}

def method_handle(cp,i):
    e=cp[i] if i and i<len(cp) else None
    if not e or e[0]!=15: return None
    return ref(cp,e[2])

def parse(data):
    if data[:4]!=b'\xca\xfe\xba\xbe': raise ValueError('not Java class')
    pos=8; cpc=u2(data,pos); pos+=2; cp=[None]*cpc; i=1
    while i<cpc:
        tag=data[pos]; pos+=1
        if tag==1:
            n=u2(data,pos); pos+=2; cp[i]=('Utf8',data[pos:pos+n].decode('utf-8','replace')); pos+=n
        elif tag==3:
            value=struct.unpack_from('>i',data,pos)[0]; pos+=4; cp[i]=(3,value)
        elif tag==4:
            value=struct.unpack_from('>f',data,pos)[0]; pos+=4; cp[i]=(4,value)
        elif tag==5:
            value=struct.unpack_from('>q',data,pos)[0]; pos+=8; cp[i]=(5,value); i+=1
        elif tag==6:
            value=struct.unpack_from('>d',data,pos)[0]; pos+=8; cp[i]=(6,value); i+=1
        elif tag in (7,8,16,19,20): cp[i]=(tag,u2(data,pos)); pos+=2
        elif tag in (9,10,11,12,17,18): cp[i]=(tag,u2(data,pos),u2(data,pos+2)); pos+=4
        elif tag==15: cp[i]=(15,data[pos],u2(data,pos+1)); pos+=3
        else: raise ValueError(f'unknown constant pool tag {tag}')
        i+=1
    access,this_i,super_i=u2(data,pos),u2(data,pos+2),u2(data,pos+4); pos+=6
    ic=u2(data,pos); pos+=2+2*ic
    fc=u2(data,pos); pos+=2
    fields=[]
    for _ in range(fc):
        fa,ni,di,ac=u2(data,pos),u2(data,pos+2),u2(data,pos+4),u2(data,pos+6); pos+=8
        attrs=[]
        for __ in range(ac):
            ai=u2(data,pos); n=u4(data,pos+2); pos+=6
            attrs.append({'name':utf(cp,ai),'raw':data[pos:pos+n]}); pos+=n
        fields.append({'name':utf(cp,ni),'descriptor':utf(cp,di),'access':fa,'attributes':attrs})
    methods=[]; mc=u2(data,pos); pos+=2
    for _ in range(mc):
        ma,ni,di,ac=u2(data,pos),u2(data,pos+2),u2(data,pos+4),u2(data,pos+6); pos+=8
        code=None
        method_attrs=[]
        for __ in range(ac):
            ai=u2(data,pos); n=u4(data,pos+2); pos+=6; name=utf(cp,ai); raw=data[pos:pos+n]
            method_attrs.append({'name':name,'raw':raw})
            if name=='Code':
                q=0; max_stack,max_locals=u2(raw,q),u2(raw,q+2); clen=u4(raw,q+4); q+=8
                code_bytes=raw[q:q+clen]; q+=clen; ex=u2(raw,q); q+=2+8*ex; sub=u2(raw,q); q+=2
                line_numbers=[]
                for ___ in range(sub):
                    sub_name_idx=u2(raw,q); sn=u4(raw,q+2); q+=6
                    sub_raw=raw[q:q+sn]; q+=sn
                    sub_name=utf(cp,sub_name_idx)
                    if sub_name=='LineNumberTable' and sn>=2:
                        try:
                            lp=0; ln=u2(sub_raw,lp); lp+=2
                            for ____ in range(ln):
                                if lp+4>len(sub_raw): break
                                start_pc=u2(sub_raw,lp); line=u2(sub_raw,lp+2); lp+=4
                                line_numbers.append((start_pc,line))
                        except Exception:
                            pass
                line_numbers.sort()
                code={'max_stack':max_stack,'max_locals':max_locals,'bytes':code_bytes,'line_numbers':line_numbers}
            pos += n
        methods.append({'name':utf(cp,ni),'descriptor':utf(cp,di),'code':code,'access':ma,'attributes':method_attrs})
    ac=u2(data,pos); pos+=2; class_attrs=[]
    for _ in range(ac):
        ai=u2(data,pos); n=u4(data,pos+2); pos+=6; class_attrs.append({'name':utf(cp,ai),'raw':data[pos:pos+n]}); pos+=n
    source_file=None
    for attr in class_attrs:
        if attr.get('name')=='SourceFile':
            raw=attr.get('raw',b'')
            if len(raw)>=2:
                try: source_file=utf(cp,u2(raw,0))
                except Exception: source_file=None
    parsed={'major':u2(data,6),'cp':cp,'this':class_name(cp,this_i),'super':class_name(cp,super_i),'fields':fields,'methods':methods,'class_attrs':class_attrs,'source_file':source_file}
    parsed['annotations']=class_annotations(parsed)
    for mm in parsed['methods']:
        mm['annotations']=method_annotations(mm,cp)
        mm['parameter_types']=method_parameter_class_names(mm.get('descriptor'))
    return parsed

def _skip_element_value(raw, pos):
    """Skip a JVM annotation element_value recursively and return the next offset."""
    tag=chr(raw[pos]); pos+=1
    if tag in 'BCDFIJSZs': return pos+2
    if tag=='e': return pos+4
    if tag=='c': return pos+2
    if tag=='@':
        pos += 2
        pairs=u2(raw,pos); pos+=2
        for _ in range(pairs):
            pos += 2
            pos = _skip_element_value(raw,pos)
        return pos
    if tag=='[':
        n=u2(raw,pos); pos+=2
        for _ in range(n): pos=_skip_element_value(raw,pos)
        return pos
    return pos


def annotation_types(raw, cp):
    """Return annotation type descriptors from RuntimeVisible/InvisibleAnnotations."""
    out=[]
    try:
        pos=0
        count=u2(raw,pos); pos+=2
        for _ in range(count):
            if pos+4>len(raw): break
            type_desc=utf(cp,u2(raw,pos)); pos+=2
            out.append(type_desc)
            pairs=u2(raw,pos); pos+=2
            for __ in range(pairs):
                if pos+2>len(raw): return out
                pos+=2
                pos=_skip_element_value(raw,pos)
    except Exception:
        return out
    return out


def method_parameter_class_names(descriptor):
    """Return object parameter internal names from a JVM method descriptor."""
    if not isinstance(descriptor,str) or '(' not in descriptor or ')' not in descriptor:
        return []
    body=descriptor.split('(',1)[1].split(')',1)[0]
    out=[]; i=0
    while i < len(body):
        c=body[i]
        if c in 'BCDFIJSZ': i+=1; continue
        if c=='[':
            while i<len(body) and body[i]=='[': i+=1
            if i<len(body) and body[i]=='L':
                j=body.find(';',i)
                if j<0: break
                out.append(body[i+1:j]); i=j+1; continue
            i+=1; continue
        if c=='L':
            j=body.find(';',i)
            if j<0: break
            out.append(body[i+1:j]); i=j+1; continue
        i+=1
    return out


def method_annotations(method, cp):
    out=[]
    for attr in method.get('attributes',[]) or []:
        if attr.get('name') in {'RuntimeVisibleAnnotations','RuntimeInvisibleAnnotations'}:
            out.extend(annotation_types(attr.get('raw',b''),cp))
    return sorted(set(out))


def class_annotations(parsed):
    out=[]
    for attr in parsed.get('class_attrs',[]) or []:
        if attr.get('name') in {'RuntimeVisibleAnnotations','RuntimeInvisibleAnnotations'}:
            out.extend(annotation_types(attr.get('raw',b''), parsed['cp']))
    return sorted(set(out))


def bootstrap_methods(parsed):
    a=next((x for x in parsed['class_attrs'] if x['name']=='BootstrapMethods'),None)
    if not a: return []
    raw=a['raw']; pos=0; n=u2(raw,pos); pos+=2; out=[]
    for _ in range(n):
        mr=u2(raw,pos); ac=u2(raw,pos+2); pos+=4; args=[u2(raw,pos+2*j) for j in range(ac)]; pos+=2*ac
        out.append({'method_ref':mr,'arguments':args})
    return out

def name_type(cp, index):
    e=cp[index] if index and index < len(cp) else None
    if not e or e[0]!=12: return None
    return {'name':utf(cp,e[1]),'descriptor':utf(cp,e[2])}

def invokedynamic_callsite(parsed, index):
    cp=parsed['cp']; e=cp[index] if index and index < len(cp) else None
    if not e or e[0]!=18: return None
    return name_type(cp,e[2])

def invokedynamic_target(parsed, index):
    cp=parsed['cp']; e=cp[index] if index and index < len(cp) else None
    if not e or e[0]!=18: return None
    bs=bootstrap_methods(parsed); bi=e[1]
    if bi>=len(bs): return None
    for arg in bs[bi]['arguments']:
        h=method_handle(cp,arg)
        if h and h.get('owner') not in ('java/lang/invoke/LambdaMetafactory','java/lang/invoke/MethodHandles$Lookup','java/lang/invoke/StringConcatFactory'):
            return h
    return None

def constant_value(cp, index):
    e=cp[index] if index and index < len(cp) else None
    if not e: return None
    if e[0] in (3,4,5,6): return e[1]
    if e[0]==8: return utf(cp,e[1])
    return None


def code_scan(parsed, method):
    code=method.get('code')
    if not code: return []
    b=code['bytes']; cp=parsed['cp']; out=[]; pc=0; last_indy=None; last_goal_ctor=None; strings=[]; constants=[]; fields=[]
    fixed={16:2,17:3,18:2,19:3,20:3,21:2,22:2,23:2,24:2,25:2,54:2,55:2,56:2,57:2,58:2,84:1,132:3,
           153:3,154:3,155:3,156:3,157:3,158:3,159:3,160:3,161:3,162:3,163:3,164:3,165:3,166:3,167:3,168:3,
           178:3,179:3,180:3,181:3,187:3,188:2,189:3,192:3,193:3,197:4,198:3,199:3,200:5,201:5}
    while pc<len(b):
        op=b[pc]; size=1; target=None
        if op==18 and pc+1<len(b):
            idx=b[pc+1]; e=cp[idx]; size=2
            value=constant_value(cp,idx)
            if e and e[0]==8: strings.append(utf(cp,e[1]))
            if value is not None: constants.append(value)
        elif op==19 and pc+2<len(b):
            idx=u2(b,pc+1); e=cp[idx]; size=3
            value=constant_value(cp,idx)
            if e and e[0]==8: strings.append(utf(cp,e[1]))
            if value is not None: constants.append(value)
        elif op==170:
            pad=(4-((pc+1)&3))&3; base=pc+1+pad; low=struct.unpack_from('>i',b,base+4)[0]; high=struct.unpack_from('>i',b,base+8)[0]; size=1+pad+12+4*(high-low+1)
        elif op==171:
            pad=(4-((pc+1)&3))&3; base=pc+1+pad; np=u4(b,base+4); size=1+pad+8+8*np
        elif 3 <= op <= 8:
            constants.append(op - 3); size=1
        elif op==16 and pc+1<len(b):
            constants.append(struct.unpack_from('>b',b,pc+1)[0]); size=2
        elif op==17 and pc+2<len(b):
            constants.append(struct.unpack_from('>h',b,pc+1)[0]); size=3
        elif op==20 and pc+2<len(b):
            idx=u2(b,pc+1); value=constant_value(cp,idx); size=3
            if value is not None: constants.append(value)
        elif op in (178,179,180,181) and pc+2<len(b):
            idx=u2(b,pc+1); target=ref(cp,idx); size=3
            line=0
            for start_pc,ln in code.get('line_numbers',[]):
                if start_pc <= pc: line=ln
                else: break
            if target:
                fields.append(target)
                out.append({'owner':target.get('owner'),'name':target.get('name'),'descriptor':target.get('descriptor'),
                            'offset':pc,'line':line or None,'invoke':{178:'getstatic',179:'putstatic',180:'getfield',181:'putfield'}[op],
                            'kind':'field','near_strings':strings[-6:],'constant_hints':constants[-8:],
                            'near_fields':[dict(x) for x in fields[-4:]],
                            'method_name':method.get('name'),'method_descriptor':method.get('descriptor')})
        elif op==196: size=6 if b[pc+1]==132 else 4
        elif op in INVOKES:
            idx=u2(b,pc+1)
            target=invokedynamic_target(parsed,idx) if op==186 else ref(cp,idx)
            size=5 if op in (185,186) else 3
            if op==186 and target is None:
                # invokedynamic is not necessarily a lambda callback. Java compilers
                # also emit StringConcatFactory call sites and other bootstrap forms
                # whose bootstrap arguments contain no MethodHandle. Preserve the
                # call-site metadata without treating it as a callback target.
                callsite=invokedynamic_callsite(parsed,idx) or {}
                line=0
                for start_pc,ln in code.get('line_numbers',[]):
                    if start_pc <= pc: line=ln
                    else: break
                item={'owner':None,'name':callsite.get('name'),'descriptor':callsite.get('descriptor'),
                      'offset':pc,'line':line or None,'invoke':INVOKES[op],'kind':'invokedynamic',
                      'unresolved_bootstrap':True,'near_strings':strings[-4:], 'constant_hints':constants[-8:],
                      'near_fields':[dict(x) for x in fields[-4:]],
                      'method_name':method.get('name'),'method_descriptor':method.get('descriptor')}
                last_indy=None
                out.append(item)
            elif target:
                line=0
                for start_pc,ln in code.get('line_numbers',[]):
                    if start_pc <= pc: line=ln
                    else: break
                item={'owner':target.get('owner'),'name':target.get('name'),'descriptor':target.get('descriptor'),
                      'offset':pc,'line':line or None,'invoke':INVOKES[op], 'near_strings':strings[-4:],'constant_hints':constants[-8:],
                      'near_fields':[dict(x) for x in fields[-4:]],
                      'method_name':method.get('name'),'method_descriptor':method.get('descriptor')}
                if op==186:
                    item['kind']='invokedynamic'; item['callback_target']=target
                    last_indy=target
                else:
                    item['kind']='invoke'
                    if target.get('name') == '<init>' and 'goal/' in (target.get('owner') or '').lower():
                        last_goal_ctor={'owner':target.get('owner'),'name':target.get('name'),'descriptor':target.get('descriptor')}
                    if 'GoalSelector' in (target.get('owner') or '') and target.get('name') == 'addGoal' and last_goal_ctor:
                        item['goal_constructor']=last_goal_ctor
                        nums=[x for x in constants[-8:] if isinstance(x,int)]
                        if nums:
                            item['goal_priority_hint']=nums[-1]
                        last_goal_ctor=None
                    if target.get('name') in ('register','subscribe','addListener','addGenericListener') and last_indy:
                        item['callback_target']=last_indy
                        last_indy=None
                out.append(item)
        else:
            size=fixed.get(op,1)
        if pc+size>len(b): raise ValueError('truncated bytecode')
        pc+=size
    return out

def analyze(data):
    p=parse(data)
    return { 'major':p['major'], 'this':p['this'], 'methods':[{'name':m['name'],'descriptor':m['descriptor'],'calls':code_scan(p,m)} for m in p['methods']] }
