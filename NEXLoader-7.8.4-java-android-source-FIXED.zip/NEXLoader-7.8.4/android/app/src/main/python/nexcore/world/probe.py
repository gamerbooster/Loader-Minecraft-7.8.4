from __future__ import annotations

import json
import re
import tempfile
import zipfile
from dataclasses import asdict, dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Iterator

from .nbt import NBTError, read_level_dat

_MAX_ZIP_TOTAL = 2 * 1024 * 1024 * 1024
_MAX_ZIP_MEMBER = 256 * 1024 * 1024
_MAX_ZIP_FILES = 100_000


@dataclass
class DimensionStats:
    id: str
    path: str
    regions: int = 0
    chunks: int = 0
    entities_regions: int = 0
    poi_regions: int = 0


@dataclass
class WorldInfo:
    kind: str = "java_world"
    root: str = ""
    name: str = ""
    data_version: int | None = None
    legacy_version: int | None = None
    seed: int | None = None
    spawn: dict[str, int] = field(default_factory=dict)
    dimensions: list[DimensionStats] = field(default_factory=list)
    player_files: int = 0
    playerdata_files: int = 0
    session_lock_present: bool = False
    modded: bool = False
    mod_signals: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    source_archive: bool = False

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["dimensions"] = [asdict(x) for x in self.dimensions]
        return d


def _safe_member(name: str) -> PurePosixPath:
    n = str(name).replace("\\", "/").lstrip("/")
    p = PurePosixPath(n)
    if any(part in {"", ".", ".."} for part in p.parts):
        raise ValueError(f"unsafe archive path: {name!r}")
    return p


def _logical_root_from_zip(names: list[str]) -> str | None:
    files = [str(_safe_member(n)) for n in names if not str(n).endswith("/")]
    if not files:
        return None
    if "level.dat" in files and "region" in {x.split("/")[0] for x in files}:
        return ""
    candidates = [f for f in files if f.endswith("/level.dat")]
    roots = {f[:-len("/level.dat")] for f in candidates}
    for root in sorted(roots, key=len):
        prefix = root + "/" if root else ""
        if prefix + "region/" in {x for x in files if x.endswith("/")}:  # uncommon; usually omitted
            return root
        if any(f.startswith(prefix + "region/") for f in files):
            return root
    return None


def _extract_world_zip(src: Path) -> tuple[Path, tempfile.TemporaryDirectory]:
    temp = tempfile.TemporaryDirectory(prefix="nex_java_world_")
    out = Path(temp.name)
    total = 0
    with zipfile.ZipFile(src) as z:
        infos = z.infolist()
        if len(infos) > _MAX_ZIP_FILES:
            temp.cleanup()
            raise ValueError(f"world archive contains too many members: {len(infos)} > {_MAX_ZIP_FILES}")
        root = _logical_root_from_zip(z.namelist())
        if root is None:
            temp.cleanup()
            raise ValueError("ZIP does not contain a Java world (level.dat + region/)")
        prefix = root + "/" if root else ""
        seen_members: set[str] = set()
        try:
            for info in infos:
                if info.is_dir():
                    continue
                member = str(_safe_member(info.filename))
                if not member.startswith(prefix):
                    continue
                if member in seen_members:
                    raise ValueError(f"duplicate world archive member: {member}")
                seen_members.add(member)
                rel = member[len(prefix):]
                if not rel or rel.startswith("../"):
                    continue
                if info.file_size > _MAX_ZIP_MEMBER:
                    raise ValueError(f"world archive member exceeds safety limit: {member}")
                total += info.file_size
                if total > _MAX_ZIP_TOTAL:
                    raise ValueError("world archive exceeds total expanded safety limit")
                dst = out / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src_f, dst.open("wb") as dst_f:
                    remaining = info.file_size
                    while remaining:
                        chunk = src_f.read(min(1024 * 1024, remaining))
                        if not chunk:
                            raise ValueError(f"truncated world archive member: {member}")
                        dst_f.write(chunk)
                        remaining -= len(chunk)
            return out, temp
        except Exception:
            temp.cleanup()
            raise


def _locate_world_root(path: Path) -> tuple[Path, tempfile.TemporaryDirectory | None, bool]:
    if path.is_dir():
        if (path / "level.dat").is_file() and (path / "region").is_dir():
            return path, None, False
        # A common import case is selecting an enclosing folder that contains the real save.
        candidates = []
        for child in path.iterdir():
            if child.is_dir() and (child / "level.dat").is_file() and (child / "region").is_dir():
                candidates.append(child)
        if len(candidates) == 1:
            return candidates[0], None, False
        raise ValueError("folder is not a Java world root (need level.dat and region/)")
    if path.suffix.lower() == ".zip":
        root, temp = _extract_world_zip(path)
        return root, temp, True
    raise ValueError("unsupported Java world input; use a world folder or .zip")


def _region_files(region_dir: Path) -> Iterator[Path]:
    if region_dir.is_dir():
        yield from sorted(region_dir.glob("r.*.*.mca"))


def _count_chunks(region_file: Path) -> int:
    try:
        size = region_file.stat().st_size
        with region_file.open("rb") as f:
            header = f.read(8192)
        if len(header) < 8192 or size < 8192:
            return 0
        sectors = size // 4096
        chunks = 0
        for i in range(0, 4096, 4):
            # First three bytes are sector offset; fourth is sector count.
            offset = int.from_bytes(header[i:i + 3], "big")
            count = header[i + 3]
            if count and offset >= 2 and offset + count <= sectors:
                chunks += 1
        return chunks
    except OSError:
        return 0


def _dimension_id(rel: Path) -> str:
    text = rel.as_posix()
    if text == "region":
        return "minecraft:overworld"
    if text == "DIM-1/region":
        return "minecraft:the_nether"
    if text == "DIM1/region":
        return "minecraft:the_end"
    if text.startswith("dimensions/") and text.endswith("/region"):
        parts = text.split("/")
        if len(parts) >= 4:
            return parts[1] + ":" + ":".join(parts[2:-1])
    head = text[:-len("/region")] if text.endswith("/region") else text
    return head.replace("/", ":") or "minecraft:overworld"


def _discover_dimensions(root: Path) -> list[DimensionStats]:
    result: list[DimensionStats] = []
    seen: set[str] = set()
    for region_dir in sorted(root.rglob("region")):
        try:
            rel = region_dir.relative_to(root)
        except ValueError:
            continue
        valid_layout = (
            rel.as_posix() in {"region", "DIM-1/region", "DIM1/region"}
            or (rel.parts and rel.parts[0] == "dimensions" and len(rel.parts) >= 4)
        )
        if not valid_layout:
            continue
        dim = _dimension_id(rel)
        if dim in seen:
            continue
        seen.add(dim)
        regions = list(_region_files(region_dir))
        entity_dir = region_dir.parent / "entities"
        poi_dir = region_dir.parent / "poi"
        result.append(DimensionStats(
            id=dim,
            path="" if rel.as_posix() == "region" else rel.parent.as_posix(),
            regions=len(regions),
            chunks=sum(_count_chunks(x) for x in regions),
            entities_regions=len(list(entity_dir.glob("r.*.*.mca"))) if entity_dir.is_dir() else 0,
            poi_regions=len(list(poi_dir.glob("r.*.*.mca"))) if poi_dir.is_dir() else 0,
        ))
    return result


def _find_int(compound: dict[str, Any], key_names: tuple[str, ...]) -> int | None:
    for key in key_names:
        value = compound.get(key)
        if isinstance(value, int) and not isinstance(value, bool):
            return int(value)
    return None


def _find_string(compound: dict[str, Any], key_names: tuple[str, ...]) -> str | None:
    for key in key_names:
        value = compound.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def _signal_modded(root: Path, nbt: dict[str, Any]) -> tuple[bool, list[str]]:
    signals: list[str] = []
    # World saves normally do not contain the installed mods themselves, but some
    # launchers/exports do. Treat these as strong signals, not proof of complete conversion.
    for rel, label in (("mods", "mods/"), ("config", "config/"), ("defaultconfigs", "defaultconfigs/")):
        if (root / rel).exists():
            signals.append(label)
    jar_candidates = list(root.glob("*.jar"))
    mods_dir = root / "mods"
    if mods_dir.is_dir():
        jar_candidates.extend(mods_dir.glob("*.jar"))
    for marker in jar_candidates[:256]:
        try:
            name = marker.name.lower()
            if any(token in name for token in ("forge", "neoforge", "fabric", "quilt")):
                signals.append(marker.name)
        except OSError:
            pass
    text_values: list[str] = []
    def walk(v: Any, depth: int = 0) -> None:
        if depth > 5 or len(text_values) >= 2000:
            return
        if isinstance(v, str):
            text_values.append(v.lower())
        elif isinstance(v, dict):
            for child in v.values():
                walk(child, depth + 1)
        elif isinstance(v, list):
            for child in v[:256]:
                walk(child, depth + 1)
    walk(nbt)
    for needle in ("forge", "neoforge", "fabric", "quilt"):
        if any(needle in s for s in text_values):
            signals.append(f"level.dat:{needle}")
    dedup = []
    seen = set()
    for s in signals:
        if s not in seen:
            seen.add(s); dedup.append(s)
    return bool(dedup), dedup[:32]


def probe_java_world(path: str | Path) -> WorldInfo:
    src = Path(path).expanduser().resolve()
    root, temp, archived = _locate_world_root(src)
    try:
        try:
            nbt = read_level_dat(root / "level.dat")
        except (OSError, NBTError) as exc:
            raise ValueError(f"unable to read Java level.dat: {exc}") from exc
        data = nbt.get("Data") if isinstance(nbt.get("Data"), dict) else nbt
        if not isinstance(data, dict):
            data = {}
        name = _find_string(data, ("LevelName", "levelName")) or root.name
        data_version = _find_int(data, ("DataVersion", "dataVersion"))
        legacy_version = _find_int(data, ("Version", "version"))
        seed = _find_int(data, ("RandomSeed", "seed", "Seed"))
        spawn = {}
        for key, out_key in (("SpawnX", "x"), ("SpawnY", "y"), ("SpawnZ", "z")):
            v = _find_int(data, (key,))
            if v is not None:
                spawn[out_key] = v
        dimensions = _discover_dimensions(root)
        modded, mod_signals = _signal_modded(root, nbt)
        warnings: list[str] = []
        if not dimensions:
            warnings.append("No region directory was found beyond the world root marker.")
        if modded:
            warnings.append("Modded-world signals detected; custom blocks/entities may require NEX adapters and engine-side mappings.")
        warnings.append("Java entities/player inventories are not assumed to have 1:1 Bedrock parity; verify the conversion report.")
        return WorldInfo(
            root=str(root), name=name, data_version=data_version, legacy_version=legacy_version,
            seed=seed, spawn=spawn, dimensions=dimensions,
            player_files=len(list((root / "playerdata").glob("*.dat"))) if (root / "playerdata").is_dir() else 0,
            playerdata_files=len(list((root / "playerdata").glob("*.dat"))) if (root / "playerdata").is_dir() else 0,
            session_lock_present=(root / "session.lock").is_file(),
            modded=modded, mod_signals=mod_signals, warnings=warnings,
            source_archive=archived,
        )
    finally:
        if temp is not None:
            temp.cleanup()


# Internal helper for the converter: it needs the stable temporary world path for the
# duration of the external engine process.
def materialize_java_world(path: str | Path) -> tuple[Path, Any, bool]:
    src = Path(path).expanduser().resolve()
    return _locate_world_root(src)
