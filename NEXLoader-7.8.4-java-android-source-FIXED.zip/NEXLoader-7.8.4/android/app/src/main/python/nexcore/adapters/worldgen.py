from __future__ import annotations
import json
from pathlib import PurePosixPath
from nex.ir import Operation
from nex.io_limits import MAX_JSON_BYTES, read_zip_member_text

WORLDGEN_ROOTS = {
    'dimension': ('data', 'dimension'),
    'biome': ('data', 'worldgen', 'biome'),
    'configured_feature': ('data', 'worldgen', 'configured_feature'),
    'placed_feature': ('data', 'worldgen', 'placed_feature'),
    'feature_rule': ('data', 'worldgen', 'placed_feature'),
    'noise': ('data', 'worldgen', 'noise'),
    'template_pool': ('data', 'worldgen', 'template_pool'),
    'processor_list': ('data', 'worldgen', 'processor_list'),
    'structure': ('data', 'worldgen', 'structure'),
    'structure_set': ('data', 'worldgen', 'structure_set'),
}


def _kind(name: str):
    parts = PurePosixPath(name).parts
    if len(parts) < 4 or parts[0] != 'data':
        return None
    if parts[2] == 'dimension':
        return 'dimension'
    if len(parts) >= 4 and parts[2] == 'worldgen':
        return parts[3]
    return None


def _identifier(name: str, kind: str, default_ns: str):
    parts = PurePosixPath(name).parts
    ns = parts[1] if len(parts) > 1 else default_ns
    try:
        if kind == 'dimension':
            idx = parts.index('dimension')
        else:
            idx = parts.index('worldgen') + 1
    except ValueError:
        return f'{ns}:{PurePosixPath(name).stem}'
    rel = '/'.join(parts[idx + 1:])
    rel = rel.rsplit('.', 1)[0] if '.' in rel.rsplit('/', 1)[-1] else rel
    return f'{ns}:{rel}'


def _java_dimension_plan(data: dict):
    known = {}
    mapping = {
        'ambient_light': 'ambient_light',
        'has_skylight': 'has_skylight',
        'has_ceiling': 'has_ceiling',
        'ultrawarm': 'ultrawarm',
        'natural': 'natural',
        'coordinate_scale': 'coordinate_scale',
        'bed_works': 'bed_works',
        'respawn_anchor_works': 'respawn_anchor_works',
        'min_y': 'min_y',
        'height': 'height',
        'logical_height': 'logical_height',
    }
    for k, out in mapping.items():
        if k in data:
            known[out] = data[k]
    if isinstance(data.get('effects'), str):
        known['effects'] = data['effects']
    return known


def _as_block_id(state):
    """Recover a plain block identifier from a Java BlockState-like object."""
    if isinstance(state, str):
        return state if not state.startswith('#') else None
    if not isinstance(state, dict):
        return None
    block_id = state.get('Name') or state.get('name') or state.get('block')
    if isinstance(block_id, str) and ':' in block_id and not block_id.startswith('#'):
        return block_id
    return None


def _plain_block_list(predicate):
    if not isinstance(predicate, dict):
        return None
    blocks = predicate.get('blocks')
    if isinstance(blocks, str):
        blocks = [blocks]
    if not isinstance(blocks, list) or not blocks:
        return None
    result=[]
    for b in blocks:
        if not isinstance(b, str) or b.startswith('#') or ':' not in b:
            return None
        result.append(b)
    return sorted(set(result))


def _translate_ore(identifier, cfg):
    targets = cfg.get('targets')
    if not isinstance(targets, list) or not targets:
        return None, [{'code':'WORLDGEN_ORE_UNSUPPORTED','reason':'ore feature has no target list'}]
    replace_rules=[]; diags=[]
    for target in targets:
        if not isinstance(target, dict):
            return None, [{'code':'WORLDGEN_ORE_UNSUPPORTED','reason':'target is not an object'}]
        state = _as_block_id(target.get('state'))
        pred = target.get('target')
        may_replace = _plain_block_list(pred.get('predicate') if isinstance(pred,dict) else None)
        if not state or may_replace is None:
            return None, [{'code':'WORLDGEN_ORE_UNSUPPORTED','reason':'target state/predicate uses tags or unsupported structure'}]
        replace_rules.append({'places_block':state, 'may_replace':may_replace})
        src_state = target.get('state') or {}
        if isinstance(src_state,dict) and src_state.get('Properties'):
            diags.append({'code':'WORLDGEN_ORE_STATE_PROPERTIES_DROPPED','reason':'Bedrock ore_feature places a block id, not Java BlockState properties', 'block':state})
    count=cfg.get('size', 1)
    if not isinstance(count,int) or count < 1:
        return None, [{'code':'WORLDGEN_ORE_UNSUPPORTED','reason':'ore size is not a positive integer'}]
    out={
        'format_version':'1.13.0',
        'minecraft:ore_feature':{
            'description':{'identifier':identifier},
            'count':count,
            'replace_rules':replace_rules,
        }
    }
    discard=cfg.get('discard_chance_on_air_exposure')
    if isinstance(discard,(int,float)) and 0 <= float(discard) <= 1:
        out['minecraft:ore_feature']['discard_chance_on_air_exposure']=float(discard)
    return out, diags


def _translate_single_block(identifier, cfg):
    """Translate a very small Java simple-block provider to Bedrock."""
    state_provider=cfg.get('state_provider')
    if not isinstance(state_provider,dict):
        return None, [{'code':'WORLDGEN_SINGLE_BLOCK_UNSUPPORTED','reason':'missing state_provider'}]
    block_state = state_provider.get('state')
    block_id = _as_block_id(block_state)
    if not block_id:
        return None, [{'code':'WORLDGEN_SINGLE_BLOCK_UNSUPPORTED','reason':'state provider is not a fixed block state'}]
    out={
        'format_version':'1.13.0',
        'minecraft:single_block_feature':{
            'description':{'identifier':identifier},
            'places_block':block_id,
        }
    }
    diags=[]
    if isinstance(block_state,dict) and block_state.get('Properties'):
        diags.append({'code':'WORLDGEN_SINGLE_BLOCK_STATE_PROPERTIES_DROPPED','reason':'Bedrock single_block_feature places a block id, not Java BlockState properties','block':block_id})
    return out, diags


def _parse_height_absolute(value):
    if not isinstance(value,dict):
        return None
    if value.get('absolute') is not None and isinstance(value.get('absolute'), int):
        return value['absolute']
    if value.get('above_bottom') is not None and isinstance(value.get('above_bottom'), int):
        return None
    if value.get('below_top') is not None and isinstance(value.get('below_top'), int):
        return None
    return None


def _translate_placed(identifier, data, configured_ids):
    feature = data.get('feature')
    if not isinstance(feature,str) or feature not in configured_ids:
        return None, [{'code':'WORLDGEN_PLACED_UNSUPPORTED','reason':'placed feature references a missing configured feature','feature':feature}]
    modifiers=data.get('placement',[])
    if not isinstance(modifiers,list):
        return None, [{'code':'WORLDGEN_PLACED_UNSUPPORTED','reason':'placement is not an array'}]
    iterations=1; x=0; y=0; z=0; scatter_chance=1.0; supported=True; diags=[]
    has_square=False
    for mod in modifiers:
        if not isinstance(mod,dict): supported=False; continue
        t=mod.get('type')
        if t == 'minecraft:count':
            c=mod.get('count')
            if isinstance(c,int) and c>0: iterations=c
            else: supported=False
        elif t == 'minecraft:in_square':
            has_square=True
        elif t == 'minecraft:biome':
            pass
        elif t == 'minecraft:rarity_filter':
            chance=mod.get('chance')
            if isinstance(chance,int) and chance>0:
                scatter_chance=1.0/chance
            else: supported=False
        elif t == 'minecraft:height_range':
            hr=mod.get('height',mod)
            hr_type=(hr.get('type') if isinstance(hr,dict) else None)
            if hr_type in {'minecraft:uniform','uniform'}:
                minv=_parse_height_absolute(hr.get('min_inclusive'))
                maxv=_parse_height_absolute(hr.get('max_inclusive'))
                if isinstance(minv,int) and isinstance(maxv,int): y={'distribution':'uniform','extent':[minv,maxv]}
                else: supported=False
            else:
                supported=False
        else:
            supported=False
            diags.append({'code':'WORLDGEN_PLACED_MODIFIER_UNSUPPORTED','modifier':t})
    if has_square:
        x={'distribution':'uniform','extent':[0,15]}; z={'distribution':'uniform','extent':[0,15]}
    result={
        'format_version':'1.21.20',
        'minecraft:scatter_feature':{
            'description':{'identifier':identifier},
            'places_feature':feature,
            'distribution':{'iterations':iterations,'scatter_chance':scatter_chance,'x':x,'y':y,'z':z}
        }
    }
    status='emulated' if supported else 'adaptable'
    if not supported:
        diags.append({'code':'WORLDGEN_PLACED_PARTIAL','reason':'some Java placement modifiers cannot be represented exactly by Bedrock scatter parameters'})
    return result, diags + [{'code':'WORLDGEN_PLACED_MAPPING','status':status}]


def _safe_biome_tag(identifier):
    short=identifier.split(':',1)[-1].replace('/','_').replace('-','_').replace('.','_')
    return 'nex_biome_' + ''.join(c if c.isalnum() or c=='_' else '_' for c in short)


def _flatten_feature_refs(features):
    out=[]
    def rec(x):
        if isinstance(x,str):
            out.append(x); return
        if isinstance(x,list):
            for v in x: rec(v)
    rec(features)
    return out


def scan_worldgen(z, meta, program):
    """Index Java worldgen and lower a conservative Bedrock-safe subset.

    Complex generator graphs remain lossless in nex_untranslated and are marked
    adaptable; simple ore/single-block/placed-feature chains are emitted as
    real Bedrock features using the documented feature/feature-rule schemas.
    """
    docs={}; counts={}
    for name in sorted(z.namelist()):
        if not name.endswith('.json'): continue
        kind=_kind(name)
        if kind not in WORLDGEN_ROOTS: continue
        try: data=json.loads(read_zip_member_text(z,name,MAX_JSON_BYTES))
        except Exception as exc:
            program.warn('WORLDGEN_PARSE_FAILED',str(exc),name); continue
        if not isinstance(data,dict):
            program.warn('WORLDGEN_ROOT_INVALID','Worldgen JSON root must be an object',name); continue
        identifier=_identifier(name,kind,meta.get('id','mod'))
        docs[identifier]=(kind,name,data)
        counts[kind]=counts.get(kind,0)+1

    configured_ids=set(k for k,(kind,_,_) in docs.items() if kind=='configured_feature')
    placed_ids=set(k for k,(kind,_,_) in docs.items() if kind=='placed_feature')

    for identifier,(kind,source_path,data) in sorted(docs.items()):
        plan={}; status='adaptable'; capability='worldgen.graph'; extra_diags=[]
        if kind=='dimension':
            plan=_java_dimension_plan(data); capability='worldgen.dimension'
        elif kind=='biome':
            climate={}
            if isinstance(data.get('temperature'),(int,float)): climate['temperature']=data['temperature']
            if isinstance(data.get('downfall'),(int,float)): climate['downfall']=data['downfall']
            effects=data.get('effects') if isinstance(data.get('effects'),dict) else {}
            plan_effects={k:v for k,v in effects.items() if k in {'sky_color','water_color','water_fog_color','fog_color'}}
            biome_tag=_safe_biome_tag(identifier)
            plan={'identifier':identifier,'climate':climate,'effects_unmapped':plan_effects,'keys':sorted(data.keys()),'biome_tag':biome_tag}
            status='emulated' if climate else 'adaptable'; capability='worldgen.biome'
            if climate:
                plan['bedrock_json']={
                    'format_version':'1.21.40',
                    'minecraft:biome':{
                        'description':{'identifier':identifier},
                        'components':{'minecraft:climate':climate,'minecraft:tags':{'tags':['nex_converted_biome',biome_tag]}}
                    }
                }
        elif kind=='configured_feature':
            feature_type=data.get('type'); cfg=data.get('config') if isinstance(data.get('config'),dict) else {}
            capability='worldgen.feature'; plan={'identifier':identifier,'java_type':feature_type,'keys':sorted(data.keys())}
            translated=None
            if feature_type in {'minecraft:ore','ore'}:
                translated, extra_diags=_translate_ore(identifier,cfg)
            elif feature_type in {'minecraft:random_patch','minecraft:vegetal_patch','random_patch','vegetal_patch'}:
                translated, extra_diags=_translate_single_block(identifier,cfg)
            if translated:
                plan['bedrock_json']=translated; status='emulated'
            else:
                status='adaptable'
        elif kind=='placed_feature':
            capability='worldgen.feature'
            translated, extra_diags=_translate_placed(identifier,data,configured_ids)
            plan={'identifier':identifier,'feature':data.get('feature'),'keys':sorted(data.keys())}
            if translated:
                plan['bedrock_json']=translated
                status='emulated' if not any(d.get('code')=='WORLDGEN_PLACED_PARTIAL' for d in extra_diags) else 'adaptable'
        elif kind=='feature_rule':
            capability='worldgen.feature_rule'; plan={'identifier':identifier,'keys':sorted(data.keys())}
            status='adaptable'
        else:
            plan={'identifier':identifier,'keys':sorted(data.keys())}

        args={'kind':kind,'capability':capability,'identifier':identifier,'java_json':data,'bedrock_plan':plan,'source_path':source_path,'mod_id':meta.get('id','mod'),'note':'Java worldgen schema requires reconstruction; raw JSON preserved for diagnostics.'}
        program.add(Operation('register_worldgen',identifier,args,status,meta.get('loader','unknown'),source_path))
        for d in extra_diags:
            program.warn(d.get('code','WORLDGEN_TRANSLATION'),json.dumps(d,ensure_ascii=False),source_path)

    # A custom Java biome's feature references can be attached to the emitted
    # biome through a Bedrock feature rule. We only create rules for placed
    # features that were actually defined by this JAR, avoiding accidental
    # references to vanilla/internal generator nodes.
    for identifier,(kind,source_path,data) in sorted(docs.items()):
        if kind!='biome': continue
        plan_id=_safe_biome_tag(identifier)
        biome_features=_flatten_feature_refs(data.get('features',[]))
        for ref in sorted(set(biome_features)):
            if ref not in placed_ids: continue
            rule_id=f'{identifier}/feature_rule/{ref.split(":",1)[-1].replace("/","_")}'
            rule={
                'format_version':'1.21.40',
                'minecraft:feature_rules':{
                    'description':{'identifier':rule_id,'places_feature':ref},
                    'conditions':{'placement_pass':'underground_pass','minecraft:biome_filter':{'test':'has_biome_tag','operator':'==','value':plan_id}},
                    'distribution':{'iterations':1,'x':0,'y':'query.heightmap(variable.worldx, variable.worldz)','z':0}
                }
            }
            program.add(Operation('register_worldgen',rule_id,{
                'kind':'feature_rule','capability':'worldgen.feature_rule','identifier':rule_id,
                'java_json':{},'bedrock_plan':{'bedrock_json':rule,'generated_from_biome':identifier,'placed_feature':ref,'biome_tag':plan_id},
                'source_path':source_path,'mod_id':meta.get('id','mod')
            },'emulated','java',source_path))

    if counts:
        program.diagnostics.append({'code':'WORLDGEN_ANALYZED','counts':counts,'total':sum(counts.values()),'converted_capabilities':['biome.climate','configured_feature.ore','configured_feature.single_block','placed_feature.scatter','biome_feature_rules']})
