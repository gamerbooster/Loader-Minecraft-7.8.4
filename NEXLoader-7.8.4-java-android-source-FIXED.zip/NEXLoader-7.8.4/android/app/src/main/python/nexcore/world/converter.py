from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from .chunker_engine import DEFAULT_TARGET, CHUNKER_VERSION, CHUNKER_SHA256, WorldEngineUnavailable, engine_status, run_conversion
from .mcworld import find_bedrock_world_root, package_mcworld, validate_bedrock_world_root
from .probe import materialize_java_world, probe_java_world
from nex.version import NEXLOADER_VERSION


def analyze_world(input_path: str | Path, *, chunker_jar: str | Path | None = None) -> dict[str, Any]:
    info = probe_java_world(input_path)
    engine = engine_status(chunker_jar)
    dimensions = [
        {
            "id": d.id, "path": d.path, "regions": d.regions, "chunks": d.chunks,
            "entities_regions": d.entities_regions, "poi_regions": d.poi_regions,
        }
        for d in info.dimensions
    ]
    total_regions = sum(d["regions"] for d in dimensions)
    total_chunks = sum(d["chunks"] for d in dimensions)
    status = "ready" if engine.get("available") else "blocked"
    warnings = list(info.warnings)
    if not engine.get("available"):
        warnings.append(engine.get("reason", "World conversion engine unavailable."))
    return {
        "mode": "world",
        "input_kind": "java_world",
        "status": status,
        "engine": {
            "name": "Chunker CLI",
            "known_version": CHUNKER_VERSION,
            "verified_sha256": CHUNKER_SHA256,
            **engine,
        },
        "source": info.to_dict(),
        "dimensions": dimensions,
        "total_regions": total_regions,
        "total_chunks": total_chunks,
        "target_default": DEFAULT_TARGET,
        "dimension_count": len(dimensions),
        "warnings": warnings,
    }


def convert_java_world(input_path: str | Path, output_root: str | Path, *, target: str = DEFAULT_TARGET,
                       chunker_jar: str | Path | None = None, timeout: int = 1800,
                       converter_settings: str | None = None) -> dict[str, Any]:
    started = time.time()
    src = Path(input_path).expanduser().resolve()
    out = Path(output_root).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    materialized = temp = None
    engine = None
    log_tail = ""
    try:
        # Materialize once. Large ZIP saves can be many gigabytes, so avoid a second
        # extraction just for probing before handing the same directory to Chunker.
        materialized, temp, _archive = materialize_java_world(src)
        info = probe_java_world(materialized)
        if src.suffix.lower() == ".zip":
            info.root = str(src)
        raw_output = out / "chunker_output"
        raw_output.mkdir(parents=True, exist_ok=True)
        raw_output, engine, log_tail = run_conversion(
            materialized, raw_output, target=target,
            chunker_jar=chunker_jar, timeout=timeout,
            converter_settings=converter_settings,
        )
        bedrock_root = find_bedrock_world_root(raw_output)
        if bedrock_root is None:
            raise RuntimeError("Chunker finished successfully but no Bedrock world (level.dat + db/) was found in its output")
        validation_errors = validate_bedrock_world_root(bedrock_root)
        if validation_errors:
            raise RuntimeError("generated Bedrock world failed validation: " + "; ".join(validation_errors))
        mcworld = out / f"{info.name or src.stem}-Bedrock.mcworld"
        package_mcworld(bedrock_root, mcworld)
        report = {
            "tool": "NEXLoader World Converter",
            "nexloader_version": NEXLOADER_VERSION,
            "status": "partial" if info.modded else "complete",
            "mode": "world",
            "input": str(src),
            "source": info.to_dict(),
            "target": target,
            "engine": {"name": "Chunker CLI", "version": engine.version, "jar": engine.jar, "sha256": engine.sha256},
            "bedrock_world_root": str(bedrock_root),
            "mcworld": str(mcworld),
            "elapsed_seconds": round(time.time() - started, 3),
            "warnings": list(info.warnings) + (["Modded world: inspect unsupported custom content before final play."] if info.modded else []),
            "engine_log_tail": log_tail[-40_000:],
        }
        report_path = out / "conversion_report.json"
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return report
    except WorldEngineUnavailable:
        raise
    finally:
        if temp is not None:
            temp.cleanup()
