from __future__ import annotations
import json, re, uuid, zipfile, struct
from pathlib import Path

_FUNCTION_REF_RE = re.compile(r"\bfunction\s+([a-z0-9_.-]+/[a-z0-9_./-]+)")

def _read_json(path: Path):
    try:
        value=json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        return None, f'JSON parse failed: {exc}'
    return value, None

def _valid_uuid(value):
    try:
        uuid.UUID(str(value)); return True
    except Exception:
        return False

def validate_compiled_output(outdir):
    """Validate NEX-generated archive structure and internal references.

    This intentionally checks invariants that NEX controls itself rather than
    attempting to reimplement the complete Bedrock schema validator.
    """
    out=Path(outdir)
    errors=[]
    bp=out/'behavior_pack'; rp=out/'resource_pack'
    if not bp.is_dir() or not rp.is_dir():
        return ['behavior_pack/resource_pack directories are missing']
    manifests={}
    for pack_name, pack_dir in [('behavior_pack',bp),('resource_pack',rp)]:
        path=pack_dir/'manifest.json'
        data,err=_read_json(path)
        if err or not isinstance(data,dict):
            errors.append(f'{pack_name}/manifest.json invalid: {err or "root is not an object"}')
            continue
        manifests[pack_name]=data
        metadata=data.get('metadata')
        if metadata is not None:
            if not isinstance(metadata,dict):
                errors.append(f'{pack_name}/manifest.json metadata must be an object')
            else:
                generated_with=metadata.get('generated_with')
                if generated_with is not None:
                    if not isinstance(generated_with,dict):
                        errors.append(f'{pack_name}/manifest.json metadata.generated_with must be an object')
                    else:
                        tool_re=re.compile(r'^[A-Za-z0-9_-]{1,32}$')
                        semver_re=re.compile(r'^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$')
                        for tool,versions in generated_with.items():
                            if not isinstance(tool,str) or not tool_re.fullmatch(tool):
                                errors.append(f'{pack_name}/manifest.json generated_with has invalid tool name {tool!r}')
                                continue
                            if not isinstance(versions,list) or not versions:
                                errors.append(f'{pack_name}/manifest.json generated_with.{tool} must be a non-empty array')
                                continue
                            for v in versions:
                                if not isinstance(v,str) or not semver_re.fullmatch(v):
                                    errors.append(f'{pack_name}/manifest.json generated_with.{tool} has invalid version {v!r}')
        header=data.get('header')
        if not isinstance(header,dict) or not _valid_uuid(header.get('uuid')):
            errors.append(f'{pack_name}/manifest.json has invalid header uuid')
        modules=data.get('modules')
        if not isinstance(modules,list) or not modules:
            errors.append(f'{pack_name}/manifest.json has no modules')
        else:
            for i,module in enumerate(modules):
                if not isinstance(module,dict) or not _valid_uuid(module.get('uuid')):
                    errors.append(f'{pack_name}/manifest.json module {i} has invalid uuid')
    # NEX always ships a pack icon in both generated packs.
    for pack_name, pack_root in (('behavior_pack', bp), ('resource_pack', rp)):
        icon=pack_root/'pack_icon.png'
        if not icon.is_file():
            # A converter must never fabricate pack artwork. Real source PNG is optional
            # for mods that ship no PNG at all; the conversion report records the absence.
            continue
        try:
            raw=icon.read_bytes()
            if raw[:8] != b'\x89PNG\r\n\x1a\n' or raw[12:16] != b'IHDR':
                raise ValueError('not a PNG')
            width,height=struct.unpack('>II',raw[16:24])
            if width < 1 or height < 1 or width > 4096 or height > 4096:
                raise ValueError(f'invalid dimensions {width}x{height}')
        except Exception as exc:
            errors.append(f'{pack_name}/pack_icon.png invalid: {exc}')

    bp_manifest=manifests.get('behavior_pack'); rp_manifest=manifests.get('resource_pack')
    if bp_manifest and rp_manifest:
        rp_uuid=rp_manifest.get('header',{}).get('uuid')
        deps=bp_manifest.get('dependencies',[]) or []
        if rp_uuid and not any(isinstance(d,dict) and d.get('uuid')==rp_uuid for d in deps):
            errors.append('behavior pack does not depend on resource pack uuid')

    # Every emitted custom client entity must have a matching behavior entity and
    # every geometry/texture reference controlled by NEX must resolve to a file.
    bp_entities={p.stem for p in (bp/'entities').glob('*.json')} if (bp/'entities').is_dir() else set()
    custom_client_files=list((rp/'entity').glob('*.entity.json')) if (rp/'entity').is_dir() else []
    geometry_ids=set()
    for gp in (rp/'models').rglob('*.geo.json') if (rp/'models').is_dir() else []:
        data,err=_read_json(gp)
        if err: errors.append(f'{gp.relative_to(out)}: {err}'); continue
        for geo in (data.get('minecraft:geometry',[]) if isinstance(data,dict) else []):
            if isinstance(geo,dict) and isinstance(geo.get('description'),dict):
                gid=geo['description'].get('identifier')
                if isinstance(gid,str): geometry_ids.add(gid)
    for cp in custom_client_files:
        data,err=_read_json(cp)
        if err: errors.append(f'{cp.relative_to(out)}: {err}'); continue
        desc=((data or {}).get('minecraft:client_entity') or {}).get('description') if isinstance(data,dict) else None
        if not isinstance(desc,dict):
            errors.append(f'{cp.relative_to(out)} missing client entity description'); continue
        ident=desc.get('identifier')
        if not isinstance(ident,str) or ':' not in ident:
            errors.append(f'{cp.relative_to(out)} has invalid identifier')
            continue
        short=ident.split(':',1)[1].split('/')[-1]
        if short not in bp_entities:
            errors.append(f'{cp.relative_to(out)} has no matching behavior entity')
        geoms=desc.get('geometry') if isinstance(desc.get('geometry'),dict) else {}
        gid=geoms.get('default') if isinstance(geoms,dict) else None
        if isinstance(gid,str) and gid not in geometry_ids:
            errors.append(f'{cp.relative_to(out)} references missing geometry {gid}')
        texmap=desc.get('textures') if isinstance(desc.get('textures'),dict) else {}
        tex=texmap.get('default') if isinstance(texmap,dict) else None
        if isinstance(tex,str) and tex.startswith('textures/'):
            tex_path=rp/tex
            if tex_path.suffix.lower() == '': tex_path=tex_path.with_suffix('.png')
            if not tex_path.is_file(): errors.append(f'{cp.relative_to(out)} references missing texture {tex}')

    # Bedrock texture registries must only point to files that exist in the RP.
    for registry in (rp/'textures'/'item_texture.json', rp/'textures'/'terrain_texture.json'):
        if not registry.exists():
            continue
        data,err=_read_json(registry)
        if err or not isinstance(data,dict):
            errors.append(f'{registry.relative_to(out)} invalid')
            continue
        for section in ('texture_data','resource_pack_name','atlas'):
            payload=data.get(section)
            if not isinstance(payload,dict): continue
            for key,entry in payload.items():
                values=[]
                if isinstance(entry,dict):
                    raw=entry.get('textures')
                    if isinstance(raw,str): values=[raw]
                    elif isinstance(raw,list): values=[v for v in raw if isinstance(v,str)]
                    elif isinstance(raw,dict): values=[v for v in raw.values() if isinstance(v,str)]
                elif isinstance(entry,str):
                    values=[entry]
                for value in values:
                    if value.startswith('textures/'):
                        path=rp/value
                        if path.suffix == '': path=path.with_suffix('.png')
                        if not path.is_file(): errors.append(f'{registry.relative_to(out)}:{key} references missing texture {value}')

    # Hook files must point at actual .mcfunction files generated by NEX.
    for hook in ('tick','load'):
        hp=bp/'functions'/f'{hook}.json'
        if not hp.exists(): continue
        data,err=_read_json(hp)
        if err or not isinstance(data,dict) or not isinstance(data.get('values'),list):
            errors.append(f'functions/{hook}.json invalid')
            continue
        for value in data['values']:
            if not isinstance(value,str) or not value: errors.append(f'functions/{hook}.json contains invalid value'); continue
            if ':' in value:
                ns,rel=value.split(':',1); path=bp/'functions'/ns/(rel+'.mcfunction')
            else:
                path=bp/'functions'/(value+'.mcfunction')
            if not path.is_file(): errors.append(f'functions/{hook}.json references missing function {value}')

    # Active Java->Bedrock function references must resolve after normalization.
    if (bp/'functions').is_dir():
        for fp in (bp/'functions').rglob('*.mcfunction'):
            try: text=fp.read_text(encoding='utf-8')
            except UnicodeDecodeError: continue
            parts=fp.relative_to(bp/'functions').parts
            current_ns=parts[0] if len(parts) >= 2 else None
            for line in text.splitlines():
                stripped=line.strip()
                if not stripped or stripped.startswith('#'): continue
                for m in _FUNCTION_REF_RE.finditer(stripped):
                    value=m.group(1)
                    if ':' in value:
                        ns,rel=value.split(':',1)
                        path=bp/'functions'/ns/(rel+'.mcfunction')
                    else:
                        first, sep, rest=value.partition('/')
                        if sep and (bp/'functions'/first).is_dir():
                            path=bp/'functions'/first/(rest+'.mcfunction')
                        elif current_ns:
                            path=bp/'functions'/current_ns/(value+'.mcfunction')
                        else:
                            continue
                    if not path.is_file():
                        errors.append(f'{fp.relative_to(out)} references missing function {value}')

    # Nested pack archives must be valid ZIP files and contain exactly the two
    # pack files produced by the compiler.
    mcaddon=next(iter(sorted(out.glob('*.mcaddon'))),None)
    if mcaddon:
        try:
            with zipfile.ZipFile(mcaddon) as outer:
                bad=outer.testzip()
                if bad: errors.append(f'mcaddon contains corrupt member {bad}')
                names=set(outer.namelist())
                expected={p.name for p in sorted(out.glob('*.mcpack'))}
                if not expected.issubset(names):
                    errors.append('mcaddon is missing one or more generated mcpack members')
                for nested in sorted(expected):
                    try:
                        raw=outer.read(nested)
                        import io
                        with zipfile.ZipFile(io.BytesIO(raw)) as inner:
                            bad_inner=inner.testzip()
                            if bad_inner: errors.append(f'{nested} contains corrupt member {bad_inner}')
                            if 'manifest.json' not in inner.namelist():
                                errors.append(f'{nested} is missing manifest.json')
                            else:
                                try:
                                    inner_manifest=json.loads(inner.read('manifest.json').decode('utf-8'))
                                    if not isinstance(inner_manifest,dict):
                                        errors.append(f'{nested}/manifest.json root is not an object')
                                    # NEX controls these generated manifests. Do not allow a stale or
                                    # malformed generated_with field to survive into the shipped pack.
                                    if isinstance(inner_manifest,dict) and 'metadata' in inner_manifest:
                                        errors.append(f'{nested}/manifest.json contains metadata; generated packs must omit it')
                                except Exception as manifest_exc:
                                    errors.append(f'{nested}/manifest.json invalid: {manifest_exc}')
                    except Exception as exc:
                        errors.append(f'{nested} invalid nested zip: {exc}')
        except Exception as exc: errors.append(f'mcaddon invalid zip: {exc}')
    return errors
