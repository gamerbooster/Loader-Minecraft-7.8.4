import re
from .ir import Program
MOD_RE=re.compile(r'^[a-z0-9_.-]+$')
ID_RE=re.compile(r'^[a-z0-9_.-]+:[a-z0-9/_.-]+$')
VALID={'convertible','emulated','adaptable','incompatible','unknown'}
SUPPORTED={'register_block','register_item','register_recipe','register_loot_table','register_model','register_texture','register_blockstate','register_entity','register_entity_visual','register_pack_asset','register_content','event','mixin','call','capability','spawn_body','tick_body','world_message','runtime_op','remove_effect','teleport','damage','impulse','run_command','dynamic_property','tick','register_config','register_tag','register_language','register_sound','register_function','register_worldgen','register_entity','register_advancement','intermod_call','resource_conflict','entrypoint','keybind','ui_screen','hud_overlay','particle','sound_play','scoreboard_op'}

def validate_program(p:Program):
    errs=[]; seen=set()
    if not MOD_RE.fullmatch(p.mod_id): errs.append(f'invalid mod_id: {p.mod_id}')
    for i,o in enumerate(p.operations):
        # register_content is a best-effort semantic hint. Java bytecode can expose
        # the same registry call through bridge/lambda methods, so duplicate hints
        # must not block conversion. Unknown hints are simply ignored by the compiler.
        if o.op == 'register_content' and (o.id == 'unknown' or not o.id or not ID_RE.fullmatch(o.id)):
            continue
        if o.status in {'convertible','emulated'} and o.op not in SUPPORTED: errs.append(f'unsupported convertible op {o.op}')
        if o.op in {'register_block','register_item','register_recipe','register_loot_table','register_model','register_texture','register_blockstate','register_entity'} and not ID_RE.fullmatch(o.id): errs.append(f'invalid resource id: {o.id}')
        if o.status not in VALID: errs.append(f'invalid status: {o.status}')
        key=(o.op,o.id)
        # Duplicate content hints are harmless and are not emitted as Bedrock files.
        if key in seen and o.op.startswith('register_') and o.op != 'register_content':
            errs.append(f'duplicate registration: {o.op}:{o.id}')
        seen.add(key)
    return errs
