# NEX Loader 7.7 core

Target runtime: **Minecraft Bedrock 1.26.52.3**.

The core analyzes a Java mod or ModPack into a common NEX-IR and lowers the safe subset into Bedrock behavior/resource packs. The resolver handles Fabric, Quilt, Forge and NeoForge metadata, dependency ranges, conflicts, cycles, Modrinth/CurseForge external-file declarations, and Jar-in-Jar discovery.

## Included lowering passes
- Blocks, models, parent-model resolution, blockstates/permutations and per-face textures.
- Items and common Java item-model `layer0` icons.
- Common crafting/cooking recipes and conservative loot tables.
- Tags, localization, sounds and static configs.
- Java `data/<namespace>/functions/*.mcfunction` with conservative command checks; unsupported functions are archived under `nex_untranslated/`.
- Physics fragment proxy/runtime, effects/state/scheduler bridges, input/UI/particle reconstruction hints.
- Fabric/Quilt entrypoint and Mixin metadata retained in NEX-IR/report for later semantic reconstruction.
- Unified ModPack IR, inter-mod contracts, resource deduplication/conflict detection and dependency graph output.

## Compatibility statuses
`convertible` = lowered directly; `emulated` = Bedrock-side NEX runtime required; `adaptable` = semantics require reconstruction and are retained as diagnostics/archive; `incompatible` = no supported execution path.

The core does not execute Java bytecode inside Bedrock and does not claim 1:1 parity for arbitrary JVM/rendering/networking systems.

## Hardening
- Corrupt loader manifests are surfaced as explicit input errors. Empty ModPacks are reported as incomplete.
- External artifacts and local verification are streamed with bounded memory use; oversized embedded JAR/config inputs are skipped explicitly.

## Verification
The current release runs 39 automated regression test scripts plus the compatibility self-test. The Android source analyzer is checked with local compile stubs; the real Android SDK/Gradle build remains external to this environment.

## Java World Converter (7.8.4)
NEXLoader now detects Java worlds (`level.dat` + `region/`) before ModPack routing and exposes a dedicated world pipeline.

The pipeline probes the save safely, reads the GZip/NBT `level.dat`, inventories Overworld/Nether/End regions, counts populated chunk slots, detects common modded-world signals, and produces a structured report. Actual Java→Bedrock world rewriting is delegated to a verified Chunker CLI engine because Java worlds use Anvil storage while Bedrock worlds use LevelDB; an `.mcworld` is then packaged only after `level.dat` + `db/` validation.

Install the verified engine with:
```text
python tools/fetch_world_engine.py
```

Analyze without converting:
```text
python core/nex_world_convert.py analyze "MY_WORLD"
```

Convert to the conservative Bedrock 1.26.50 target:
```text
python core/nex_world_convert.py convert "MY_WORLD" out --target BEDROCK_1_26_50
```

The Android shell can already analyze Java worlds and report whether the verified engine is present. The current APK source does not bundle a desktop JVM/Chunker binary, so full in-app world conversion is intentionally reported as unavailable rather than pretending it works. The desktop/CI path can use the verified Chunker CLI JAR.
