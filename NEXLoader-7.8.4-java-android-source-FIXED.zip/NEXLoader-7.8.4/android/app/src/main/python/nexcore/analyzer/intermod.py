from __future__ import annotations

from dataclasses import dataclass

from .classfile import parse, code_scan
from nex.ir import Operation


@dataclass(frozen=True)
class MethodDef:
    owner: str
    name: str
    descriptor: str
    access: int
    mod_id: str
    source: str

    @property
    def public(self) -> bool:
        return bool(self.access & 0x0001)


def _package_prefix(class_name: str) -> str:
    parts = class_name.replace('.', '/').split('/')
    if len(parts) <= 1:
        return parts[0]
    n = min(3, len(parts) - 1)
    return '/'.join(parts[:n])


def _owner_matches(owner: str, prefix: str) -> bool:
    return owner == prefix or owner.startswith(prefix + '/')


def analyze_cross_mod_calls(mod_entries):
    """Recover Java calls between mod-provided class namespaces.

    Exact class ownership is preferred. A conservative package-prefix fallback is used
    only when it resolves to one unambiguous target mod.
    """
    class_defs: dict[str, list[MethodDef]] = {}
    class_to_mods: dict[str, set[str]] = {}
    prefix_to_mods: dict[str, set[str]] = {}
    parsed_by_source = []

    for source_mod, source_path, entries in mod_entries:
        for class_path, data in entries:
            try:
                parsed = parse(data)
            except Exception:
                continue
            owner = parsed['this'].replace('.', '/')
            class_to_mods.setdefault(owner, set()).add(source_mod)
            prefix_to_mods.setdefault(_package_prefix(owner), set()).add(source_mod)
            class_defs.setdefault(owner, [])
            for method in parsed['methods']:
                class_defs[owner].append(MethodDef(owner, method['name'], method['descriptor'], method['access'], source_mod, source_path))
            parsed_by_source.append((source_mod, source_path, parsed))

    prefixes = sorted(prefix_to_mods, key=len, reverse=True)
    ops=[]; seen=set()
    for source_mod, source_path, parsed in parsed_by_source:
        owner_self = parsed['this'].replace('.', '/')
        for method in parsed['methods']:
            for call in code_scan(parsed, method):
                owner=call.get('owner') or ''
                if not owner or owner == owner_self:
                    continue

                candidates=sorted(x for x in class_to_mods.get(owner, set()) if x != source_mod)
                ambiguous=False
                if len(candidates) == 1:
                    target_mod=candidates[0]
                elif len(candidates) > 1:
                    target_mod=None; ambiguous=True
                else:
                    target_mod=None
                    prefix_candidates=set()
                    for prefix in prefixes:
                        mods=prefix_to_mods[prefix]
                        if source_mod in mods or not _owner_matches(owner, prefix):
                            continue
                        prefix_candidates.update(mods)
                    prefix_candidates.discard(source_mod)
                    if len(prefix_candidates)==1:
                        target_mod=sorted(prefix_candidates)[0]
                    elif len(prefix_candidates)>1:
                        ambiguous=True

                if not target_mod and not ambiguous:
                    continue
                defs=[d for d in class_defs.get(owner, []) if d.name==call.get('name') and d.descriptor==call.get('descriptor')]
                if ambiguous:
                    resolved=False
                else:
                    resolved=bool(defs and defs[0].mod_id==target_mod)
                key=(source_mod,target_mod,owner,call.get('name'),call.get('descriptor'),source_path,method['name'],ambiguous)
                if key in seen:
                    continue
                seen.add(key)
                args={
                    'source_mod':source_mod,
                    'target_mod':target_mod,
                    'owner':owner,
                    'method':call.get('name'),
                    'descriptor':call.get('descriptor'),
                    'resolved':resolved,
                    'visibility':'public' if (defs and defs[0].public) else 'unknown_or_non_public',
                    'invoke':call.get('invoke'),
                }
                if ambiguous:
                    args['reason']='ambiguous owner supplied by multiple mods'
                elif not defs:
                    args['reason']='target class found but exact method signature was not found'
                ops.append(Operation(
                    'intermod_call',
                    f'{source_mod}->{target_mod or "ambiguous"}:{owner.replace("/",".")}#{call.get("name")}',
                    args,
                    'emulated' if resolved else 'adaptable',
                    'modpack',
                    source_path,
                ))
    return ops
