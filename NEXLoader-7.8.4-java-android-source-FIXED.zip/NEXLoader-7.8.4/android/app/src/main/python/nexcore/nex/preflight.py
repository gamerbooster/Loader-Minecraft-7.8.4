from __future__ import annotations
import re
from pathlib import Path
from .output_validate import validate_compiled_output

ID_RE=re.compile(r'^[a-z0-9_.-]+:[a-z0-9_./-]+$')

def preflight_program(program):
    findings=[]; counts={'convertible':0,'emulated':0,'adaptable':0,'incompatible':0}
    for o in program.operations:
        counts[o.status]=counts.get(o.status,0)+1
        if o.op.startswith('register_') and o.op not in {'register_config','register_function','register_language'} and not ID_RE.fullmatch(str(o.id)):
            findings.append({'severity':'error','code':'INVALID_OPERATION_ID','op':o.op,'id':o.id,'source':o.source})
        if o.status=='incompatible': findings.append({'severity':'warning','code':'INCOMPATIBLE_CAPABILITY','id':o.id,'source':o.source})
        if o.status=='adaptable': findings.append({'severity':'warning','code':'ADAPTABLE_CAPABILITY','id':o.id,'source':o.source})
    return {'ok':not any(x['severity']=='error' for x in findings),'counts':counts,'findings':findings}

def preflight_output(outdir):
    errors=validate_compiled_output(outdir)
    return {'ok':not errors,'errors':errors}
