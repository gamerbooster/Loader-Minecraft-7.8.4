from .effects import EffectRequest, emit_add_effect

# This layer translates normalized semantic actions, not arbitrary Java source.
def translate(action):
    kind=action.get('kind')
    if kind=='add_effect':
        return {'status':'convertible', 'js':emit_add_effect(EffectRequest(
            target=action['target'], effect=action['effect'],
            duration_ticks=action['duration_ticks'],
            amplifier=action.get('amplifier',0),
            show_particles=action.get('show_particles',True)))
        }
    if kind in {'remove_effect','teleport','damage','impulse','run_command','dynamic_property','tick'}:
        return {'status':'bridge', 'operation':kind}
    return {'status':'adaptable', 'operation':kind}
