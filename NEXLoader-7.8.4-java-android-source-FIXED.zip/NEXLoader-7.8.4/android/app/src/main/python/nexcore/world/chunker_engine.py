from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence
from urllib.request import Request, urlopen

CHUNKER_VERSION = "1.21.0"
CHUNKER_SHA256 = "63148e587f5ee5a2ca7ebae1079b235c82ae4d1eff8f7a8a8a3398332513dda6"
CHUNKER_URL = f"https://github.com/HiveGamesOSS/Chunker/releases/download/{CHUNKER_VERSION}/chunker-cli-{CHUNKER_VERSION}.jar"
MAX_ENGINE_DOWNLOAD_BYTES = 64 * 1024 * 1024
DEFAULT_TARGET = "BEDROCK_1_26_50"


class WorldEngineUnavailable(RuntimeError):
    pass


def _is_android_runtime() -> bool:
    """Return True for the current Android/ART runtime used by Chaquopy."""
    if sys.platform == "android":
        return True
    return Path("/system/bin/app_process").exists() and Path("/system/build.prop").exists()


def _java_major(java: str | None) -> int | None:
    if not java:
        return None
    try:
        proc = subprocess.run(
            [java, "-version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    match = re.search(r"version\s+[\"](\d+)(?:\.(\d+))?", proc.stdout)
    if not match:
        return None
    major = int(match.group(1))
    if major == 1 and match.group(2):
        return int(match.group(2))
    return major


@dataclass(frozen=True)
class EngineInfo:
    version: str
    jar: str
    java: str
    sha256: str


def _candidate_paths(explicit: str | Path | None = None) -> list[Path]:
    values: list[Path] = []
    if explicit:
        values.append(Path(explicit).expanduser())
    env = os.environ.get("NEX_CHUNKER_JAR")
    if env:
        values.append(Path(env).expanduser())
    here = Path(__file__).resolve()
    values.extend([
        here.parents[2] / "tools" / "world_engine" / f"chunker-cli-{CHUNKER_VERSION}.jar",
        Path.cwd() / "tools" / "world_engine" / f"chunker-cli-{CHUNKER_VERSION}.jar",
    ])
    # Dedupe without requiring existing paths.
    out=[]; seen=set()
    for x in values:
        try: k=str(x.resolve())
        except OSError: k=str(x)
        if k not in seen:
            seen.add(k); out.append(x)
    return out


def _sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def find_engine(explicit: str | Path | None = None) -> EngineInfo | None:
    if _is_android_runtime():
        return None
    for candidate in _candidate_paths(explicit):
        if not candidate.is_file():
            continue
        digest = _sha256(candidate)
        if digest != CHUNKER_SHA256:
            continue
        java = shutil.which("java")
        java_major = _java_major(java)
        if java_major is None or java_major < 17:
            return None
        return EngineInfo(version=CHUNKER_VERSION, jar=str(candidate), java=java, sha256=digest)
    return None


def engine_status(explicit: str | Path | None = None) -> dict:
    if _is_android_runtime():
        return {
            "available": False,
            "runtime": "android",
            "reason": "La APK actual no incluye una JVM Java SE 17+ para ejecutar Chunker CLI; la conversión completa de mundos Java está disponible en desktop/CI.",
        }
    java = shutil.which("java")
    java_major = _java_major(java)
    invalid_candidate = None
    for candidate in _candidate_paths(explicit):
        if candidate.is_file():
            digest = _sha256(candidate)
            if digest == CHUNKER_SHA256 and java_major is not None and java_major >= 17:
                return {"available": True, "version": CHUNKER_VERSION, "jar": str(candidate), "java": java, "java_major": java_major, "sha256": digest}
            invalid_candidate = candidate
    if invalid_candidate is not None:
        reason = "Chunker JAR exists but failed SHA-256 verification."
        if java_major is None:
            reason = "Chunker JAR exists, but Java 17+ is unavailable."
        elif java_major < 17:
            reason = f"Chunker JAR exists, but Java {java_major} is too old; Java 17+ is required."
        return {"available": False, "reason": reason, "jar": str(invalid_candidate), "java": java or None, "java_major": java_major}
    return {"available": False, "reason": "Verified Chunker CLI not installed; run tools/fetch_world_engine.py.", "java": java or None, "java_major": java_major}



def fetch_verified_engine(destination: str | Path) -> EngineInfo:
    """Download the pinned Chunker CLI atomically and return verified engine info."""
    if _is_android_runtime():
        raise WorldEngineUnavailable("La APK actual no incluye una JVM Java SE 17+ para ejecutar Chunker CLI.")
    import tempfile

    dest = Path(destination).expanduser().resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_file() and _sha256(dest) == CHUNKER_SHA256:
        java = shutil.which("java")
        java_major = _java_major(java)
        if java_major is not None and java_major >= 17:
            return EngineInfo(version=CHUNKER_VERSION, jar=str(dest), java=java, sha256=CHUNKER_SHA256)
        raise WorldEngineUnavailable("Java 17+ is required to run the Chunker CLI.")

    fd, tmp_name = tempfile.mkstemp(prefix=dest.name + ".", suffix=".part", dir=str(dest.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        request = Request(CHUNKER_URL, headers={"User-Agent": "NEXLoader-World-Engine/7.8.4"})
        with urlopen(request, timeout=90) as response, tmp.open("wb") as out:
            total = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                total += len(block)
                if total > MAX_ENGINE_DOWNLOAD_BYTES:
                    raise WorldEngineUnavailable("Chunker download exceeds the 64 MiB safety limit.")
                out.write(block)
        digest = _sha256(tmp)
        if digest != CHUNKER_SHA256:
            raise WorldEngineUnavailable(f"Chunker SHA-256 mismatch: got {digest}, expected {CHUNKER_SHA256}")
        tmp.replace(dest)
    except WorldEngineUnavailable:
        tmp.unlink(missing_ok=True)
        raise
    except Exception as exc:
        tmp.unlink(missing_ok=True)
        raise WorldEngineUnavailable(f"Unable to download verified Chunker CLI: {exc}") from exc
    finally:
        tmp.unlink(missing_ok=True)

    java = shutil.which("java")
    java_major = _java_major(java)
    if java_major is None or java_major < 17:
        raise WorldEngineUnavailable("Java 17+ is required to run the Chunker CLI.")
    return EngineInfo(version=CHUNKER_VERSION, jar=str(dest), java=java, sha256=CHUNKER_SHA256)

def run_conversion(input_dir: str | Path, output_dir: str | Path, *, target: str = DEFAULT_TARGET,
                   chunker_jar: str | Path | None = None, timeout: int = 1800,
                   converter_settings: str | None = None) -> tuple[Path, EngineInfo, str]:
    if _is_android_runtime():
        raise WorldEngineUnavailable("La APK actual no incluye una JVM Java SE 17+ para ejecutar Chunker CLI.")
    info = find_engine(chunker_jar)
    if info is None:
        raise WorldEngineUnavailable(engine_status(chunker_jar)["reason"])
    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    cmd: list[str] = [info.java, "-jar", info.jar, "-i", str(source), "-f", target, "-o", str(output)]
    if converter_settings:
        cmd.extend(["-c", converter_settings])
    env = os.environ.copy()
    env.setdefault("JAVA_TOOL_OPTIONS", "-Dfile.encoding=UTF-8")
    proc = subprocess.run(
        cmd, cwd=str(Path(info.jar).parent), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", timeout=timeout,
        check=False,
    )
    log = proc.stdout[-200_000:]
    if proc.returncode != 0:
        raise RuntimeError(f"Chunker CLI failed with exit code {proc.returncode}.\n{log}")
    return output, info, log
