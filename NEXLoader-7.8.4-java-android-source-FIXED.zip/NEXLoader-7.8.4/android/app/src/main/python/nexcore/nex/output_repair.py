from __future__ import annotations
import json
import shutil
from pathlib import Path


def _read_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return None


def repair_generated_output(outdir):
    """Repair only deterministic, source-derived output problems.

    Never creates fake textures/geometries. Invalid visuals are quarantined so the
    behavior entity and the rest of the pack can remain usable.
    """
    out = Path(outdir)
    rp = out / 'resource_pack'
    bp = out / 'behavior_pack'
    repairs = []

    # Geometry repair: if a client entity points at a missing geometry and there is
    # exactly one strongly named matching geometry, use that real identifier.
    geometry_index = []
    for gp in (rp / 'models').rglob('*.geo.json') if (rp / 'models').is_dir() else []:
        data = _read_json(gp)
        if not isinstance(data, dict):
            continue
        for rec in data.get('minecraft:geometry', []) or []:
            if not isinstance(rec, dict) or not isinstance(rec.get('description'), dict):
                continue
            gid = rec['description'].get('identifier')
            if isinstance(gid, str) and gid:
                geometry_index.append((gid, gp))

    for cp in sorted((rp / 'entity').glob('*.entity.json')) if (rp / 'entity').is_dir() else []:
        data = _read_json(cp)
        if not isinstance(data, dict):
            continue
        ce = data.get('minecraft:client_entity', {})
        desc = ce.get('description') if isinstance(ce, dict) else None
        if not isinstance(desc, dict):
            continue
        ident = desc.get('identifier') if isinstance(desc.get('identifier'), str) else cp.stem
        short = ident.split(':', 1)[-1].split('/')[-1].lower()
        geoms = desc.get('geometry') if isinstance(desc.get('geometry'), dict) else None
        if not geoms:
            continue
        gid = geoms.get('default')
        if isinstance(gid, str) and gid:
            if any(g == gid for g, _ in geometry_index):
                continue
            candidates=[]
            for candidate_gid, candidate_path in geometry_index:
                low=(candidate_gid + ' ' + candidate_path.name).lower()
                if short in low:
                    candidates.append((candidate_gid, candidate_path))
            if len(candidates) == 1:
                new_gid=candidates[0][0]
                geoms['default']=new_gid
                cp.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
                repairs.append({'type':'geometry_id','file':str(cp.relative_to(out)),'from':gid,'to':new_gid})

    # Any remaining client entity that still points at an absent geometry or texture
    # is quarantined, rather than allowing a magenta/invalid visual to poison the pack.
    for cp in sorted((rp / 'entity').glob('*.entity.json')) if (rp / 'entity').is_dir() else []:
        data = _read_json(cp)
        if not isinstance(data, dict):
            continue
        desc = ((data.get('minecraft:client_entity') or {}).get('description') if isinstance(data.get('minecraft:client_entity'), dict) else None)
        if not isinstance(desc, dict):
            continue
        broken=[]
        geoms=desc.get('geometry') if isinstance(desc.get('geometry'), dict) else {}
        gid=geoms.get('default') if isinstance(geoms,dict) else None
        if isinstance(gid,str) and gid and not any(g==gid for g,_ in geometry_index):
            broken.append({'kind':'geometry','value':gid})
        texmap=desc.get('textures') if isinstance(desc.get('textures'), dict) else {}
        tex=texmap.get('default') if isinstance(texmap,dict) else None
        if isinstance(tex,str) and tex.startswith('textures/'):
            p=rp/tex
            if p.suffix=='': p=p.with_suffix('.png')
            if not p.is_file(): broken.append({'kind':'texture','value':tex})
        if broken:
            q=rp/'nex_untranslated'/'quarantined_visuals'/cp.name
            q.parent.mkdir(parents=True,exist_ok=True)
            shutil.move(str(cp),str(q))
            repairs.append({'type':'quarantine_visual','file':str(q.relative_to(out)),'reasons':broken})

    return repairs
