from __future__ import annotations
import re
from pathlib import PurePosixPath

# Commands whose Bedrock command form is close enough to Java to keep after
# normalizing function paths/selectors. Commands that depend on Java NBT/storage
# are handled conservatively below instead of being emitted as known-good.
SAFE_COMMANDS = {
    'say', 'tellraw', 'title', 'playsound', 'stopsound', 'particle',
    'summon', 'teleport', 'tp', 'give', 'clear', 'effect', 'tag',
    'scoreboard', 'setblock', 'fill', 'clone', 'kill', 'weather',
    'time', 'gamerule', 'difficulty', 'gamemode', 'spawnpoint',
    'setworldspawn', 'locate', 'execute', 'function', 'experience', 'xp',
    'damage', 'loot',
}

# Root commands that are syntactically different or Java-only enough that we
# must not leave them active in a Bedrock function.
UNSAFE_COMMANDS = {
    'data', 'schedule', 'attribute', 'jfr', 'return', 'forceload', 'item',
    'place', 'random',
}

_DISPLAY_TYPES = {
    'minecraft:item_display', 'minecraft:block_display',
    'minecraft:text_display', 'minecraft:interaction',
}


def _command_root(line: str) -> str | None:
    stripped = line.strip()
    if not stripped or stripped.startswith('#'):
        return None
    if stripped.startswith('/'):
        stripped = stripped[1:].lstrip()
    token = stripped.split(None, 1)[0] if stripped else ''
    return token.split(':')[-1].lower() if token else None


def _replace_function_refs(line: str) -> str:
    # Bedrock /function takes a file path. NEX emits functions/<namespace>/<path>.
    return re.sub(
        r'(?<![A-Za-z0-9_./-])function\s+([a-z0-9_.-]+):([a-z0-9_./-]+)',
        lambda m: 'function ' + m.group(1) + '/' + m.group(2),
        line,
    )


def _replace_display_selectors(line: str, proxy_entity: str | None) -> str:
    if not proxy_entity:
        return line
    # From The Fog uses a custom Java entity tag (#namespace:herobrine). Map
    # that one known display-entity type tag onto the generated Bedrock proxy.
    line = re.sub(r'type=#(?:lunareclipse\.watching:)?herobrine\b', f'type={proxy_entity}', line)
    for display_type in sorted(_DISPLAY_TYPES):
        line = line.replace('type=' + display_type, 'type=' + proxy_entity)
    return line


def _normalize_display_summon(line: str, proxy_entity: str | None) -> str:
    if not proxy_entity:
        return line
    # Java display entities carry NBT after coordinates. Bedrock cannot consume
    # that NBT, so keep the summon but strip the Java NBT payload. This is an
    # intentional approximation; the diagnostic tells the user what was lost.
    m = re.match(r'^(\s*)summon\s+(minecraft:(?:item_display|block_display|text_display|interaction))\b(.*)$', line)
    if not m:
        return line
    tail = m.group(3).strip()
    # Keep up to three coordinate tokens when present, discard the Java NBT tail.
    prefix = tail.split('{', 1)[0].strip()
    tokens = prefix.split()
    if 1 <= len(tokens) <= 3 and all(re.match(r'^[~^]|^-?\d+(?:\.\d+)?$', t) for t in tokens):
        return f'{m.group(1)}summon {proxy_entity} ' + ' '.join(tokens)
    return f'{m.group(1)}summon {proxy_entity}'


def translate_function(text: str, proxy_entity: str | None = None):
    """Translate a Java .mcfunction conservatively for Bedrock.

    Safe commands stay active after normalization. Java-only commands/NBT lines
    are commented out in the active function and preserved in diagnostics. This
    lets otherwise-useful parts of a function continue running instead of
    archiving the entire file just because one line is unsupported.
    """
    diagnostics = []
    out = []
    unsupported = []
    translated = 0
    for line_no, raw in enumerate(text.splitlines(), 1):
        line = raw[1:] if raw.startswith('/') else raw
        root = _command_root(line)
        if root is None:
            out.append(line)
            continue

        line = _replace_function_refs(line)
        line = _replace_display_selectors(line, proxy_entity)
        line2 = _normalize_display_summon(line, proxy_entity)
        if line2 != line:
            translated += 1
            line = line2
            diagnostics.append({'code':'DISPLAY_SUMMON_APPROXIMATED','line':line_no})

        # Java data/NBT operations embedded in execute are not Bedrock syntax.
        java_nbt = bool(re.search(r'\bdata\s+(?:storage|entity|block|get|merge|modify|remove)\b', line))
        java_store = bool(re.search(r'\bstore\s+(?:result|success)\b', line))
        java_with = bool(re.search(r'\bwith\s+(?:entity|storage|block)\b.*\bdata\b', line))
        is_unsafe = root in UNSAFE_COMMANDS or java_nbt or java_store or java_with

        if is_unsafe:
            unsupported.append({'line': line_no, 'command': root, 'text': raw})
            out.append('# NEX_UNTRANSLATED_JAVA: ' + line)
            continue

        if root not in SAFE_COMMANDS:
            unsupported.append({'line': line_no, 'command': root, 'text': raw})
            out.append('# NEX_UNSUPPORTED_COMMAND: ' + line)
            continue

        if line != raw and (raw.startswith('/') or 'function ' in raw or 'type=' in raw):
            translated += 1
        out.append(line)

    if unsupported:
        diagnostics.insert(0, {
            'code': 'FUNCTION_PARTIAL_TRANSLATION',
            'count': len(unsupported),
            'commands': unsupported,
        })
        status = 'adaptable'
    else:
        status = 'convertible'

    result = '\n'.join(out) + ('\n' if text.endswith('\n') or out else '')
    return status, result, diagnostics


def function_path_info(name: str, default_namespace: str):
    parts = PurePosixPath(name).parts
    marker = next((i for i, part in enumerate(parts) if part in {'function', 'functions'}), None)
    if marker is None:
        return None
    if marker < 2 or marker + 1 >= len(parts):
        return None
    namespace = parts[1] or default_namespace
    rel = '/'.join(parts[marker + 1:])
    if not rel.endswith('.mcfunction'):
        return None
    rel = rel[:-len('.mcfunction')]
    if not rel:
        return None
    return namespace, rel
