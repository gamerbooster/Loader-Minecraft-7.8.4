import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from adapters.resources import build_ir
from adapters.modpack import build_modpack_ir, inspect_modpack
from nex.compiler import compile_program, compile_modpack

p = argparse.ArgumentParser(description='NEXLoader Java/Fabric/Forge -> Bedrock converter')
p.add_argument('input', help='.jar, ModPack directory, .zip or .mrpack')
p.add_argument('output')
p.add_argument('--script-api', default='2.9.0')
p.add_argument('--pack-id', default=None)
p.add_argument('--modpack', action='store_true', help='treat input as a ModPack')
p.add_argument('--strict', action='store_true', help='fail when required dependencies cannot be resolved')
p.add_argument('--analyze-only', action='store_true', help='analyze input and print JSON without generating a pack')
p.add_argument('--fetch-externals', action='store_true', help='download missing Modrinth files with HTTPS + hash verification')
a = p.parse_args()

src=Path(a.input)
is_pack=a.modpack or src.is_dir() or src.suffix.lower() in {'.zip','.mrpack','.modpack'}
if is_pack:
    program,resolution,tmp=build_modpack_ir(src,a.pack_id,fetch_externals=a.fetch_externals)
    try:
        if a.analyze_only:
            print(json.dumps({'mode':'modpack','pack_id':program.mod_id,'status':'complete' if resolution.complete else 'partial',
                              'mods':[n.mod_id for n in resolution.ordered],'missing':[d.__dict__ for d in resolution.missing],
                              'conflicts':resolution.conflicts,'cycles':resolution.cycles,'warnings':resolution.warnings,
                              'diagnostics':program.diagnostics},ensure_ascii=False,indent=2))
            raise SystemExit(0)
        if a.strict and not resolution.complete:
            raise SystemExit('ModPack dependency resolution failed in --strict mode')
        out=compile_modpack(program,a.output,resolution,a.script_api,strict=a.strict)
        report=json.loads((out/'conversion_report.json').read_text(encoding='utf-8'))
        print(json.dumps({'mode':'modpack','status':report['status'],'mods':len(resolution.ordered),'missing':len(resolution.missing),'conflicts':len(resolution.conflicts),'cycles':len(resolution.cycles)},ensure_ascii=False))
    finally:
        import shutil
        shutil.rmtree(tmp,ignore_errors=True)
else:
    info,program=build_ir(src)
    if a.analyze_only:
        print(json.dumps({'mode':'mod','info':info,'mod_id':program.mod_id,'version':program.version,
                          'operations':len(program.operations),'diagnostics':program.diagnostics,
                          'statuses':{s:sum(1 for o in program.operations if o.status==s) for s in ('convertible','emulated','adaptable','incompatible')}},ensure_ascii=False,indent=2))
        raise SystemExit(0)
    out=compile_program(program,a.output,a.script_api)
    print(info)
