import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from adapters.resources import build_ir
from adapters.input_detect import detect_input_kind
from adapters.resourcepack import compile_resource_pack
from adapters.modpack import build_modpack_ir, inspect_modpack
from nex.compiler import compile_program, compile_modpack
from analyzer.compatibility_plan import build_plan
from world.converter import analyze_world, convert_java_world
from world.chunker_engine import DEFAULT_TARGET

p = argparse.ArgumentParser(description='NEXLoader Java/Fabric/Forge -> Bedrock converter')
p.add_argument('input', help='.jar, ModPack directory, .zip or .mrpack')
p.add_argument('output')
p.add_argument('--script-api', default='2.9.0')
p.add_argument('--pack-id', default=None)
p.add_argument('--modpack', action='store_true', help='treat input as a ModPack')
p.add_argument('--strict', action='store_true', help='fail when required dependencies cannot be resolved')
p.add_argument('--analyze-only', action='store_true', help='analyze input and print JSON without generating a pack')
p.add_argument('--fetch-externals', action='store_true', help='download missing Modrinth files with HTTPS + hash verification')
p.add_argument('--world-target', default=DEFAULT_TARGET, help='Bedrock world target format for Java-world conversion')
p.add_argument('--chunker-jar', default=None, help='path to a verified Chunker CLI JAR')
p.add_argument('--world-timeout', type=int, default=1800, help='maximum seconds for Java-world conversion')
p.add_argument('--converter-settings', default=None, help='Chunker converter-settings JSON path')
a = p.parse_args()

src=Path(a.input)
kind=detect_input_kind(src, a.modpack)
if kind == 'java_world':
    if a.analyze_only:
        print(json.dumps(analyze_world(src, chunker_jar=a.chunker_jar), ensure_ascii=False, indent=2))
        raise SystemExit(0)
    report = convert_java_world(
        src, a.output, target=a.world_target, chunker_jar=a.chunker_jar,
        timeout=max(60, a.world_timeout), converter_settings=a.converter_settings,
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0)

is_pack=kind=='modpack'
if is_pack:
    program,resolution,tmp=build_modpack_ir(src,a.pack_id,fetch_externals=a.fetch_externals)
    try:
        if a.analyze_only:
            print(json.dumps({'mode':'modpack','input_kind':kind,'pack_id':program.mod_id,'status':'complete' if resolution.complete else 'partial',
                              'mods':[n.mod_id for n in resolution.ordered],'missing':[d.__dict__ for d in resolution.missing],
                              'conflicts':resolution.conflicts,'cycles':resolution.cycles,'warnings':resolution.warnings,
                              'diagnostics':program.diagnostics},ensure_ascii=False,indent=2))
            raise SystemExit(0)
        if a.strict and not resolution.complete:
            raise SystemExit('ModPack dependency resolution failed in --strict mode')
        out=compile_modpack(program,a.output,resolution,a.script_api,strict=a.strict)
        report=json.loads((out/'conversion_report.json').read_text(encoding='utf-8'))
        print(json.dumps({'mode':'modpack','input_kind':kind,'status':report['status'],'mods':len(resolution.ordered),'missing':len(resolution.missing),'conflicts':len(resolution.conflicts),'cycles':len(resolution.cycles),
                          'primary_pack':report.get('primary_pack'),'activation':report.get('activation'),'failure_first':report.get('compatibility_plan',{}).get('failure_first',{})},ensure_ascii=False))
    finally:
        import shutil
        shutil.rmtree(tmp,ignore_errors=True)
elif kind in {'java_resource_pack','java_shaderpack','bedrock_resource_pack'}:
    out=compile_resource_pack(src,a.output,kind)
    print(json.dumps(json.loads((out/'conversion_report.json').read_text(encoding='utf-8')),ensure_ascii=False))
else:
    info,program=build_ir(src)
    if a.analyze_only:
        print(json.dumps({'mode':'mod','input_kind':kind,'info':info,'mod_id':program.mod_id,'version':program.version,
                          'operations':len(program.operations),'diagnostics':program.diagnostics,
                          'statuses':{s:sum(1 for o in program.operations if o.status==s) for s in ('convertible','emulated','adaptable','incompatible')}},ensure_ascii=False,indent=2))
        raise SystemExit(0)
    out=compile_program(program,a.output,a.script_api)
    report=json.loads((out/'conversion_report.json').read_text(encoding='utf-8'))
    print(json.dumps({'info':info,'status':report.get('status'),'primary_pack':report.get('primary_pack'),'activation':report.get('activation'),
                      'failure_first':report.get('compatibility_plan',{}).get('failure_first',{}),'mechanics_source_matrix':report.get('compatibility_plan',{}).get('mechanics_source_matrix',[])},ensure_ascii=False))
