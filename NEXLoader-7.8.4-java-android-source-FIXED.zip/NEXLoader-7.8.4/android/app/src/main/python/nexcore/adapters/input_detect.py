from __future__ import annotations
import json, zipfile
from pathlib import Path, PurePosixPath
from .loader import detect


def _zip_names(path):
    try:
        with zipfile.ZipFile(path) as z:
            return set(z.namelist())
    except Exception:
        return set()


def detect_input_kind(path: str|Path, force_modpack: bool=False) -> str:
    """Classify an input before conversion so ZIP/MCpack/resource packs are not
    accidentally routed through the ModPack path."""
    p=Path(path)
    if force_modpack:
        return 'modpack'
    if p.is_dir():
        if (p/'pack.mcmeta').is_file() and (p/'assets').is_dir():
            return 'java_resource_pack'
        mf=p/'manifest.json'
        if mf.is_file():
            try:
                d=json.loads(mf.read_text(encoding='utf-8'))
                types={str(m.get('type')) for m in (d.get('modules') or []) if isinstance(m,dict)}
                if 'resources' in types and 'data' not in types:
                    return 'bedrock_resource_pack'
            except Exception:
                pass
        return 'modpack'
    ext=p.suffix.lower()
    if ext=='.jar': return 'java_mod'
    if ext=='.mrpack' or ext=='.modpack': return 'modpack'
    if ext=='.mcpack': return 'bedrock_resource_pack'
    if ext=='.mcaddon': return 'bedrock_addon'
    if ext=='.zip':
        names=_zip_names(p)
        if 'modrinth.index.json' in names or any(n.startswith('mods/') and n.lower().endswith('.jar') for n in names):
            return 'modpack'
        if ('shaders/' in names or 'shaders' in {n.split('/')[0] for n in names}) and any(PurePosixPath(n).suffix.lower() in {'.vsh','.fsh','.glsl','.vert','.frag','.geom','.comp','.tesc','.tese'} for n in names):
            return 'java_shaderpack'
        if 'pack.mcmeta' in names and any(n.startswith('assets/') for n in names):
            return 'java_resource_pack'
        if 'manifest.json' in names:
            try:
                with zipfile.ZipFile(p) as z:
                    d=json.loads(z.read('manifest.json').decode('utf-8'))
                types={str(m.get('type')) for m in (d.get('modules') or []) if isinstance(m,dict)}
                if 'resources' in types and 'data' not in types:
                    return 'bedrock_resource_pack'
                if 'resources' in types and 'data' in types:
                    return 'bedrock_addon'
            except Exception:
                pass
        # A ZIP containing a loader manifest is still a standalone Java mod.
        if {'fabric.mod.json','quilt.mod.json'} & names or 'META-INF/mods.toml' in names or 'META-INF/neoforge.mods.toml' in names:
            return 'java_mod'
        return 'modpack'
    return 'java_mod'
