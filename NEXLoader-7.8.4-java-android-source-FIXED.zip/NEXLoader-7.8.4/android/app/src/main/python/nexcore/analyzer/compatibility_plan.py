from __future__ import annotations
from collections import Counter
from .failure_predictor import predict_failures


def build_plan(program):
    """Turn raw analysis into a deterministic conversion plan before packaging."""
    status_counts=Counter(o.status for o in program.operations)
    ops_by_kind=Counter(o.op for o in program.operations)
    blockers=[]; adaptations=[]; safe=[]
    for o in program.operations:
        rec={'id':o.id,'op':o.op,'status':o.status,'source':o.source,'loader':o.source_loader}
        if o.status=='incompatible': blockers.append(rec)
        elif o.status=='adaptable': adaptations.append(rec)
        else: safe.append(rec)
    # Detect mods that are likely client-only and therefore legitimately have no
    # world content. This prevents treating "nothing spawned" as a compiler failure.
    world_content=sum(ops_by_kind[k] for k in ('register_block','register_item','register_entity','register_recipe','register_loot_table','register_function','event','spawn_body','register_worldgen'))
    client_surface=sum(ops_by_kind[k] for k in ('feature_profile','performance_profile','mixin','entrypoint','hud_overlay','ui_screen','keybind'))
    diagnostics=list(program.diagnostics)
    zero_world_content = world_content==0 and client_surface>0
    if zero_world_content:
        diagnostics.append({'code':'CLIENT_SURFACE_ONLY','message':'Input exposes client/UI/optimization behavior but no directly spawnable world content was recovered; this can be valid for HUD, renderer, minimap, shader, or optimization mods.'})
    confidence='high'
    if blockers: confidence='low'
    elif adaptations or any(x.status=='unknown' for x in program.operations): confidence='medium'
    failure_analysis=predict_failures(program)
    return {
        'status_counts':dict(sorted(status_counts.items())),
        'operation_counts':dict(sorted(ops_by_kind.items())),
        'world_content_operations':world_content,
        'client_surface_operations':client_surface,
        'client_surface_only':zero_world_content,
        'confidence':confidence,
        'blockers':blockers[:500],
        'adaptations':adaptations[:1000],
        'safe_operations':safe[:1000],
        'preflight_order':['input classification','loader/dependency scan','resource scan','bytecode mechanics scan','capability classification','semantic lowering','reference repair','output validation'],
        'diagnostics':diagnostics[-1000:],
        'failure_first':failure_analysis,
    }
