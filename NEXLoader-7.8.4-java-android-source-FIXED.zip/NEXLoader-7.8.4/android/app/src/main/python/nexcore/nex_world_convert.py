from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from world.converter import analyze_world, convert_java_world
from world.chunker_engine import DEFAULT_TARGET

p = argparse.ArgumentParser(description="NEXLoader Java world -> Bedrock .mcworld converter")
sub = p.add_subparsers(dest="command", required=True)

a = sub.add_parser("analyze", help="probe a Java world without converting it")
a.add_argument("input", help="Java world folder or .zip")
a.add_argument("--chunker-jar", default=None)

c = sub.add_parser("convert", help="convert Java world to a Bedrock .mcworld")
c.add_argument("input", help="Java world folder or .zip")
c.add_argument("output", help="output directory")
c.add_argument("--target", default=DEFAULT_TARGET)
c.add_argument("--chunker-jar", default=None)
c.add_argument("--timeout", type=int, default=1800)
c.add_argument("--converter-settings", default=None)

args = p.parse_args()
if args.command == "analyze":
    print(json.dumps(analyze_world(args.input, chunker_jar=args.chunker_jar), ensure_ascii=False, indent=2))
else:
    print(json.dumps(convert_java_world(
        args.input, args.output, target=args.target,
        chunker_jar=args.chunker_jar, timeout=max(60, args.timeout),
        converter_settings=args.converter_settings,
    ), ensure_ascii=False, indent=2))
