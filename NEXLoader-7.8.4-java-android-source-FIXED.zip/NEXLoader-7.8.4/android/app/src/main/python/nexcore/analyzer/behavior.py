from nex.ir import Operation
from pathlib import Path
import re
from .classfile import parse, code_scan
from compat.analyzer import analyze_call

FORGE_DEFERRED_REGISTER_OWNERS={
    'net/minecraftforge/registries/DeferredRegister',
    'net/minecraftforge/registries/DeferredRegisterImpl',
}

JAVA_GOAL_TO_BEDROCK = {
    'RandomStrollGoal': 'minecraft:behavior.random_stroll',
    'WaterAvoidingRandomStrollGoal': 'minecraft:behavior.random_stroll',
    'RandomLookAroundGoal': 'minecraft:behavior.random_look_around',
    'LookAtPlayerGoal': 'minecraft:behavior.look_at_player',
    'MeleeAttackGoal': 'minecraft:behavior.melee_attack',
    'FloatGoal': 'minecraft:behavior.float',
    'PanicGoal': 'minecraft:behavior.panic',
    'RandomSwimmingGoal': 'minecraft:behavior.random_swimming',
}


def _goal_short(owner):
    return str(owner or '').replace('.', '/').split('/')[-1]

def _sound_role(caller):
    n=str(caller or '').lower()
    if n in {'hurt','handlehurt','onhurt','damage','actuallyhurt'} or 'hurt' in n: return 'hurt'
    if n in {'die','ondeath','death','killed','removed'} or 'death' in n or n == 'remove': return 'death'
    if n in {'tick','servertick','clienttick'}: return 'tick'
    if n in {'customserverai','ai_step','aiStep'.lower()}: return 'ambient'
    return None


def _sanitize_identifier(value: str) -> str:
    value = re.sub(r'[^a-z0-9_.-]+', '_', str(value).lower())
    value = re.sub(r'_+', '_', value).strip('_.-')
    return value or 'unknown'

def _registration_id(ids, namespace, fallback):
    """Recover a Bedrock-safe registration id from bytecode string constants.
    Prefer fully-qualified ids, then plausible simple names. Never return 'unknown'.
    """
    strings = [x for x in (ids or []) if isinstance(x, str) and x]
    full = next(
        (x for x in reversed(strings)
         if re.fullmatch(r'[A-Za-z0-9_.-]+:[A-Za-z0-9_/.-]+', x)),
        None,
    )
    if full:
        return full.lower()
    simple = next(
        (x for x in reversed(strings)
         if re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,63}', x)
         and x.lower() not in {'unknown', 'register', 'build', 'create', 'of'}),
        None,
    )
    if simple:
        return f'{namespace}:{_sanitize_identifier(simple)}' if namespace else _sanitize_identifier(simple)
    return fallback

FABRIC_TICK_OWNERS={
 'net/fabricmc/fabric/api/event/lifecycle/v1/ServerTickEvents$EndTick':'server_tick',
 'net/fabricmc/fabric/api/event/lifecycle/v1/ServerTickEvents$StartTick':'server_tick',
}

def analyze_classes(entries, diagnostics=None, namespace=None):
    ops=[]
    diagnostics = diagnostics if diagnostics is not None else []
    namespace = str(namespace or '').strip() or None
    for source,data in entries:
        try:
            p=parse(data)
        except Exception as exc:
            diagnostics.append({'code':'CLASSFILE_PARSE_FAILED','message':str(exc),'source':source})
            continue
        method_calls = {}
        method_has_entity_builder = {}
        for candidate in p['methods']:
            ccalls = code_scan(p, candidate)
            key = (candidate.get('name'), candidate.get('descriptor'))
            method_calls[key] = ccalls
            method_has_entity_builder[key] = any(
                'EntityType' in (c.get('owner') or '')
                and (
                    'Builder' in (c.get('owner') or '')
                    or c.get('name') in {'create','build','of'}
                )
                for c in ccalls
            )

        for m in p['methods']:
            calls=method_calls.get((m.get('name'),m.get('descriptor')),[])
            has_entity_builder=method_has_entity_builder.get((m.get('name'),m.get('descriptor')),False)
            for call_index, c in enumerate(calls):
                cap_op = analyze_call(c, 'java', source)
                if cap_op:
                    ops.append(cap_op)
                owner,name=c.get('owner'),c.get('name')
                if cap_op and cap_op.id == 'client.input':
                    hints=' '.join(c.get('near_strings') or []).lower()
                    button='Jump' if 'jump' in hints else ('Sneak' if 'sneak' in hints or 'shift' in hints else None)
                    ops.append(Operation('keybind', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'),
                        'button_hint': button, 'hints': c.get('near_strings') or []
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'ui.screen':
                    title=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('ui_screen', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'), 'title_hint': title
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'audio.play':
                    hints=(c.get('near_strings') or []) + (c.get('constant_hints') or [])
                    sound_hint=next((x for x in reversed(hints) if isinstance(x,str) and (':' in x or '/' in x or x.endswith(('.ogg','.wav','.fsb')))), None)
                    caller=m.get('name')
                    ops.append(Operation('sound_play', f'{owner}.{name}', {
                        'owner':owner, 'method':name, 'descriptor':c.get('descriptor'),
                        'sound_hint':sound_hint, 'hints':hints, 'caller_method':caller,
                        'caller_class':p.get('this'), 'sound_role':_sound_role(caller),
                    }, 'convertible', 'java', source))
                elif cap_op and cap_op.id == 'scoreboard':
                    ops.append(Operation('scoreboard_op', f'{owner}.{name}', {
                        'owner':owner, 'method':name, 'descriptor':c.get('descriptor'),
                        'hints':(c.get('near_strings') or []) + (c.get('constant_hints') or [])
                    }, 'convertible', 'java', source))
                elif cap_op and cap_op.id == 'client.hud':
                    ops.append(Operation('hud_overlay', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor')
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'particle.spawn':
                    particle=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('particle', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'), 'particle_hint': particle
                    }, 'convertible', 'java', source))

                # Recover actual Java mob goals from bytecode. We only lower goals that
                # have a direct, non-dangerous Bedrock analogue; arbitrary/custom goals
                # remain audit metadata rather than becoming invented AI.
                goal_ctor = c.get('goal_constructor')
                if goal_ctor:
                    gshort=_goal_short(goal_ctor.get('owner'))
                    bkey=JAVA_GOAL_TO_BEDROCK.get(gshort)
                    if bkey:
                        args={'entity_class':p.get('this'),'java_goal':gshort,'bedrock_behavior':bkey,
                              'goal_owner':goal_ctor.get('owner'),'goal_descriptor':goal_ctor.get('descriptor'),
                              'priority_hint':c.get('goal_priority_hint'),
                              'constant_hints':c.get('constant_hints') or []}
                        ops.append(Operation('entity_behavior',f'{p["this"]}:{gshort}:{c.get("offset",call_index)}',args,'emulated','java',source))

                # Renderer texture references often live only in Java code. A string such
                # as textures/entity/mimicer.png is enough to bind the real JAR texture
                # without inventing a cube or fallback PNG.
                caller_name=str(m.get('name') or '').lower()
                if 'texturelocation' in caller_name or caller_name in {'gettexture','gettexturepath'}:
                    hints=[x for x in (c.get('near_strings') or []) + (c.get('constant_hints') or []) if isinstance(x,str)]
                    tex_hint=next((x for x in reversed(hints) if 'textures/' in x.lower() and x.lower().endswith('.png')),None)
                    if tex_hint:
                        tex_hint=tex_hint.lstrip('/')
                        rel=tex_hint.split('textures/',1)[-1].removesuffix('.png')
                        ent=p.get('this','').split('.')[-1]
                        ent=re.sub(r'(Renderer|EntityRenderer|Render|Layer)$','',ent) or ent
                        ops.append(Operation('register_entity_visual',f'{namespace}:{_sanitize_identifier(ent)}',
                                             {'entity_class':p.get('this'),'name':_sanitize_identifier(ent),
                                              'texture_id':f'{namespace}:{rel}','texture_hint':tex_hint,
                                              'source_kind':'java_renderer'},'convertible','java',source))

                if owner in FABRIC_TICK_OWNERS and name=='register':
                    cb=c.get('callback_target') or {}
                    ops.append(Operation('event',FABRIC_TICK_OWNERS[owner],{
                        'method':m['name'],'callback':cb
                    },'convertible','fabric',source))
                elif owner=='net/minecraft/world/World' and name=='sendMessage':
                    msg=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('world_message',f'{p["this"]}.{m["name"]}',{
                        'method':m['name'],'message':msg
                    },'convertible' if msg else 'adaptable','java',source))
                elif owner=='net/minecraft/registry/Registry' and name=='register':
                    ids=c.get('near_strings') or []
                    fallback=f'{namespace}:{_sanitize_identifier(Path(source).stem)}_{_sanitize_identifier(m.get("name") or "register")}_{call_index}' if namespace else f'unknown:entity_{call_index}'
                    reg_id=_registration_id(ids, namespace, fallback)
                    callback = c.get('callback_target') or {}
                    callback_key = (callback.get('name'), callback.get('descriptor'))
                    callback_has_entity_builder = method_has_entity_builder.get(callback_key, False)
                    entity_builder = has_entity_builder or callback_has_entity_builder
                    if entity_builder:
                        ops.append(Operation('register_entity',reg_id,{
                            'method':m['name'], 'owner':owner, 'near_strings':ids,
                            'callback_target':callback,
                            'entity_builder_detected':True, 'loader_hint':'java',
                            'entity_class':callback.get('owner') if isinstance(callback,dict) else None
                        },'emulated','java',source))
                    elif reg_id != fallback:
                        ops.append(Operation('register_content',reg_id,{
                            'method':m['name'], 'near_strings':ids
                        },'adaptable','java',source))
                    else:
                        diagnostics.append({
                            'code':'REGISTRY_REGISTER_ID_UNRECOVERED',
                            'message':f'Ignored Java Registry.register without a recoverable id: {reg_id}',
                            'source':source
                        })
                elif owner in FORGE_DEFERRED_REGISTER_OWNERS and name=='register':
                    ids=c.get('near_strings') or []
                    fallback=f'{namespace}:{_sanitize_identifier(Path(source).stem)}_{_sanitize_identifier(m.get("name") or "register")}_{call_index}' if namespace else f'unknown:entity_{call_index}'
                    reg_id=_registration_id(ids, namespace, fallback)
                    callback = c.get('callback_target') or {}
                    callback_key = (callback.get('name'), callback.get('descriptor'))
                    callback_has_entity_builder = method_has_entity_builder.get(callback_key, False)
                    entity_builder = has_entity_builder or callback_has_entity_builder
                    if entity_builder:
                        ops.append(Operation('register_entity',reg_id,{
                            'method':m['name'], 'owner':owner, 'near_strings':ids,
                            'callback_target':callback,
                            'entity_builder_detected':True, 'loader_hint':'forge',
                            'registration_style':'DeferredRegister',
                            'entity_class':callback.get('owner') if isinstance(callback,dict) else None
                        },'emulated','forge',source))
                        diagnostics.append({
                            'code':'FORGE_ENTITY_REGISTRATION_RECOVERED',
                            'message':f'Recovered Forge DeferredRegister entity {reg_id}',
                            'source':source
                        })
                    elif reg_id != fallback:
                        ops.append(Operation('register_content',reg_id,{
                            'method':m['name'], 'near_strings':ids,
                            'registration_style':'DeferredRegister'
                        },'adaptable','forge',source))
                    else:
                        diagnostics.append({
                            'code':'FORGE_REGISTER_ID_UNRECOVERED',
                            'message':f'Ignored Forge DeferredRegister.register without a recoverable id: {reg_id}',
                            'source':source
                        })
                elif owner=='net/minecraftforge/eventbus/api/IEventBus' and name in ('addListener','addGenericListener'):
                    ops.append(Operation('event',f'forge:{name}',{
                        'method':m['name'],'callback':c.get('callback_target') or {}
                    },'adaptable','forge',source))
    # Bind sound calls to known event callbacks when the Java bytecode exposes the
    # same owner/name/descriptor. This enables safe automatic lowering for callbacks
    # where a Bedrock execution context can be reconstructed; unrelated sound calls
    # remain exported helpers instead of being guessed.
    event_targets={(e.args.get('callback') or {}).get('name'):(e.args.get('callback') or {}).get('descriptor') for e in ops if e.op=='event'}
    for op in ops:
        if op.op=='sound_play':
            key=op.args.get('method')
            desc=op.args.get('descriptor')
            if key in event_targets and event_targets[key] == desc:
                op.args['bound_event_method']=key

    parsed_by_class = {}
    for source2, data2 in entries:
        try:
            pp=parse(data2); parsed_by_class[pp.get('this')]=pp
        except Exception:
            continue
    for op in ops:
        if op.op != 'register_entity':
            continue
        cls=op.args.get('entity_class') or ''
        if not cls:
            # Fallback: recover an entity class from any builder-like invocation in
            # the registration source class. This remains source-derived metadata.
            cls_candidates=[]
            for src2,data2 in entries:
                if src2 != op.source: continue
                try: pp=parse(data2)
                except Exception: continue
                for mm in pp['methods']:
                    for cc in code_scan(pp,mm):
                        if 'EntityType' in (cc.get('owner') or '') and ('Builder' in (cc.get('owner') or '') or cc.get('name') in {'create','build','of'}):
                            cb=cc.get('callback_target') or {}
                            if cb.get('owner'): cls_candidates.append(cb.get('owner'))
            if cls_candidates: cls=sorted(set(cls_candidates))[0]
        if cls:
            chain=[]; cur=cls; seen=set()
            while cur and cur not in seen:
                seen.add(cur); chain.append(cur); cur=(parsed_by_class.get(cur) or {}).get('super')
            op.args['entity_class']=cls
            op.args['class_hierarchy']=chain
            op.args['super_class']=(chain[1] if len(chain)>1 else (parsed_by_class.get(cls) or {}).get('super'))

    # Java compilers may expose one registry operation through bridge/synthetic/lambda methods.
    # Keep the first registration hint and discard exact duplicates so a duplicated
    # semantic observation never aborts an otherwise valid conversion.
    deduped=[]; seen_reg=set()
    for op in ops:
        if op.op.startswith('register_'):
            key=(op.op, op.id)
            if key in seen_reg:
                diagnostics.append({'code':'DUPLICATE_REGISTRATION_HINT_IGNORED',
                                    'message':f'Ignored duplicate semantic registration hint {op.op}:{op.id}',
                                    'source':op.source})
                continue
            seen_reg.add(key)
        deduped.append(op)
    return deduped
