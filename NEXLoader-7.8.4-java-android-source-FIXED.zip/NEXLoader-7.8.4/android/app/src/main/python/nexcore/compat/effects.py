from dataclasses import dataclass

@dataclass
class EffectRequest:
    target: str
    effect: str
    duration_ticks: int
    amplifier: int = 0
    show_particles: bool = True

    def validate(self):
        if self.duration_ticks < 1:
            raise ValueError('duration_ticks must be >= 1')
        if self.amplifier < 0:
            raise ValueError('amplifier must be >= 0')


def emit_add_effect(req: EffectRequest) -> str:
    req.validate()
    particles='true' if req.show_particles else 'false'
    return (
        f"{req.target}.addEffect({req.effect!r}, {req.duration_ticks}, "
        f"{{ amplifier: {req.amplifier}, showParticles: {particles} }});"
    )
