from __future__ import annotations
from collections import Counter
from pathlib import PurePosixPath
import re

PERFORMANCE_IDS={
    'sodium':'java_renderer_optimization', 'embeddium':'java_renderer_optimization',
    'rubidium':'java_renderer_optimization', 'optifine':'java_renderer_optimization',
    'iris':'java_shader_pipeline', 'oculus':'java_shader_pipeline',
    'lithium':'server_logic_optimization', 'ferritecore':'memory_optimization',
    'modernfix':'startup_memory_optimization', 'immediatelyfast':'gui_render_optimization',
    'entityculling':'visibility_culling', 'moreculling':'visibility_culling',
    'starlight':'lighting_engine_optimization', 'c2me':'chunk_thread_optimization',
    'krypton':'network_optimization', 'noisium':'worldgen_optimization',
}

JAVA_SHADER_EXT={'.vsh','.fsh','.glsl','.vert','.frag','.geom','.comp','.tesc','.tese'}
JAVA_RENDER_TERMS=('render','renderer','renderlayer','opengl','gl11','blaze3d','shader','vertexbuffer','frustum')
RISK_TERMS={
    'reflection':('java/lang/reflect','java.lang.reflect','Class.forName','MethodHandles'),
    'file_io':('java/nio/file','java/io/','Files.read','Files.write','FileInputStream','FileOutputStream'),
    'network':('java/net/','java/net/http','HttpClient','Socket','URLConnection','WebSocket'),
    'native':('System.load','System.loadLibrary','JNI','Unsafe'),
    'threads':('java/lang/Thread','Executor','ForkJoin','CompletableFuture'),
    'classloading':('ClassLoader','defineClass','URLClassLoader'),
}

def _name_hits(text, terms):
    low=text.lower(); return sorted({t for t in terms if t.lower() in low})

def audit_names(names, mod_id='unknown'):
    names=list(names or [])
    ext=Counter(PurePosixPath(n).suffix.lower() for n in names if '.' in PurePosixPath(n).name)
    cats={
        'classes':sum(n.endswith('.class') for n in names),
        'textures':sum(('/textures/' in n.lower()) and PurePosixPath(n).suffix.lower() in {'.png','.jpg','.jpeg','.tga'} for n in names),
        'models':sum('/models/' in n.lower() and n.lower().endswith('.json') for n in names),
        'blockstates':sum('/blockstates/' in n.lower() and n.lower().endswith('.json') for n in names),
        'functions':sum(n.lower().endswith('.mcfunction') for n in names),
        'sounds':sum(('/sounds/' in n.lower()) and PurePosixPath(n).suffix.lower() in {'.ogg','.wav','.fsb'} for n in names),
        'languages':sum('/lang/' in n.lower() for n in names),
        'recipes':sum(('/recipe/' in n.lower() or '/recipes/' in n.lower()) and n.lower().endswith('.json') for n in names),
        'loot':sum(('/loot_table/' in n.lower() or '/loot_tables/' in n.lower()) and n.lower().endswith('.json') for n in names),
        'worldgen':sum('/worldgen/' in n.lower() and n.lower().endswith('.json') for n in names),
        'advancements':sum('/advancement/' in n.lower() and n.lower().endswith('.json') for n in names),
        'mixins':sum('mixin' in n.lower() and n.lower().endswith('.json') for n in names),
        'pbr':sum(n.lower().endswith('.texture_set.json') or n.lower().endswith('_mer.png') or n.lower().endswith('_normal.png') or n.lower().endswith('_height.png') for n in names),
        'shader_files':sum((PurePosixPath(n).suffix.lower() in JAVA_SHADER_EXT or '/shaders/' in n.lower()) for n in names),
        'fonts':sum('/font/' in n.lower() for n in names),
        'configs':sum(n.lower().startswith('config/') for n in names),
    }
    lowid=str(mod_id or '').lower()
    detected={}
    name_text=' '.join(str(n).lower() for n in names)
    for key,profile in PERFORMANCE_IDS.items():
        if key in lowid or re.search(rf'(^|[/_.-]){re.escape(key)}([/_.-]|$)', name_text): detected[key]=profile
    if any('/shaders/' in n.lower() for n in names): detected.setdefault('shaderpack_files','java_shaderpack_files')
    if any('sodium' in n.lower() for n in names): detected.setdefault('sodium','java_renderer_optimization')
    if any(x in lowid for x in ('jade','jode','waila','hwyla')) or any(x in name_text for x in ('jade','jode','waila','hwyla')): detected['hud_inspection']='hud_reconstruction_candidate'
    if 'xaero' in lowid or 'xaero' in name_text or any('minimap' in n.lower() for n in names): detected['minimap']='map_reconstruction_candidate'
    return {'file_counts':cats,'extensions':dict(sorted(ext.items())),'profiles':dict(sorted(detected.items()))}

def audit_class_calls(operations):
    owners=[]; unknown=[]; risks=[]; capabilities=Counter()
    for o in operations or []:
        if o.op!='capability': continue
        capabilities[o.id]+=1
        owner=str(o.args.get('owner') or '')
        name=str(o.args.get('name') or '')
        owners.append(f'{owner}.{name}')
        target=(owner+' '+name).lower()
        for risk,terms in RISK_TERMS.items():
            if any(t.lower() in target for t in terms): risks.append((risk,owner,name))
        if any(t in target for t in JAVA_RENDER_TERMS) and o.id not in {'render.custom','shader.java_pipeline','client.hud'}:
            risks.append(('render_surface',owner,name))
    return {'capability_counts':dict(sorted(capabilities.items())), 'risk_calls':[{'risk':a,'owner':b,'name':c} for a,b,c in sorted(set(risks))], 'capability_owners':sorted(set(owners))}


def audit_bytecode_surface(entries):
    from .classfile import parse, code_scan
    method_roles=Counter(); unknown=[]; risky=[]; total_calls=0
    for source,data in entries or []:
        try: parsed=parse(data)
        except Exception: continue
        for m in parsed.get('methods',[]):
            name=str(m.get('name') or '')
            low=name.lower()
            for role,terms in {
                'tick':('tick','ontick','aitick','servertick','clienttick'),
                'render':('render','draw','shader'),
                'register':('register','initialize','init'),
                'combat':('attack','hurt','damage','die','death'),
                'ai':('ai','goal','pathfind'),
                'input':('key','mouse','input'),
            }.items():
                if any(t in low for t in terms): method_roles[role]+=1
            calls=code_scan(parsed,m); total_calls+=len(calls)
            for c in calls:
                owner=str(c.get('owner') or ''); cname=str(c.get('name') or '')
                target=(owner+'.'+cname).lower()
                if any(t in target for t in ('unsafe','reflect','classloader','native','opengl','gl11','blaze3d','socket','httpclient','urlconnection','executor','thread')):
                    risky.append({'owner':owner,'name':cname,'source':source,'offset':c.get('offset')})
                # Calls not covered by a capability still matter; keep a bounded sample for diagnostics.
                if owner and cname and any(root_term in target for root_term in ('render','shader','network','world','entity','scoreboard','registry','event','config','command')):
                    unknown.append({'owner':owner,'name':cname,'source':source,'offset':c.get('offset')})
    return {'total_calls':total_calls,'method_roles':dict(sorted(method_roles.items())),
            'risky_calls':risky[:500],'surface_calls':unknown[:500]}

MECHANIC_TERMS = {
    'entity_ai': ('goal','ai','pathfinder','pathfinding','navigation','brain','sensor','behavior'),
    'combat': ('attack','hurt','damage','knockback','death','health','armor'),
    'movement': ('move','velocity','teleport','travel','jump','swim','fly','fall'),
    'world': ('level','world','chunk','biome','dimension','block','fluid'),
    'inventory': ('inventory','container','slot','itemstack','recipe'),
    'scoreboard': ('scoreboard','objective','score','display slot'),
    'audio': ('sound','music','voice','playsound'),
    'particles': ('particle','particles','dust'),
    'rendering': ('render','renderer','renderlayer','opengl','blaze3d','vertex','frustum'),
    'shaders': ('shader','glsl','program','uniform','framebuffer'),
    'networking': ('packet','network','socket','http','channel','payload'),
    'input': ('key','keyboard','mouse','input','controller','gamepad'),
    'ui_hud': ('screen','gui','hud','overlay','widget','toast','title','actionbar'),
    'configuration': ('config','configuration','option','setting'),
    'commands': ('command','dispatcher','brigadier','argument'),
    'registration': ('register','registry','bootstrap'),
    'worldgen': ('worldgen','feature','placement','carver','structure','noise'),
    'datapack': ('function','predicate','loot','advancement','tag'),
    'automation': ('schedule','tick','timer','executor','thread','future'),
}

CLIENT_TERMS = ('client','render','renderer','screen','hud','gui','keybind','keymapping','mouse','shader','opengl','minecraftclient')
SERVER_TERMS = ('server','world','level','command','registry','datagen','serverlevel','dedicatedserver')

def _term_hits(text, mapping):
    low=str(text or '').lower()
    return [k for k,v in mapping.items() if any(t in low for t in v)]

def analyze_mechanics(entries):
    """Second-pass bytecode audit aimed at finding mechanics before lowering.

    This intentionally does not try to execute Java bytecode. It records where the
    mechanics live (method, bytecode line, call owner/name) so the lowerer can make
    conservative choices instead of guessing.
    """
    from .classfile import parse, code_scan
    counts=Counter(); method_counts=Counter(); loader_surfaces={'client':0,'server':0,'mixed':0}
    findings=[]; risky=[]; complexity=[]
    for source,data in entries or []:
        try: p=parse(data)
        except Exception: continue
        cls=p.get('this') or ''
        for m in p.get('methods',[]):
            mn=str(m.get('name') or '')
            method_text=f'{cls}.{mn}'
            roles=_term_hits(method_text,MECHANIC_TERMS)
            if roles:
                for role in roles: counts[role]+=1; method_counts[(role,method_text)]+=1
            low=method_text.lower()
            client=any(t in low for t in CLIENT_TERMS); server=any(t in low for t in SERVER_TERMS)
            if client and server: loader_surfaces['mixed']+=1
            elif client: loader_surfaces['client']+=1
            elif server: loader_surfaces['server']+=1
            calls=code_scan(p,m)
            code_len=len((m.get('code') or {}).get('bytes') or b'')
            branch_count=0; backward_branches=0
            # Lightweight opcode scan for conditional/goto branch density.
            b=(m.get('code') or {}).get('bytes') or b''
            pc=0
            fixed={16:2,17:3,18:2,19:3,20:3,21:2,22:2,23:2,24:2,25:2,54:2,55:2,56:2,57:2,58:2,84:1,132:3,
                   153:3,154:3,155:3,156:3,157:3,158:3,159:3,160:3,161:3,162:3,163:3,164:3,165:3,166:3,167:3,168:3,
                   178:3,179:3,180:3,181:3,187:3,188:2,189:3,192:3,193:3,197:4,198:3,199:3,200:5,201:5}
            try:
                while pc < len(b):
                    op=b[pc]; size=fixed.get(op,1)
                    if op in range(153,169) or op in {167,168,198,199,200,201}:
                        width=4 if op in {200,201} else 2
                        if pc+1+width<=len(b):
                            rel=int.from_bytes(b[pc+1:pc+1+width],'big',signed=True)
                            branch_count+=1
                            if pc+rel < pc: backward_branches+=1
                    if op==170:
                        pad=(4-((pc+1)&3))&3; base=pc+1+pad
                        if base+12<=len(b):
                            low=int.from_bytes(b[base+4:base+8],'big',signed=True); high=int.from_bytes(b[base+8:base+12],'big',signed=True)
                            size=1+pad+12+4*max(0,high-low+1)
                    elif op==171:
                        pad=(4-((pc+1)&3))&3; base=pc+1+pad
                        if base+8<=len(b):
                            np=int.from_bytes(b[base+4:base+8],'big',signed=False); size=1+pad+8+8*np
                    elif op==196:
                        size=6 if pc+1<len(b) and b[pc+1]==132 else 4
                    if size<1: break
                    pc+=size
            except Exception:
                pass
            if code_len>=512 or branch_count>=16 or backward_branches>=2:
                complexity.append({'source':source,'class':cls,'method':mn,'line':((m.get('code') or {}).get('line_numbers') or [(0,None)])[0][1],'bytecode_bytes':code_len,'branches':branch_count,'backward_branches':backward_branches})
            for c in calls:
                owner=str(c.get('owner') or ''); name=str(c.get('name') or '')
                text=f'{owner}.{name}'
                roles=_term_hits(text,MECHANIC_TERMS)
                risk_roles=[]
                if any(x in text.lower() for x in ('unsafe','jni','loadlibrary','opengl','gl11','socket','httpclient','classloader','reflect','thread','executor')):
                    risk_roles.append('runtime_or_platform_dependency')
                if c.get('unresolved_bootstrap'): risk_roles.append('unresolved_invokedynamic')
                for role in roles:
                    findings.append({'mechanic':role,'source':source,'class':cls,'method':mn,'line':c.get('line'),'offset':c.get('offset'),'owner':owner,'name':name})
                    counts[role]+=1
                if risk_roles:
                    risky.append({'risk':risk_roles,'source':source,'class':cls,'method':mn,'line':c.get('line'),'offset':c.get('offset'),'owner':owner,'name':name,'descriptor':c.get('descriptor')})
    top_methods=[]
    for (role,meth),count in sorted(method_counts.items(), key=lambda x:(-x[1],x[0]))[:300]:
        top_methods.append({'mechanic':role,'method':meth,'hits':count})
    return {
        'mechanic_counts':dict(sorted(counts.items())),
        'top_methods':top_methods,
        'platform_surface_counts':loader_surfaces,
        'complexity_hotspots':sorted(complexity,key=lambda x:(-x['bytecode_bytes'],-x['branches']))[:300],
        'risky_calls':risky[:500],
        'mechanic_calls':findings[:1000],
    }
