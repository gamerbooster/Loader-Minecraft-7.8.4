from __future__ import annotations
import json, re

LOCALE_MAP={
    'en_us':'en_US','en_gb':'en_GB','de_de':'de_DE','ru_ru':'ru_RU','zh_cn':'zh_CN','fr_fr':'fr_FR',
    'it_it':'it_IT','pt_br':'pt_BR','fr_ca':'fr_CA','zh_tw':'zh_TW','es_mx':'es_MX','es_es':'es_ES',
    'pt_pt':'pt_PT','ko_kr':'ko_KR','ja_jp':'ja_JP','nl_nl':'nl_NL','bg_bg':'bg_BG','cs_cz':'cs_CZ',
    'da_dk':'da_DK','el_gr':'el_GR','fi_fi':'fi_FI','hu_hu':'hu_HU','id_id':'id_ID','nb_no':'nb_NO',
    'pl_pl':'pl_PL','sk_sk':'sk_SK','sv_se':'sv_SE','tr_tr':'tr_TR','uk_ua':'uk_UA',
}

def locale_code(stem: str):
    key=stem.lower()
    return LOCALE_MAP.get(key, stem if re.fullmatch(r'[a-z]{2}_[A-Z]{2}',stem) else None)

def parse_lang_json(raw: bytes):
    data=json.loads(raw.decode('utf-8'))
    if not isinstance(data,dict): raise ValueError('language JSON must be an object')
    out={}
    for k,v in sorted(data.items()):
        if isinstance(v,(str,int,float,bool)):
            out[str(k)]=str(v)
    return out
