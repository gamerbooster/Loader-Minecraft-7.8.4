from pathlib import Path
import json

RUNTIME_FILES = {
    'actions.js': '''import { system } from "@minecraft/server";
// NEX semantic action bridge. These helpers are deliberately small and side-effect-safe.
export function addEffect(ctx, effect, duration, amplifier = 0, showParticles = true) {
  if (!ctx?.entity || !effect || !Number.isFinite(Number(duration))) return false;
  ctx.entity.addEffect(String(effect), Math.max(1, Number(duration) | 0), { amplifier: Math.max(0, Number(amplifier) | 0), showParticles: Boolean(showParticles) });
  return true;
}
export function removeEffect(ctx, effect) {
  if (!ctx?.entity || !effect) return false;
  return Boolean(ctx.entity.removeEffect(String(effect)));
}
export function teleport(ctx, location, dimension) {
  if (!ctx?.entity || !location) return false;
  const options = dimension ? { dimension } : undefined;
  ctx.entity.teleport(location, options);
  return true;
}
export function damage(ctx, amount, cause) {
  if (!ctx?.entity || !Number.isFinite(Number(amount))) return false;
  ctx.entity.applyDamage(Number(amount), cause ? { cause: String(cause) } : undefined);
  return true;
}
export function impulse(ctx, vector) {
  if (!ctx?.entity || !vector) return false;
  ctx.entity.applyImpulse({ x: Number(vector.x) || 0, y: Number(vector.y) || 0, z: Number(vector.z) || 0 });
  return true;
}
export function runCommand(ctx, command) {
  if (!ctx?.entity || !command) return undefined;
  return ctx.entity.runCommand(String(command).replace(/^\\s*\\//, ""));
}
export function setDynamicState(ctx, key, value) {
  if (!key) return false;
  const target = ctx?.entity ?? ctx?.world;
  if (!target?.setDynamicProperty) return false;
  target.setDynamicProperty(String(key), value);
  return true;
}
export function schedule(ticks, callback, repeating = false) {
  const n = Math.max(1, Number(ticks) | 0);
  return repeating ? system.runInterval(callback, n) : system.runTimeout(callback, n);
}
''',
    'runtime_core.js': '''// NEX Runtime core for Bedrock scripting\nexport function safeCall(fn) { try { return fn(); } catch (e) { console.warn(`[NEX] ${e}`); return undefined; } }\nexport function sendWorldMessage(world, message) { safeCall(() => world.sendMessage(String(message))); }\n''',
    'physics.js': '''import { system } from "@minecraft/server";\n\nconst clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, Number(n) || 0));\n\nexport function registerBody(body, entities) {\n  if (!body || !Array.isArray(entities)) return body;\n  body.entities = entities.filter(Boolean);\n  return body;\n}\n\nexport function spawnPhysicsBody(dimension, location, options = {}) {\n  if (!dimension?.spawnEntity) return null;\n  const identifier = options.entityType;\n  if (!identifier) throw new Error("[NEX] physics entityType is required");\n  const count = Math.max(1, Math.min(128, Number(options.fragments ?? 1) | 0));\n  const body = {\n    entities: [],\n    gravity: clamp(options.gravity ?? 0.08, 0, 2),\n    restitution: clamp(options.restitution ?? 0.25, 0, 1),\n    drag: clamp(options.drag ?? 0.98, 0, 1),\n    lifetime: Math.max(0, Number(options.lifetime ?? 0) | 0),\n    age: 0\n  };\n  for (let i = 0; i < count; i++) {\n    try {\n      const e = dimension.spawnEntity(identifier, location);\n      body.entities.push(e);\n      const spread = Number(options.spread ?? 0.03);\n      const dx = ((i * 1103515245 + 12345) % 1000) / 1000 - 0.5;\n      const dz = ((i * 214013 + 2531011) % 1000) / 1000 - 0.5;\n      e.applyImpulse?.({ x: dx * spread, y: Number(options.upward ?? 0), z: dz * spread });\n    } catch (_) {}\n  }\n  return body;\n}\n\nexport function startPhysics(world, getBodies) {\n  system.runInterval(() => {\n    const bodies = getBodies?.() ?? [];\n    for (const body of bodies) {\n      if (!body?.entities) continue;\n      body.age = (body.age ?? 0) + 1;\n      for (const entity of body.entities) {\n        try {\n          if (!entity || !entity.isValid) continue;\n          const v = entity.getVelocity?.() ?? { x: 0, y: 0, z: 0 };\n          const dragImpulse = { x: v.x * (body.drag - 1), y: 0, z: v.z * (body.drag - 1) };\n          entity.applyImpulse?.({ x: dragImpulse.x, y: -body.gravity, z: dragImpulse.z });\n          if (entity.isOnGround && v.y < -0.05 && body.restitution > 0) {\n            entity.applyImpulse?.({ x: 0, y: -v.y * body.restitution, z: 0 });\n          }\n          if (typeof entity.setRotation === 'function') {\n            const yaw = Number(entity.getRotation?.().y ?? 0);\n            entity.setRotation({ x: 0, y: yaw + Math.hypot(v.x, v.z) * 8 });\n          }\n        } catch (_) {}\n      }\n      if (body.lifetime > 0 && body.age >= body.lifetime) {\n        for (const entity of body.entities) { try { entity?.remove?.(); } catch (_) {} }\n        body.entities.length = 0;\n      }\n    }\n  }, 1);\n}\n''',
    'effects.js': '''export function addEffect(entity, id, duration, amplifier = 0, showParticles = true) {\n  return entity.addEffect(id, duration, { amplifier, showParticles });\n}\nexport function removeEffect(entity, id) { return entity.removeEffect(id); }\n''',
    'state.js': '''export function setEntityState(entity, key, value) { entity.setDynamicProperty(key, value); }\nexport function setWorldState(world, key, value) { world.setDynamicProperty(key, value); }\n''',
    'sounds.js': '''// NEX sound playback bridge.\nexport function playSoundAt(dimension, soundId, location, options = {}) {\n  if (!dimension?.playSound || !soundId || !location) return false;\n  dimension.playSound(String(soundId), location, options);\n  return true;\n}\nexport function playSoundToPlayer(player, soundId, options = {}) {\n  if (!player?.playSound || !soundId) return false;\n  player.playSound(String(soundId), options);\n  return true;\n}\nexport function broadcastSound(players, soundId, options = {}) {\n  let count = 0;\n  for (const player of players ?? []) { if (playSoundToPlayer(player, soundId, options)) count++; }\n  return count;\n}\n''',
    'scoreboard.js': '''// NEX scoreboard bridge. Objective IDs should be namespaced by the converter.\nexport function getObjective(world, id) { return world?.scoreboard?.getObjective(String(id)); }\nexport function ensureObjective(world, id, displayName = id) {\n  if (!world?.scoreboard) return undefined;\n  return world.scoreboard.getObjective(String(id)) ?? world.scoreboard.addObjective(String(id), String(displayName));\n}\nexport function setScore(objective, participant, value) { return objective?.setScore?.(participant, Number(value) | 0); }\nexport function addScore(objective, participant, value) { return objective?.addScore?.(participant, Number(value) | 0); }\nexport function getScore(objective, participant) { return objective?.getScore?.(participant); }\nexport function removeObjective(world, id) { return world?.scoreboard?.removeObjective?.(String(id)) ?? false; }\n''',
    'scheduler.js': '''import { system } from "@minecraft/server";\nexport function every(ticks, callback) { return system.runInterval(callback, Math.max(1, ticks | 0)); }\nexport function later(ticks, callback) { return system.runTimeout(callback, Math.max(1, ticks | 0)); }\n''',
    'config.js': '''// Generated NEX config registry. Values are static defaults extracted from Java mod jars.\nexport const NEX_CONFIG = Object.freeze({});\nexport function getConfig(modId) { return NEX_CONFIG[modId] ?? {}; }\n''',
    'intermod.js': '''// NEX inter-mod contract registry.\nconst registry = new Map();\nexport const NEX_INTERMOD_CONTRACTS = Object.freeze([]);\nexport function registerModApi(modId, methods) { registry.set(modId, methods ?? {}); }\nexport function hasModApi(modId, method) { return Boolean(registry.get(modId)?.[method]); }\nexport function callModApi(modId, method, ...args) {\n  const fn = registry.get(modId)?.[method];\n  if (typeof fn !== "function") throw new Error(`[NEX] Missing inter-mod API: ${modId}#${method}`);\n  return fn(...args);\n}\n''',
    'input.js': '''// NEX input bridge. Bedrock exposes player button input transitions.\nimport { world } from "@minecraft/server";\n\nexport const INPUT_BUTTONS = Object.freeze({ Jump: "Jump", Sneak: "Sneak" });\nexport function bindButton(button, callback) {\n  return world.afterEvents.playerButtonInput.subscribe((ev) => {\n    if (ev.button === button) callback(ev.player, ev.newButtonState, ev);\n  }, { buttons: [button] });\n}\nexport function bindMappedButton(mapping, callback) {\n  const button = mapping?.button;\n  if (!button || !Object.values(INPUT_BUTTONS).includes(button)) return undefined;\n  return bindButton(button, callback);\n}\n''',
    'particles.js': '''// NEX particle bridge. Bedrock exposes Dimension.spawnParticle and Player.spawnParticle.\nexport function spawnParticle(dimension, effectName, location, molangVariables) {\n  if (!dimension || typeof dimension.spawnParticle !== 'function') return false;\n  dimension.spawnParticle(effectName, location, molangVariables);\n  return true;\n}\nexport function spawnPlayerParticle(player, effectName, location, molangVariables) {\n  if (!player || typeof player.spawnParticle !== 'function') return false;\n  player.spawnParticle(effectName, location, molangVariables);\n  return true;\n}\n''',
    'ui.js': '''// NEX UI reconstruction bridge for @minecraft/server-ui 2.x. Java screens are lowered to Bedrock forms when enough semantics are known.\nimport { ActionFormData, ModalFormData } from "@minecraft/server-ui";\nexport async function showMenu(player, title, body, buttons = []) {\n  const form = new ActionFormData().title(String(title ?? "NEX" )).body(String(body ?? ""));\n  for (const b of buttons) form.button(String(b));\n  return form.show(player);\n}\nexport async function showSettings(player, title, fields = []) {\n  const form = new ModalFormData().title(String(title ?? "NEX"));\n  for (const f of fields) {\n    if (f.type === "toggle") form.toggle(String(f.label), { defaultValue: Boolean(f.default) });\n    else if (f.type === "slider") form.slider(String(f.label), Number(f.min ?? 0), Number(f.max ?? 100), { valueStep: Number(f.step ?? 1), defaultValue: Number(f.default ?? 0) });\n    else if (f.type === "dropdown") form.dropdown(String(f.label), (f.items ?? []).map(String), { defaultValueIndex: Number(f.default ?? 0) });\n    else form.textField(String(f.label), String(f.placeholder ?? ""), { defaultValue: String(f.default ?? "") });\n  }\n  return form.show(player);\n}\n''',
}

def _config_payload(program):
    payload={}
    for o in program.operations:
        if o.op != 'register_config' or o.status == 'incompatible':
            continue
        mod_id=o.args.get('mod_id') or o.id.split(':',1)[0]
        rel=o.args.get('path','config/default')
        value=o.args.get('value')
        payload.setdefault(mod_id, {})[rel]=value if value is not None else {'__raw_hex__':o.args.get('bytes_hex','')}
    return payload

def _intermod_payload(program):
    payload=[]
    for o in program.operations:
        if o.op != 'intermod_call':
            continue
        payload.append({
            'source_mod':o.args.get('source_mod'), 'target_mod':o.args.get('target_mod'),
            'owner':o.args.get('owner'), 'method':o.args.get('method'),
            'descriptor':o.args.get('descriptor'), 'resolved':bool(o.args.get('resolved')),
            'visibility':o.args.get('visibility')
        })
    return payload

def _input_payload(program):
    out=[]
    for o in program.operations:
        if o.op=='keybind':
            out.append({'id':o.id,'button':o.args.get('button_hint'),'owner':o.args.get('owner'),'method':o.args.get('method'),'status':o.status,'source':o.source})
    return out

def emit_runtime(bp_dir: Path, modules: set[str], config_payload=None, intermod_payload=None, input_payload=None):
    root = bp_dir / 'scripts' / 'nex_runtime'
    root.mkdir(parents=True, exist_ok=True)
    for name, text in RUNTIME_FILES.items():
        key = name.rsplit('.',1)[0]
        if key == 'runtime_core' or key in modules:
            if key == 'config' and config_payload is not None:
                text = '// Generated NEX config registry.\nexport const NEX_CONFIG = Object.freeze(' + json.dumps(config_payload, ensure_ascii=False, separators=(',', ':')) + ');\nexport function getConfig(modId) { return NEX_CONFIG[modId] ?? {}; }\n'
            elif key == 'intermod' and intermod_payload is not None:
                text = '// Generated NEX inter-mod contract registry.\nexport const NEX_INTERMOD_CONTRACTS = Object.freeze(' + json.dumps(intermod_payload, ensure_ascii=False, separators=(',', ':')) + ');\n'
            elif key == 'input' and input_payload is not None:
                text = '// Generated NEX input registry.\nexport const NEX_INPUT_MAP = Object.freeze(' + json.dumps(input_payload, ensure_ascii=False, separators=(',', ':')) + ');\nexport function getInputMappings() { return NEX_INPUT_MAP; }\n' + RUNTIME_FILES['input.js']
            (root / name).write_text(text, encoding='utf-8')

def runtime_modules(program):
    mods=set()
    capability_modules={
        'effects.add':'effects', 'effects.remove':'effects',
        'entity.teleport':'actions', 'entity.damage':'actions', 'entity.impulse':'actions',
        'entity.command':'actions', 'entity.dynamic_state':'state',
        'world.dynamic_state':'state', 'tick.schedule':'scheduler',
        'client.input':'input', 'ui.screen':'ui', 'client.hud':'ui',
        'particle.spawn':'particles', 'audio.play':'sounds', 'scoreboard':'scoreboard', 'event.bridge':'actions', 'physics.body':'physics',
        'java.threading':'scheduler',
    }
    for o in program.operations:
        if o.op == 'capability':
            module=capability_modules.get(o.id)
            if module: mods.add(module)
        if o.op in {'register_config','intermod_call'}:
            if o.op == 'register_config': mods.add('config')
            if o.op == 'intermod_call': mods.add('intermod')
            continue
        if o.op == 'keybind': mods.add('input'); continue
        if o.op == 'ui_screen' or o.op == 'hud_overlay': mods.add('ui'); continue
        if o.op == 'particle': mods.add('particles'); continue
        if o.op == 'scoreboard_op': mods.add('scoreboard'); continue
        if o.op == 'sound_play': mods.add('sounds'); continue
        if o.status not in {'emulated','adaptable'}:
            continue
        if (o.op == 'capability' and o.id == 'physics.body') or o.op in {'spawn_body','tick_body'}: mods.add('physics')
        if o.id.startswith('effects.'): mods.add('effects')
        if o.id.endswith('dynamic_state'): mods.add('state')
        if o.id == 'tick.schedule': mods.add('scheduler')
        if o.id == 'client.input': mods.add('input')
        if o.id in {'ui.screen','client.hud'}: mods.add('ui')
        if o.id in {'entity.teleport','entity.damage','entity.impulse','entity.command','event.bridge'}: mods.add('actions')
    return mods
