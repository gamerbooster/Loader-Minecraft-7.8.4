package com.nex.loader;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;
    private static final int REQ_FOLDER = 1002;
    private static final long MAX_SELECTED_INPUT_BYTES = 2L * 1024L * 1024L * 1024L;
    private static final int MAX_SELECTED_TREE_FILES = 100_000;
    private static final long MAX_SELECTED_TREE_BYTES = 2L * 1024L * 1024L * 1024L;

    private TextView status;
    private Button analyzeButton;
    private Button convertButton;
    private Button shareButton;
    private Button openButton;
    private CheckBox fetchExternals;
    private File selectedPath;
    private String selectedName = "nex_input.bin";
    private File lastAddon;
    private Thread conversionThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(getString(R.string.app_name));
        buildUi();
        Intent launchIntent = getIntent();
        if (launchIntent != null && launchIntent.getData() != null) {
            acceptFile(launchIntent.getData());
        }
    }

    @Override
    protected void onDestroy() {
        if (conversionThread != null) {
            conversionThread.interrupt();
            conversionThread = null;
        }
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        // Derive the visible UI version from the same Gradle/BuildConfig version used by the APK.
        // This prevents a hardcoded/stale resource string from making a new APK look like an old release.
        title.setText("NEXLoader " + BuildConfig.VERSION_NAME);
        title.setTextSize(24f);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(getString(R.string.app_subtitle));
        subtitle.setTextSize(15f);
        root.addView(subtitle);

        Button pickFile = new Button(this);
        pickFile.setText(getString(R.string.pick_input));
        pickFile.setOnClickListener(v -> pickInputFile());
        root.addView(pickFile);

        Button pickFolder = new Button(this);
        pickFolder.setText(getString(R.string.pick_folder));
        pickFolder.setOnClickListener(v -> pickInputFolder());
        root.addView(pickFolder);

        fetchExternals = new CheckBox(this);
        fetchExternals.setText(getString(R.string.fetch_externals));
        fetchExternals.setChecked(false);
        root.addView(fetchExternals);

        analyzeButton = new Button(this);
        analyzeButton.setText(getString(R.string.analyze_input));
        analyzeButton.setEnabled(false);
        analyzeButton.setOnClickListener(v -> analyzeSelected());

        convertButton = new Button(this);
        convertButton.setText(getString(R.string.convert_input));
        convertButton.setEnabled(false);
        convertButton.setOnClickListener(v -> convertSelected());

        shareButton = new Button(this);
        shareButton.setText(getString(R.string.share_output));
        shareButton.setEnabled(false);
        shareButton.setOnClickListener(v -> shareAddon());

        openButton = new Button(this);
        openButton.setText(getString(R.string.open_output));
        openButton.setEnabled(false);
        openButton.setOnClickListener(v -> openAddon());

        status = new TextView(this);
        status.setText(getString(R.string.no_input));
        status.setTextSize(14f);

        root.addView(analyzeButton);
        root.addView(convertButton);
        root.addView(shareButton);
        root.addView(openButton);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(status);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(scroll);

        setContentView(root);
        verifyEmbeddedCore();
    }

    private void verifyEmbeddedCore() {
        new Thread(() -> {
            try {
                ensurePython();
                PyObject bridge = Python.getInstance().getModule("nex_android_bridge");
                JSONObject obj = new JSONObject(bridge.callAttr("build_info").toString());
                String coreVersion = obj.optString("nexloader_version", "");
                String apkVersion = BuildConfig.VERSION_NAME;
                if (!apkVersion.equals(coreVersion)) {
                    runOnUiThread(() -> {
                        status.setText("ERROR DE INTEGRIDAD: APK=" + apkVersion + " / CORE=" + coreVersion);
                        analyzeButton.setEnabled(false);
                        convertButton.setEnabled(false);
                    });
                    return;
                }
                runOnUiThread(() -> status.setText("NEXLoader " + apkVersion + "\nNúcleo Python: " + coreVersion + "\nManifest audit: sin metadata.generated_with"));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("ERROR verificando núcleo NEX: " + messageOf(e)));
            }
        }, "nex-core-check").start();
    }

    private void pickInputFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/java-archive",
                "application/zip",
                "application/octet-stream",
                "application/x-zip-compressed",
                "application/x-modrinth-modpack+zip"
        });
        startActivityForResult(intent, REQ_FILE);
    }

    private void pickInputFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_FOLDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_FILE) {
            acceptFile(uri);
        } else if (requestCode == REQ_FOLDER) {
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                if (flags != 0) {
                    getContentResolver().takePersistableUriPermission(uri, flags);
                }
            } catch (Exception ignored) {
            }
            acceptTree(uri);
        }
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } finally {
            if (c != null) c.close();
        }
        return "nex_input.bin";
    }

    private void acceptFile(Uri uri) {
        try {
            String name = displayName(uri);
            File dir = new File(getCacheDir(), "inputs");
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create input cache");
            File dst = new File(dir, sanitize(name));
            long declared = -1L;
            DocumentFile doc = DocumentFile.fromSingleUri(this, uri);
            if (doc != null) declared = doc.length();
            if (declared > MAX_SELECTED_INPUT_BYTES) throw new IllegalArgumentException("Selected file is too large: " + declared + " bytes");
            InputStream input = getContentResolver().openInputStream(uri);
            if (input == null) throw new IllegalStateException("Cannot open selected file");
            try (InputStream in = input; OutputStream out = new FileOutputStream(dst)) {
                copyLimited(in, out, MAX_SELECTED_INPUT_BYTES);
            }
            selectedPath = dst;
            selectedName = name;
            lastAddon = null;
            setReadyState();
            status.setText(getString(R.string.selected_input, name));
        } catch (Exception e) {
            status.setText(getString(R.string.analysis_error, messageOf(e)));
        }
    }

    private void acceptTree(Uri uri) {
        try {
            DocumentFile rootDoc = DocumentFile.fromTreeUri(this, uri);
            if (rootDoc == null) throw new IllegalStateException("Cannot open folder");
            String safeBase = "pack_" + System.currentTimeMillis();
            File base = new File(new File(getCacheDir(), "inputs"), safeBase);
            if (!base.mkdirs()) throw new IllegalStateException("Cannot create folder cache");
            CopyStats stats = new CopyStats();
            copyTree(rootDoc, base, stats, 0);
            selectedPath = base;
            selectedName = rootDoc.getName() == null ? "ModPack" : rootDoc.getName();
            lastAddon = null;
            setReadyState();
            status.setText(getString(R.string.selected_input, selectedName));
        } catch (Exception e) {
            status.setText(getString(R.string.analysis_error, messageOf(e)));
        }
    }

    private static final class CopyStats {
        int files;
        long bytes;
    }

    private void copyTree(DocumentFile doc, File target, CopyStats stats, int depth) throws Exception {
        if (depth > 64) throw new IllegalArgumentException("Folder nesting exceeds safety limit");
        DocumentFile[] children = doc.listFiles();
        if (children == null) return;
        for (DocumentFile child : children) {
            String safeName = sanitize(child.getName() == null ? "unnamed" : child.getName());
            File out = new File(target, safeName);
            if (child.isDirectory()) {
                if (!out.exists() && !out.mkdirs()) throw new IllegalStateException("Cannot create folder " + out);
                copyTree(child, out, stats, depth + 1);
            } else {
                stats.files++;
                if (stats.files > MAX_SELECTED_TREE_FILES) throw new IllegalArgumentException("Folder contains too many files");
                long declared = child.length();
                long remaining = MAX_SELECTED_TREE_BYTES - stats.bytes;
                if (remaining <= 0) throw new IllegalArgumentException("Folder is too large");
                if (declared >= 0 && declared > remaining) throw new IllegalArgumentException("Folder is too large");
                InputStream input = getContentResolver().openInputStream(child.getUri());
                if (input == null) throw new IllegalStateException("Cannot read " + child.getName());
                File parent = out.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IllegalStateException("Cannot create " + parent);
                try (InputStream in = input; OutputStream output = new FileOutputStream(out)) {
                    copyLimited(in, output, remaining);
                }
                stats.bytes += out.length();
                if (stats.bytes > MAX_SELECTED_TREE_BYTES) throw new IllegalArgumentException("Folder is too large");
            }
        }
    }

    private void setReadyState() {
        analyzeButton.setEnabled(true);
        convertButton.setEnabled(true);
        shareButton.setEnabled(false);
        openButton.setEnabled(false);
    }

    private boolean isPackLike(File src) {
        String ext = extension(src.getName());
        return src.isDirectory() || ext.equals("zip") || ext.equals("mrpack") || ext.equals("modpack");
    }

    private void analyzeSelected() {
        final File src = selectedPath;
        if (src == null) return;
        status.setText("Analizando…");
        new Thread(() -> {
            try {
                ensurePython();
                PyObject bridge = Python.getInstance().getModule("nex_android_bridge");
                String raw = bridge.callAttr("analyze", src.getAbsolutePath(), isPackLike(src)).toString();
                JSONObject obj = new JSONObject(raw);
                StringBuilder msg = new StringBuilder();
                msg.append("Modo: ").append(obj.optString("mode")).append('\n');
                msg.append("Estado: ").append(obj.optString("status")).append('\n');
                String loader = obj.optString("loader");
                if (!loader.isEmpty()) msg.append("Loader: ").append(loader).append('\n');
                if (obj.has("mods")) msg.append("Mods: ").append(obj.optInt("mods", 0)).append('\n');
                msg.append("Operaciones: ").append(obj.optInt("operations", 0)).append('\n');
                if (obj.optJSONObject("capability_counts") != null) {
                    msg.append("Capabilities: ").append(obj.optJSONObject("capability_counts")).append('\n');
                }
                JSONArray missing = obj.optJSONArray("missing");
                if (missing != null && missing.length() > 0) msg.append("Dependencias faltantes: ").append(missing.length()).append('\n');
                JSONArray conflicts = obj.optJSONArray("conflicts");
                if (conflicts != null && conflicts.length() > 0) msg.append("Conflictos: ").append(conflicts.length()).append('\n');
                JSONArray cycles = obj.optJSONArray("cycles");
                if (cycles != null && cycles.length() > 0) msg.append("Ciclos: ").append(cycles.length()).append('\n');
                runOnUiThread(() -> status.setText(msg.toString()));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText(getString(R.string.analysis_error, messageOf(e))));
            }
        }, "nex-analyze").start();
    }

    private void convertSelected() {
        final File src = selectedPath;
        if (src == null) return;
        final boolean fetchMissingExternals = fetchExternals.isChecked();
        convertButton.setEnabled(false);
        analyzeButton.setEnabled(false);
        shareButton.setEnabled(false);
        openButton.setEnabled(false);
        status.setText(getString(R.string.converting));

        if (conversionThread != null) conversionThread.interrupt();
        conversionThread = new Thread(() -> {
            try {
                ensurePython();
                File convertedRoot = new File(new File(getCacheDir(), "converted"), Long.toString(System.currentTimeMillis()));
                if (!convertedRoot.mkdirs()) throw new IllegalStateException("Cannot create conversion directory");
                PyObject bridge = Python.getInstance().getModule("nex_android_bridge");
                String raw = bridge.callAttr(
                        "convert",
                        src.getAbsolutePath(),
                        convertedRoot.getAbsolutePath(),
                        isPackLike(src),
                        false,
                        "2.9.0",
                        fetchMissingExternals
                ).toString();
                JSONObject obj = new JSONObject(raw);
                String addonPath = obj.optString("mcaddon");
                lastAddon = addonPath.isEmpty() ? null : new File(addonPath);
                StringBuilder msg = new StringBuilder();
                msg.append("Estado: ").append(obj.optString("status")).append('\n');
                msg.append("Salida: ").append(obj.optString("output_dir")).append('\n');
                JSONArray runtime = obj.optJSONArray("runtime_modules");
                msg.append("Runtime: ").append(runtime == null ? "[]" : runtime.toString()).append('\n');
                msg.append("NEXLoader core: " + BuildConfig.VERSION_NAME + '\n');
                msg.append("Manifest audit: PASS\n");
                if (lastAddon != null) msg.append(getString(R.string.conversion_done, lastAddon.getName()));
                runOnUiThread(() -> {
                    status.setText(msg.toString());
                    convertButton.setEnabled(true);
                    analyzeButton.setEnabled(true);
                    boolean ready = lastAddon != null && lastAddon.isFile();
                    shareButton.setEnabled(ready);
                    openButton.setEnabled(ready);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText(getString(R.string.conversion_error, messageOf(e)));
                    convertButton.setEnabled(true);
                    analyzeButton.setEnabled(true);
                    openButton.setEnabled(false);
                    shareButton.setEnabled(false);
                });
            }
        }, "nex-convert");
        conversionThread.start();
    }

    private void ensurePython() {
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
    }

    private void openAddon() {
        File addon = lastAddon;
        if (addon == null || !addon.isFile()) return;
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", addon);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/zip");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(intent);
        } catch (Exception e) {
            shareAddon();
        }
    }

    private void shareAddon() {
        File addon = lastAddon;
        if (addon == null || !addon.isFile()) return;
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", addon);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, getString(R.string.share_title)));
    }

    private static void copyLimited(InputStream input, OutputStream output, long maxBytes) throws Exception {
        if (maxBytes <= 0) throw new IllegalArgumentException("invalid safety limit");
        byte[] buffer = new byte[1024 * 1024];
        long total = 0L;
        for (;;) {
            long remaining = maxBytes - total;
            if (remaining < 0) throw new IllegalArgumentException("input exceeds safety limit");
            int want = (int) Math.min((long) buffer.length, remaining + 1L);
            int n = input.read(buffer, 0, want);
            if (n < 0) break;
            total += n;
            if (total > maxBytes) throw new IllegalArgumentException("input exceeds safety limit: " + total + " > " + maxBytes);
            output.write(buffer, 0, n);
        }
    }

    private static String sanitize(String name) {
        return name.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private static String extension(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private static String messageOf(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }
}
