// NEX Runtime core for Bedrock scripting
export function safeCall(fn) { try { return fn(); } catch (e) { console.warn(`[NEX] ${e}`); return undefined; } }
export function sendWorldMessage(world, message) { safeCall(() => world.sendMessage(String(message))); }
