# NEXLoader 7.8.4

- Added central bounded ZIP/JAR member reads for the Python core, with per-class and per-JSON limits.
- Embedded Jar-in-Jar extraction now enforces an actual streaming decompression ceiling.
- Java class scanning skips oversized class members with explicit diagnostics instead of buffering them.
- Android PackAnalyzer now uses bounded stream reads for nested JARs and metadata.
- Android file/folder imports now enforce file count, nesting and byte ceilings.
- Android conversion captures the external-download checkbox before entering the worker thread.
- Added regression tests for bounded archive reads and Android input hardening.
- Bumped Android versionCode/versionName and synchronized core metadata to 7.8.3.

## 7.7 hardening retained

- Corrupt Fabric, Quilt, Forge and NeoForge manifests fail explicitly instead of becoming an `unknown` mod.
- Empty ModPacks are marked incomplete with an `EMPTY_MODPACK` diagnostic.
- External Modrinth downloads are verified from streamed temporary files and published atomically only after integrity checks.
- Local Modrinth artifact verification hashes files incrementally.

## 7.7 worldgen retained

- Conservative Java worldgen lowering for simple ore configured features.
- Simple fixed-block worldgen lowering for supported random/vegetal patch providers.
- Simple placed-feature lowering to Bedrock scatter features for count/in-square/biome and uniform absolute height modifiers.
- Generated feature rules can attach converted placed features to converted custom biomes.
- Complex worldgen graphs remain lossless under `nex_untranslated/worldgen/` and explicit as adaptable.

Real APK generation remains gated on an actual Android SDK + Gradle environment and is not claimed unless `assembleDebug` succeeds.


## 7.8.4 V6 fixes
- Prefer original mod PNG artwork for pack icons; no synthetic icon when source artwork exists.
- Entity texture resolver now searches across namespaces and by entity basename before falling back.
- Generated entities use an explicit UV and alphatest material.
- Detect Java sound playback calls for later Bedrock lowering.

## 7.8.4 V7 maintenance

- Full pre-test maintenance pass across the converter, Java analyzer, resource/model extraction, runtime bridges, Android embedded core, validation, and release checks.
- Pack icons now prefer real PNG artwork found in the source mod assets, including icon-like PNGs outside the normal textures directory; source artwork is normalized without inventing a replacement when a usable PNG exists.
- Entity visual extraction now preserves supported Java entity geometry/model data and performs broader texture matching before falling back to placeholder geometry.
- Java sound playback calls now produce explicit `sound_play` IR operations, resolve against the generated sound registry, and have a Bedrock runtime bridge for safe playback contexts.
- Java scoreboard/objective calls now produce explicit `scoreboard_op` IR operations and package a namespaced-safe Bedrock scoreboard runtime bridge.
- Generated runtime bridge capability comments are de-duplicated to keep conversion output readable.
- Added analyzer regression coverage for sound and scoreboard detection.
- Fixed a V7 analyzer defect where detected sound/scoreboard operations referenced an undefined loader variable; these operations now correctly record `java` as their source loader.
- Core Python and the Android embedded Python copy are synchronized with zero source differences.

## Maintenance verification
- VERSION CHECK: PASS (7.8.4)
- TEST SUITE: 61 PASS / 0 FAIL
- ANDROID SOURCE LINT: 18/18 PASS
- Analyzer sound + scoreboard regression: PASS
- Release smoke conversion + output validation: PASS


## 7.8.4 V8 maintenance

- Removed all synthetic pack-icon generation. Pack icons now come only from real PNGs found in the source mod assets or loader-declared icon metadata.
- Removed synthetic 1x1 entity texture fallback.
- Removed synthetic entity cube geometry fallback.
- Removed generic random AI injection when no Java goal was found.
- Added real Java GoalSelector extraction for supported common goals.
- Added entity-class/superclass hierarchy linking so inherited mob AI can be retained when recoverable from bytecode.
- Added Java renderer texture-hint extraction for real source PNG binding.
- Wired source-derived hurt/death sound calls to Bedrock entity lifecycle events when entity mapping is known.
- Isolated converted scoreboard objectives by mod namespace.
- Synchronized Android embedded nexcore with the maintained core.
- Added source-truth and no-fake-asset regression tests.

## Final V8 maintenance verification

- VERSION CHECK: PASS (7.8.4)
- ANDROID SOURCE LINT: 18/18 PASS
- TEST SUITE: 65 PASS / 0 FAIL
- Core ↔ Android embedded nexcore: 0 source differences
- Runtime synthetic-asset scan: 0 forbidden generator/fallback references
- Source tree cache cleanup: PASS

## 7.8.4 V9 maintenance — function and entity truth fixes

- Fixed operation-order dependence in entity visual lowering: entity registrations may now appear before or after renderer/geometry operations without losing the source geometry.
- Preserved the real identifier inside GeckoLib/Bedrock `.geo.json` geometry instead of inventing `geometry.<namespace>_<entity>` when a real identifier is already present.
- Added a post-lowering function reference repair pass that resolves Java function references written as `namespace:path`, `namespace/path`, local nested paths, and stray `.mcfunction` suffixes after all generated functions exist.
- Unresolvable function calls are now archived as explicit `NEX_UNRESOLVED_FUNCTION` comments instead of leaving invalid active Bedrock command lines.
- Added generic entity-model recovery for mods that store block-model-style entity geometry in nonstandard `assets/<namespace>/models/*.json` locations; matching is restricted to strongly matching registered entity names and never creates placeholder art.
- Added regression tests for function-reference repair and real geometry-ID preservation.
- Re-synchronized the Android embedded core after the maintenance changes.

## Final V9 maintenance verification

- VERSION CHECK: PASS (7.8.4)
- ANDROID SOURCE LINT: 18/18 PASS
- TEST SUITE: 67 PASS / 0 FAIL
- Core ↔ Android embedded nexcore: 0 source differences
- No synthetic entity texture/cube/pack-icon fallback reintroduced.
- Preserved recovered entity gameplay/AI in the Behavior Pack even when no usable source geometry or texture exists; spawn-egg generation remains disabled, while `/summon` remains available for controlled testing.
- Added `entity_behavior` to the validated IR operation set so recovered Java GoalSelector operations are accepted by the release gate.

## 7.8.4 — V12 deep maintenance
- Failure-first analysis predicts missing links and platform blockers before packaging.
- Generated-output repair quarantines broken client visuals instead of generating fake textures/geometries.
- Client-only minimap profiles now get a safe coordinate/direction HUD approximation while the full Java renderer remains explicitly adaptable.
- Java resource-pack conversion activates PNG textures only; JPEG/JPG/TGA and non-Ogg audio are retained in audit storage instead of risking invalid Bedrock assets.
- OptiFine-style resource-pack features and Java overlays are explicitly detected/preserved for reconstruction review.
- Deep mechanic/risk findings retain class, method, bytecode offset and source line when available.
- Android bundled core synchronized with the updated core.


## V13 — FULL COMPATIBILITY / FAILURE-FIRST MAINTENANCE
- Java resource-pack block/item directories now lower to Bedrock `textures/blocks` and `textures/items` mappings.
- Common Java `.mcmeta` block animations are lowered into deterministic `textures/flipbook_textures.json`.
- Entity lowering uses only source-derived texture/geometry; no fabricated entity art.
- High-confidence Java entity goals now include avoid/target/tempt/breed/follow/leap families.
- Render-controller references are validated; missing custom controllers can safely fall back to Bedrock built-in `controller.render.default`.
- Compilation now performs up to three deterministic repair/validation passes before final packaging.
- Failure-first analysis reports unbound sounds, unbound scoreboards, renderer-only/performance-only mods, and minimap/HUD adaptation limits.
- Class analysis retains fields and SourceFile metadata for richer diagnostics.
