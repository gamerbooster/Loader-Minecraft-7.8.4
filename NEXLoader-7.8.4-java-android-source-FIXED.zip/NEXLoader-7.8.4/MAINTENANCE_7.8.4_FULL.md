# NEXLoader 7.8.4 — full maintenance / pre-test audit

## Scope

This pass is the maintenance gate that happens **before user testing**. The source tree was reviewed across the conversion pipeline, Java bytecode analysis, resource extraction, entity visuals, sound/scoreboard runtime bridges, dependency handling, Bedrock output validation, Android embedding, versioning, and regression tests.

## Audited and corrected

### Core conversion and safety
- Android/core Python copies were reconciled; the final source sync reports zero differences.
- Version metadata remains exact at 7.8.4.
- Existing archive-size, nested-JAR, malformed-class, malformed-metadata, dependency-range, path-traversal, and output-manifest guards were retained and re-tested.
- Generated Bedrock manifests continue to pass the final metadata guard.

### Source artwork and entity visuals
- Pack icon selection now searches for real source PNG artwork before using the NEX-generated fallback.
- Icon-like files such as `pack.png`, `pack_icon.png`, `icon.png`, `logo.png`, `thumbnail.png`, and `cover.png` are considered even when outside the regular `textures` directory.
- Usable source PNG icons are normalized to a valid 256×256 PNG without inventing new artwork.
- Entity texture matching was broadened across namespaces and common entity/mob paths, while filtering obvious generic/non-entity textures and 1×1 fallbacks.
- Supported Java entity model JSON and compatible `.geo.json` assets are converted into Bedrock entity geometry before generic placeholder geometry is considered.

### Sounds
- The analyzer detects Java sound playback calls such as `playSound`, `playLocalSound`, and `playSoundAtEntity` when their owners match sound/world/entity contexts.
- Detected calls become explicit `sound_play` IR operations and can resolve to IDs present in the extracted Bedrock sound registry.
- A Bedrock `sounds.js` runtime bridge is packaged when required.
- Safe known event contexts can automatically broadcast the resolved sound; unknown contexts remain explicit helpers rather than fabricated behavior.
- A V7 analyzer bug in this path was fixed: sound/scoreboard operations no longer reference an undefined loader variable.

### Scoreboards
- Scoreboard/objective API calls are analyzed rather than discarded.
- Detected calls become explicit `scoreboard_op` operations.
- The runtime packages a Bedrock `scoreboard.js` bridge for objective lookup/creation, score setting/addition/readback, and objective removal.
- Objective IDs should be kept namespaced by the converter so converted mods do not intentionally collide with unrelated worlds/add-ons.

### Runtime / generated bridge
- Sound and scoreboard modules are selected from the IR only when required.
- Repeated capability comments in the generated bridge are de-duplicated.
- Existing effects, state, scheduler, UI/input, particle, physics, recipe, loot, worldgen, localization, Modrinth, and inter-mod runtime paths remain covered by the regression suite.

### Android release path
- Embedded Android Python is synchronized from the canonical core.
- Android source lint and version checks pass.
- The GitHub workflow remains the authoritative Android build environment because this container does not provide the project's Android SDK/Gradle build stack.

## Important boundary

The maintenance pass validates the **converter and its generic behavior**. It does **not** prove faithful conversion of one specific Java mod that is not present in the workspace. The original The Mimic JAR is not available in this maintenance workspace, so exact Mimic model/texture references, AI/event logic, concrete sound call sites, scoreboard semantics, animations, particles, loot, and other mod-specific behavior still require analysis of the original JAR.

## Verification completed

- VERSION CHECK: PASS (7.8.4)
- Regression suite: 61 PASS / 0 FAIL
- Dedicated analyzer sound + scoreboard regression: PASS
- Maintenance asset/entity/sound/scoreboard compilation regression: PASS
- Core ↔ Android embedded source sync: 0 differences
- Android source lint: 18/18 PASS
- Release smoke conversion and final output validation: completed by final release preflight
