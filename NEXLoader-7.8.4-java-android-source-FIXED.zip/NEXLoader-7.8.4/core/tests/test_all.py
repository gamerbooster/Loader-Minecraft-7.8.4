from pathlib import Path
import json,zipfile,shutil,sys,subprocess,io
sys.path.insert(0,str(Path(__file__).parents[1]))
from adapters.loader import detect
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path('/tmp/nex33'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
png=bytes.fromhex('89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082')
# Fabric fixture with model, blockstate, item, recipe.
fab=ROOT/'fabric.jar'
with zipfile.ZipFile(fab,'w') as z:
 z.writestr('fabric.mod.json',json.dumps({'id':'demo','version':'1.0.0'}))
 z.writestr('assets/demo/blockstates/machine.json','{"variants":{"":{"model":"demo:block/machine"}}}')
 z.writestr('assets/demo/models/block/machine.json','{"textures":{"all":"demo:block/machine"},"elements":[{"from":[0,0,0],"to":[16,16,16],"uv":[0,0]}]}')
 z.writestr('assets/demo/textures/block/machine.png',png)
 z.writestr('assets/demo/items/chip.json','{}')
 z.writestr('assets/demo/textures/item/chip.png',png)
 z.writestr('data/demo/recipes/chip.json','{"type":"minecraft:crafting_shaped","pattern":["X"],"key":{"X":{"item":"minecraft:stick"}}}')
assert detect(fab)['loader']=='fabric'
info,p=build_ir(fab); assert p.mod_id=='demo'
out=compile_program(p,ROOT/'fabric_out')
# The basic custom block has all visual pieces now.
assert (out/'behavior_pack/blocks/machine.json').exists()
assert (out/'resource_pack/models/geometry.demo_block_machine.geo.json').exists()
assert (out/'resource_pack/textures/terrain_texture.json').exists()
assert (out/'resource_pack/textures/item_texture.json').exists()
assert (out/'demo.mcaddon').exists()
print('TEST 1 Fabric end-to-end: PASS')
# Forge fixture.
forge=ROOT/'forge.jar'
with zipfile.ZipFile(forge,'w') as z:
 z.writestr('META-INF/mods.toml','modLoader="javafml"\nloaderVersion="[1,)"\n[[mods]]\nmodId="forge_demo"\nversion="1.0.0"\ndisplayName="Demo"\n')
 z.writestr('assets/forge_demo/blockstates/machine.json','{"variants":{"":{"model":"forge_demo:block/machine"}}}')
 z.writestr('assets/forge_demo/models/block/machine.json','{"parent":"block/cube_all","textures":{"all":"forge_demo:block/machine"}}')
 z.writestr('assets/forge_demo/textures/block/machine.png',png)
assert detect(forge)['loader']=='forge'
fi,fp=build_ir(forge); assert fp.mod_id=='forge_demo'; fo=compile_program(fp,ROOT/'forge_out')
assert (fo/'behavior_pack/blocks/machine.json').exists()
print('TEST 2 Forge end-to-end: PASS')
# Missing texture guard.
bad=ROOT/'bad.jar'
with zipfile.ZipFile(bad,'w') as z:
 z.writestr('fabric.mod.json',json.dumps({'id':'bad','version':'1.0.0'}))
 z.writestr('assets/bad/blockstates/x.json','{"variants":{"":{"model":"bad:block/x"}}}')
 z.writestr('assets/bad/models/block/x.json','{"textures":{"all":"bad:block/x"},"elements":[{"from":[0,0,0],"to":[16,16,16]}]}')
bi,bp=build_ir(bad); bo=compile_program(bp,ROOT/'bad_out'); br=json.loads((bo/'conversion_report.json').read_text()); assert br['status']=='partial' and br['missing_resources']; assert not (bo/'behavior_pack/blocks/x.json').exists()
print('TEST 3 missing visual guard: PASS')
# Determinism.
fo2=compile_program(fp,ROOT/'forge_out2'); assert (fo/'behavior_pack/manifest.json').read_bytes()==(fo2/'behavior_pack/manifest.json').read_bytes(); assert (fo/'resource_pack/manifest.json').read_bytes()==(fo2/'resource_pack/manifest.json').read_bytes()
print('TEST 4 deterministic manifests: PASS')
# Archive nesting and JSON parse.
with zipfile.ZipFile(out/'demo.mcaddon') as a:
 assert set(a.namelist())=={'demo.behavior.mcpack','demo.resource.mcpack'}
 for member in a.namelist():
  with zipfile.ZipFile(io.BytesIO(a.read(member))) as z:
   assert 'manifest.json' in z.namelist()
   for n in z.namelist():
    if n.endswith('.json'): json.loads(z.read(n))
print('TEST 5 nested mcaddon + JSON validation: PASS')
# Bad identifier.
from nex.ir import Program,Operation
try: compile_program(Program('demo',[Operation('register_block','bad id',{},'convertible','fabric')]),ROOT/'bad_id')
except ValueError as e: assert 'invalid resource id' in str(e)
else: raise AssertionError('bad id accepted')
print('TEST 6 invalid ID rejection: PASS')
print('ALL 6 TESTS PASS')
