from pathlib import Path
import sys, tempfile, zipfile, json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nex.target import SCRIPT_API, SCRIPT_UI_API, TARGET_RUNTIME
from compiler.runtime_emit import RUNTIME_FILES

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)

ok('1 target runtime preserved', TARGET_RUNTIME=='1.26.52.3')
ok('2 server script baseline is 2.9.0', SCRIPT_API=='2.9.0')
ok('3 server-ui baseline is stable 2.2.0', SCRIPT_UI_API=='2.2.0')
ui=RUNTIME_FILES['ui.js']
ok('4 toggle uses 2.x options object', 'form.toggle(String(f.label), { defaultValue: Boolean(f.default) });' in ui)
ok('5 slider uses options object', 'valueStep: Number(f.step ?? 1)' in ui and 'defaultValue: Number(f.default ?? 0)' in ui)
ok('6 dropdown uses options object', 'defaultValueIndex: Number(f.default ?? 0)' in ui)
ok('7 textField uses options object', 'defaultValue: String(f.default ?? "")' in ui)
# prove the generator embeds the runtime module and manifest dependency at the selected UI API
from nex.ir import Program, Operation
from nex.compiler import compile_program
with tempfile.TemporaryDirectory() as td:
    p=Program('ui_test',version='1.0.0')
    p.add(Operation('ui_screen','ui_test:screen',{'title_hint':'Settings'},'adaptable','java','fixture'))
    out=Path(td)
    compile_program(p,out)
    manifest=json.loads((out/'behavior_pack'/'manifest.json').read_text())
    deps=manifest.get('dependencies',[])
    ui_dep=next((d for d in deps if d.get('module_name')=='@minecraft/server-ui'),None)
    ui_file=(out/'behavior_pack'/'scripts'/'nex_runtime'/'ui.js').read_text()
    ok('8 manifest pins server-ui 2.2.0', ui_dep and ui_dep['version']=='2.2.0')
    ok('9 generated ui.js uses corrected signatures', 'form.slider(String(f.label), Number(f.min ?? 0), Number(f.max ?? 100), {' in ui_file and 'valueStep: Number(f.step ?? 1)' in ui_file)
print('ALL 9 TESTS PASS')
