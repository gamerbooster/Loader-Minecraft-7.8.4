from pathlib import Path
import json, shutil, zipfile, sys, subprocess
sys.path.insert(0,str(Path(__file__).parents[1]))
from adapters.modpack import build_modpack_ir
from nex.compiler import compile_modpack

ROOT=Path('/tmp/nex71'); shutil.rmtree(ROOT,ignore_errors=True); (ROOT/'mods').mkdir(parents=True)
PNG=bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360f8cf00000003000101c3a8d3f60000000049454e44ae426082')

def jar(path, loader, mid, ver, deps=None, resources=False):
    deps=deps or []
    with zipfile.ZipFile(path,'w') as z:
        if loader=='fabric':
            d={'id':mid,'version':ver,'depends':{k:v for k,v in deps}}
            z.writestr('fabric.mod.json',json.dumps(d))
        elif loader=='neoforge':
            z.writestr('META-INF/neoforge.mods.toml',f'modLoader="javafml"\nloaderVersion="[4,)"\n[[mods]]\nmodId="{mid}"\nversion="{ver}"\n[[dependencies.{mid}]]\n'+''.join(f'modId="{k}"\nmandatory=true\nversionRange="{v}"\n' for k,v in deps))
        elif loader=='quilt':
            z.writestr('quilt.mod.json',json.dumps({'quilt_loader':{'id':mid,'version':ver,'depends':[{'id':k,'versions':v} for k,v in deps]}}))
        if resources:
            z.writestr('assets/alpha/textures/block/ore.png',PNG)
            z.writestr('assets/alpha/blockstates/ore.json',json.dumps({'variants':{'':{'model':'alpha:block/ore'}}}))
            z.writestr('assets/alpha/models/block/ore.json',json.dumps({'textures':{'all':'alpha:block/ore'},'elements':[{'from':[0,0,0],'to':[16,16,16]}]}))
            z.writestr('assets/alpha/models/item/gem.json',json.dumps({'textures':{'layer0':'alpha:item/gem'}}))
            z.writestr('assets/alpha/items/gem.json',json.dumps({'model':'alpha:item/gem'}))
            z.writestr('assets/alpha/textures/item/gem.png',PNG)
            z.writestr('assets/alpha/lang/en_us.json',json.dumps({'item.alpha.gem':'Gem'}))
            z.writestr('assets/alpha/sounds.json',json.dumps({'ore.break':{'category':'block','sounds':['alpha:ore.break']}}))
            z.writestr('assets/alpha/sounds/ore.break.ogg',b'OggS-test')
            z.writestr('data/alpha/recipes/gem.json',json.dumps({'type':'minecraft:crafting_shaped','pattern':['A','A'],'key':{'A':{'item':'minecraft:stone'}},'result':{'item':'alpha:gem','count':1}}))
            z.writestr('data/alpha/loot_tables/ore.json',json.dumps({'pools':[{'rolls':1,'entries':[{'type':'item','name':'alpha:gem','weight':1}]}]}))
            z.writestr('data/alpha/functions/start.mcfunction','say alpha-start\n/give @s alpha:gem 1\n')
            z.writestr('config/alpha.json',json.dumps({'enabled':True}))

jar(ROOT/'mods/alpha.jar','fabric','alpha','1.0.0',resources=True)
jar(ROOT/'mods/beta.jar','neoforge','beta','2.0.0',[('alpha','[1.0,2.0)')])
jar(ROOT/'mods/gamma.jar','quilt','gamma','3.0.0',[('beta','>=2.0')])

prog,res,tmp=build_modpack_ir(ROOT,'mega')
try:
    assert res.complete, res
    assert [n.mod_id for n in res.ordered]==['alpha','beta','gamma']
    ops={o.op for o in prog.operations}
    for required in {'register_block','register_item','register_recipe','register_loot_table','register_language','register_sound','register_function','register_config'}:
        assert required in ops, required
    out=ROOT/'out'; compile_modpack(prog,out,res,strict=True)
    report=json.loads((out/'conversion_report.json').read_text())
    graph=json.loads((out/'dependency_graph.json').read_text())
    assert report['modpack_resolution']['complete'] is True
    assert graph['ordered']==['alpha','beta','gamma']
    mcaddon=out/'mega.mcaddon'; assert mcaddon.exists()
    with zipfile.ZipFile(mcaddon) as z:
        names=set(z.namelist()); assert {'alpha.behavior.mcpack','alpha.resource.mcpack'} <= names or len(names)==2
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
        for nested in names:
            if nested.endswith('.mcpack'):
                with zipfile.ZipFile(z.open(nested)) as p:
                    manifest=json.loads(p.read('manifest.json')); assert manifest['format_version']==2
    assert (out/'behavior_pack/functions/alpha/start.mcfunction').exists()
    assert (out/'behavior_pack/loot_tables/ore.json').exists()
    print('1 mixed-loader ModPack end-to-end conversion: PASS')
    print('2 output mcaddon + dependency graph validation: PASS')
finally:
    shutil.rmtree(tmp,ignore_errors=True)
print('ALL 2 TESTS PASS')
