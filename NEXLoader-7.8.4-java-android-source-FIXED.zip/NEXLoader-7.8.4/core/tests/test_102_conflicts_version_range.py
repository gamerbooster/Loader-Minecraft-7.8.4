import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.dependencies import Dependency, ModNode, resolve

# A declared conflict only applies when the target version satisfies its range.
a=ModNode('a','1.0.0',dependencies=[Dependency('b','[2.0,3.0)',True,'conflicts','a')])
b=ModNode('b','1.5.0')
r=resolve([a,b])
assert not r.conflicts, r.conflicts
assert r.complete

# Same rule for breaks.
c=ModNode('c','1.0.0',dependencies=[Dependency('b','>=2.0',True,'breaks','c')])
r=resolve([c,b])
assert not r.conflicts, r.conflicts
assert r.complete
print('CONFLICT/BREAKS VERSION RANGES: PASS')
