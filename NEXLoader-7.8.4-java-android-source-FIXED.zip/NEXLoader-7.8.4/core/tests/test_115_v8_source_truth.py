from pathlib import Path
import hashlib, json, tempfile
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))

from nex.compiler import compile_program
from nex.ir import Program, Operation

PNG = bytes.fromhex(
    "89504E470D0A1A0A0000000D494844520000000200000002080600000072B60D24"
    "0000001649444154789C6360F8CFC0F01F00058102057C5B8E0B0000000049454E44AE426082"
)
# The bytes above are a tiny valid RGBA PNG used only as a source-truth fixture.
GEO = {
    "format_version": "1.12.0",
    "minecraft:geometry": [{
        "description": {"identifier": "geometry.test_mimicer", "texture_width": 2, "texture_height": 2},
        "bones": [{"name": "root", "pivot": [0, 0, 0], "cubes": [{"origin": [0,0,0], "size": [2,2,2]}] }]
    }]
}

with tempfile.TemporaryDirectory() as td:
    out = Path(td)
    program = Program('truthmod', [
        Operation('register_pack_asset', 'truthmod:__declared_icon__/icon.png',
                  {'path':'assets/truthmod/icon.png','bytes_hex':PNG.hex(),'kind':'png','declared':True},
                  'convertible','fabric','assets/truthmod/icon.png'),
        Operation('register_texture', 'truthmod:entity/mimicer',
                  {'path':'assets/truthmod/textures/entity/mimicer.png','bytes_hex':PNG.hex()},
                  'convertible','fabric','assets/truthmod/textures/entity/mimicer.png'),
        Operation('register_entity_visual', 'truthmod:mimicer',
                  {'texture_id':'truthmod:entity/mimicer','texture_hint':'textures/entity/mimicer.png',
                   'geometry':'geometry.test_mimicer','geometry_data':GEO,'entity_class':'com.example.Mimicer'},
                  'convertible','java','MimicerRenderer.class'),
        Operation('register_entity', 'truthmod:mimicer',
                  {'entity_class':'com.example.Mimicer','class_hierarchy':['com.example.Mimicer']},
                  'emulated','java','Mimicer.class'),
    ])
    result = compile_program(program, out)
    bp = result/'behavior_pack'; rp = result/'resource_pack'
    assert (bp/'pack_icon.png').read_bytes() == PNG
    assert (rp/'pack_icon.png').read_bytes() == PNG
    assert (rp/'textures/entity/mimicer.png').read_bytes() == PNG
    assert (rp/'models/entity/mimicer.geo.json').exists()
    assert (rp/'entity/mimicer.entity.json').exists()
    assert not any(p.name == 'mimicer.png' and p.parent.name == 'textures' for p in (rp/'textures').rglob('*') if p.is_file() and p != rp/'textures/entity/mimicer.png')
    entity = json.loads((bp/'entities/mimicer.json').read_text())
    assert entity['minecraft:entity']['description']['is_spawnable'] is True
    print('V8 source truth: PASS')

# Explicit no-fake behavior baseline: registration alone never invents random goals.
with tempfile.TemporaryDirectory() as td:
    out = Path(td)
    program = Program('nofakeai', [Operation('register_entity','nofakeai:mimicer',{},'emulated','java','Mimicer.class')])
    result = compile_program(program, out)
    entity = json.loads((result/'behavior_pack/entities/mimicer.json').read_text())
    comps = entity['minecraft:entity']['components']
    assert all(not k.startswith('minecraft:behavior.') for k in comps)
    assert not (result/'resource_pack/entity/mimicer.entity.json').exists()
    assert not (result/'resource_pack/models/entity/mimicer.geo.json').exists()
    print('V8 no synthetic entity AI/assets: PASS')
