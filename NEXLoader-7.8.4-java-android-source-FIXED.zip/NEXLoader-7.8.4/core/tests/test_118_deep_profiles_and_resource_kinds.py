from pathlib import Path
import json, tempfile, zipfile, sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.input_detect import detect_input_kind
from adapters.resourcepack import compile_resource_pack
from nex.ir import Program, Operation
from nex.compiler import compile_program
from analyzer.deep_audit import analyze_mechanics
from analyzer.classfile import parse, code_scan

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    sp=td/'shaderpack.zip'
    with zipfile.ZipFile(sp,'w') as z:
        z.writestr('pack.png', b'\x89PNG\r\n\x1a\n'+b'0'*100)
        z.writestr('shaders/gbuffers_terrain.vsh','void main(){}')
        z.writestr('shaders/gbuffers_terrain.fsh','void main(){}')
        z.writestr('shaders.properties','profile.NEX=1')
    assert detect_input_kind(sp)=='java_shaderpack'
    out=compile_resource_pack(sp,td/'shader_out','java_shaderpack')
    report=json.loads((out/'conversion_report.json').read_text())
    assert report['source_kind']=='java_shaderpack'
    assert report['shader_files']
    assert report['shader_activation']=='not_supported'

    fixture=Path(__file__).with_name('fixtures')/'mimic_HandleSound.class'
    parsed=parse(fixture.read_bytes())
    calls=[]
    for m in parsed['methods']:
        calls.extend(code_scan(parsed,m))
    # Line metadata may be absent in very small fixture classes, but the key must be present.
    if calls: assert all('line' in c for c in calls)
    audit=analyze_mechanics([(fixture.name,fixture.read_bytes())])
    assert isinstance(audit['mechanic_counts'],dict)

p=Program('jade')
p.add(Operation('feature_profile','jade:feature:hud_inspection',{'kind':'hud_inspection','interval_ticks':4,'max_distance':8},'emulated','java','fabric.mod.json'))
out=compile_program(p,Path(tempfile.mkdtemp())/'out')
script=(out/'behavior_pack/scripts/nex_bridge.js').read_text()
assert 'startInspection(world' in script
assert (out/'behavior_pack/scripts/nex_runtime/inspection.js').is_file()
plan=json.loads((out/'compatibility_plan.json').read_text())
assert plan['client_surface_operations']>=1
print('DEEP PROFILES + SHADERPACK + JADE ADAPTER: PASS')
