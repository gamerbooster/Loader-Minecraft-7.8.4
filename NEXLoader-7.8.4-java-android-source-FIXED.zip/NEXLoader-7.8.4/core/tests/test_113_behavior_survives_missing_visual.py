from pathlib import Path
import tempfile
import json
from nex.compiler import compile_program
from nex.ir import Program, Operation

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    p=Program("visual_missing")
    p.add(Operation("register_entity","visual_missing:ghost",{"entity_class":"GhostEntity"},"emulated","java","GhostEntity.class"))
    p.add(Operation("entity_behavior","GhostEntity:RandomStrollGoal:1",{"entity_class":"GhostEntity","bedrock_behavior":"minecraft:behavior.random_stroll","priority_hint":1},"emulated","java","GhostEntity.class"))
    out=compile_program(p,td/"out")
    behavior=json.loads((out/"behavior_pack/entities/ghost.json").read_text())
    desc=behavior["minecraft:entity"]["description"]
    assert desc["is_spawnable"] is False
    assert desc["is_summonable"] is True
    assert "minecraft:behavior.random_stroll" in behavior["minecraft:entity"]["components"]
    assert not (out/"resource_pack/entity/ghost.entity.json").exists()
print("BEHAVIOR SURVIVES MISSING VISUAL: PASS")
