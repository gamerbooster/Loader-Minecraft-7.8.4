package com.example;
import net.minecraftforge.eventbus.api.IEventBus;
public class ForgeDemo { public static void init(IEventBus bus){ bus.addListener(ForgeDemo::onEvent); } public static void onEvent(Object e){} }
