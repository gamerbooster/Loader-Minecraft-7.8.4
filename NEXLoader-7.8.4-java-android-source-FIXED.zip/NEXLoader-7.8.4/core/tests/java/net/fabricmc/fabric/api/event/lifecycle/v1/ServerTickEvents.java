package net.fabricmc.fabric.api.event.lifecycle.v1;
import java.util.function.Consumer;
import net.minecraft.world.World;
public final class ServerTickEvents {
  public static final class EndTick { public void register(Consumer<World> cb) {} }
  public static final EndTick END_SERVER_TICK = new EndTick();
}
