from pathlib import Path
import hashlib, tempfile, io
ROOT=Path(__file__).resolve().parents[2]
sys_path=str(ROOT/'core')
import sys; sys.path.insert(0,sys_path)
from adapters.external_fetch import fetch_modrinth_files

class FakeResponse:
    def __init__(self, raw, url): self.raw=raw; self.url=url
    def __enter__(self): return self
    def __exit__(self,*args): return False
    def geturl(self): return self.url
    def read(self, n=-1):
        if n < 0: out=self.raw; self.raw=b''; return out
        out,self.raw=self.raw[:n],self.raw[n:]; return out

def ok(name, condition):
    print(f"{name}: " + ("PASS" if condition else "FAIL"))
    if not condition: raise SystemExit(1)

raw=b'hello NEXLoader 7.5'
sha1=hashlib.sha1(raw).hexdigest()
pack={'format':'modrinth','external_files':[{'path':'mods/a.jar','downloads':['https://cdn.modrinth.com/a.jar'],'hashes':{'sha1':sha1},'size':len(raw)}]}

def opener(url, timeout=30): return FakeResponse(raw,url)
with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    report=fetch_modrinth_files(root,pack,opener=opener)
    ok('1 verified external artifact streamed and written', report['downloaded'][0]['status']=='verified' and (root/'mods/a.jar').read_bytes()==raw)

with tempfile.TemporaryDirectory() as td:
    root=Path(td); bad={**pack,'external_files':[dict(pack['external_files'][0],hashes={'sha1':'0'*40})]}
    report=fetch_modrinth_files(root,bad,opener=opener)
    ok('2 bad integrity is rejected', len(report['failed'])==1 and not (root/'mods/a.jar').exists())
print('ALL 2 EXTERNAL FETCH INTEGRITY TESTS PASS')
