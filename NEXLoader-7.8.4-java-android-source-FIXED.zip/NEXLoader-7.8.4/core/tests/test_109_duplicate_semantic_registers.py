from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from analyzer.behavior import analyze_classes

# Use empty class entries to exercise the post-analysis de-duplication contract.
ops=analyze_classes([], [], 'mimicmod')
assert ops == []
print('SEMANTIC REGISTRATION DEDUPE TEST: PASS')
