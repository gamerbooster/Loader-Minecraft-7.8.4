from pathlib import Path
import json, zipfile, shutil, subprocess, sys
ROOT=Path(__file__).resolve().parents[2]
TMP=Path('/tmp/nex_campaign_77'); shutil.rmtree(TMP,ignore_errors=True); TMP.mkdir()
mods=TMP/'mods'; mods.mkdir()
for mid,loader in [('alpha','fabric'),('beta','forge')]:
    jar=mods/f'{mid}.jar'
    with zipfile.ZipFile(jar,'w') as z:
        if loader=='fabric':
            z.writestr('fabric.mod.json',json.dumps({'id':mid,'version':'1.0.0'}))
        else:
            z.writestr('META-INF/mods.toml',f'modLoader="javafml"\n[[mods]]\nmodId="{mid}"\nversion="1.0.0"\n')
        z.writestr(f'assets/{mid}/textures/item/{mid}.png',bytes.fromhex('89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082'))
report=TMP/'campaign.json'
subprocess.run([sys.executable,str(ROOT/'tools/compat_campaign.py'),str(mods),str(report)],cwd=str(ROOT),check=True)
data=json.loads(report.read_text())
assert data['jar_count']==2 and data['analyzed']==2 and data['failed']==0
assert data['loader_counts']['fabric']==1 and data['loader_counts']['forge']==1
assert all('status_counts' in r for r in data['results'])
print('1 batch compatibility campaign: PASS')
print('2 mixed Fabric/Forge aggregation: PASS')
print('3 deterministic JSON report shape: PASS')
print('ALL 3 COMPATIBILITY CAMPAIGN TESTS PASS')
