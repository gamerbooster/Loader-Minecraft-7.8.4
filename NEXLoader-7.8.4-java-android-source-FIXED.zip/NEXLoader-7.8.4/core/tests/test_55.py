from pathlib import Path
import json, shutil, subprocess, sys, zipfile, re
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.loader import detect
from adapters.resources import build_ir
from nex.compiler import compile_program
from analyzer.behavior import analyze_classes

ROOT=Path('/tmp/nex55'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()
SRC=ROOT/'src'; OUT=ROOT/'out'; CLS=ROOT/'classes'
(SRC/'com/test').mkdir(parents=True)
(SRC/'net/minecraft/client').mkdir(parents=True)
(SRC/'net/minecraft/client/gui/screen').mkdir(parents=True)
(SRC/'test').mkdir(parents=True)
# Minimal API stubs that look like Java client-side APIs.
(SRC/'net/minecraft/client/KeyMapping.java').write_text('''package net.minecraft.client; public class KeyMapping { public static void registerKeyBinding() {} }''')
(SRC/'net/minecraft/client/Minecraft.java').write_text('''package net.minecraft.client; public class Minecraft { public void setScreen(Object screen) {} }''')
(SRC/'net/minecraft/client/gui/screen/Screen.java').write_text('''package net.minecraft.client.gui.screen; public class Screen { public void render() {} }''')
(SRC/'test/Main.java').write_text('''package test; public class Main {\n  public void client(net.minecraft.client.KeyMapping k, net.minecraft.client.Minecraft m, net.minecraft.client.gui.screen.Screen s) {\n    net.minecraft.client.KeyMapping.registerKeyBinding();\n    m.setScreen(s);\n    s.render();\n  }\n}''')
subprocess.run(['javac','-d',str(CLS),*[str(x) for x in SRC.rglob('*.java')]],check=True)
cls=(CLS/'test/Main.class').read_bytes()
ops=analyze_classes([('test/Main.class',cls)])
ids=[(o.op,o.id,o.status,o.args) for o in ops]
assert any(x[0]=='capability' and x[1]=='client.input' and x[2]=='emulated' for x in ids)
assert any(x[0]=='keybind' and x[2]=='adaptable' for x in ids)
assert any(x[0]=='capability' and x[1]=='ui.screen' and x[2]=='adaptable' for x in ids)
assert any(x[0]=='ui_screen' for x in ids)
print('1 client input + UI capability analysis: PASS')

jar=ROOT/'client.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'clientdemo','version':'1.0.0'}))
    z.writestr('test/Main.class', cls)
info, program=build_ir(jar)
out=compile_program(program,OUT)
manifest=json.loads((out/'behavior_pack/manifest.json').read_text())
deps=manifest.get('dependencies',[])
assert any(d.get('module_name')=='@minecraft/server-ui' and d.get('version')=='2.2.0' for d in deps)
assert (out/'behavior_pack/scripts/nex_runtime/input.js').exists()
assert (out/'behavior_pack/scripts/nex_runtime/ui.js').exists()
assert (out/'conversion_report.json').exists()
print('2 runtime input + UI modules packaged: PASS')
report=json.loads((out/'conversion_report.json').read_text())
assert report['script_ui_api']=='2.2.0'
assert report['input_bindings'] and report['input_bindings'][0]['status']=='adaptable'
print('3 report includes input bindings + UI API: PASS')

js=out/'behavior_pack/scripts/nex_bridge.js'
subprocess.run(['node','--check',str(js)],check=True)
for f in (out/'behavior_pack/scripts/nex_runtime').glob('*.js'):
    subprocess.run(['node','--check',str(f)],check=True)
print('4 generated JavaScript syntax: PASS')

# Direct semantic hint fixture: a string mentioning jump makes the keybind emulatable.
SRC2=ROOT/'src2'; CLS2=ROOT/'classes2'; (SRC2/'test').mkdir(parents=True)
(SRC2/'test/Main.java').write_text('''package test; public class Main { public void client(net.minecraft.client.KeyMapping k) { String s="jump"; net.minecraft.client.KeyMapping.registerKeyBinding(); } }''')
subprocess.run(['javac','-d',str(CLS2),str(SRC2/'test/Main.java'),str(SRC/'net/minecraft/client/KeyMapping.java')],check=True)
ops2=analyze_classes([('test/Main.class',(CLS2/'test/Main.class').read_bytes())])
# Constant pool string is retained in the scan; if it reaches the call neighborhood, it should become Jump.
kb=[o for o in ops2 if o.op=='keybind']
assert kb and kb[0].args.get('button_hint')=='Jump'
print('5 semantic Jump hint lowers to Bedrock InputButton: PASS')

# Backward compatibility: prior fixture with no client ops still converts.
plain=ROOT/'plain.jar'
with zipfile.ZipFile(plain,'w') as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'plain','version':'1.0.0'}))
    z.writestr('data/plain/recipes/x.json','{"type":"minecraft:crafting_shaped","pattern":["X"],"key":{"X":{"item":"minecraft:stick"}}}')
_,pp=build_ir(plain); po=compile_program(pp,ROOT/'plain_out')
assert (po/'plain.mcaddon').exists()
print('6 backward-compatible plain mod conversion: PASS')
print('ALL 6 TESTS PASS')
