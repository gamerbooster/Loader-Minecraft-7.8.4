from pathlib import Path
import tempfile, json, zipfile
from nex.ir import Program, Operation
from nex.compiler import compile_program

with tempfile.TemporaryDirectory() as td:
    out=Path(td)
    prog=Program('nofake',[
        Operation('register_entity','nofake:mimicer',{},'emulated','java','Mimicer.class'),
    ])
    # No source texture/geometry operations: compiler must NOT create a pink 1x1 PNG or cube.
    compile_program(prog,out)
    assert (out/'behavior_pack/entities/mimicer.json').exists()
    assert not (out/'resource_pack/entity/mimicer.entity.json').exists()
    assert not (out/'resource_pack/models/entity/mimicer.geo.json').exists()
    assert not (out/'resource_pack/textures/entity/mimicer.png').exists()
    report=json.loads((out/'conversion_report.json').read_text())
    assert any(x.get('type')=='entity_texture_unresolved' for x in report['missing_resources'])
    assert any(x.get('type')=='entity_geometry_unresolved' for x in report['missing_resources'])
print('NO FAKE ENTITY ASSETS: PASS')
