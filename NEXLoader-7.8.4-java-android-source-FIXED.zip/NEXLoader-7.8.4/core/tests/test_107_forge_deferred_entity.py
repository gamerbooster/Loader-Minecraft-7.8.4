from pathlib import Path
import json, subprocess, sys, tempfile, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from nex.compiler import compile_program

with tempfile.TemporaryDirectory() as td:
    td=Path(td); src=td/'src'; classes=td/'classes'; classes.mkdir()
    for pkg in ('demo','net/minecraftforge/registries','net/minecraft/world/entity'):
        (src/pkg).mkdir(parents=True, exist_ok=True)
    (src/'net/minecraftforge/registries/DeferredRegister.java').write_text("package net.minecraftforge.registries; import java.util.function.Supplier; public class DeferredRegister<T> { public Object register(String name, Supplier<T> supplier){ return supplier.get(); } }")
    (src/'net/minecraft/world/entity/EntityType.java').write_text("package net.minecraft.world.entity; public class EntityType { public static class Builder { public static Builder of(){ return new Builder(); } public Builder sized(){ return this; } public Object build(){ return null; } } }")
    (src/'demo/ForgeEntities.java').write_text("package demo; import net.minecraftforge.registries.DeferredRegister; import net.minecraft.world.entity.EntityType; public class ForgeEntities { static DeferredRegister<Object> REG=new DeferredRegister<>(); public static void init(){ REG.register(\"mimicer\", () -> EntityType.Builder.of().sized().build()); REG.register(\"not_an_entity\", ForgeEntities::other); } static Object other(){ return new Object(); } }")
    subprocess.run(['javac','-d',str(classes)] + [str(x) for x in src.rglob('*.java')], check=True)
    jar=td/'forge-entity.jar'
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('META-INF/mods.toml','modLoader=\"javafml\"\nloaderVersion=\"[1,)\"\n[[mods]]\nmodId=\"mimicmod\"\nversion=\"1.0.0\"\ndisplayName=\"Mimic Mod\"\n')
        for f in classes.rglob('*.class'): z.write(f, f.relative_to(classes))
    info,p=build_ir(jar)
    ents=[o for o in p.operations if o.op=='register_entity']
    assert len(ents)==1, [(o.op,o.id,o.args) for o in p.operations if 'register' in o.op or o.op=='register_entity']
    assert ents[0].id=='mimicmod:mimicer', ents[0].id
    out=compile_program(p, td/'out')
    assert (out/'behavior_pack/entities/mimicer.json').exists()
    client=json.loads((out/'resource_pack/entity/mimicer.entity.json').read_text())
    assert 'spawn_egg' in client['minecraft:client_entity']['description']
    assert (out/'behavior_pack/pack_icon.png').exists() and (out/'resource_pack/pack_icon.png').exists()
print('FORGE DEFERRED ENTITY + PACK ICON TEST: PASS')
