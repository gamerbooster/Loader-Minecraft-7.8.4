from pathlib import Path
import tempfile, json, zipfile
from nex.compiler import compile_program
from nex.ir import Program, Operation

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    geo={
      'format_version':'1.12.0',
      'minecraft:geometry':[{'description':{'identifier':'geo.mimicer','texture_width':64,'texture_height':64},'bones':[]}]
    }
    png=bytes.fromhex('89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082')
    p=Program('themimic_er')
    p.add(Operation('register_entity','themimic_er:mimicer',{},'emulated','java','MimicerEntity.class'))
    p.add(Operation('register_entity_visual','themimic_er:mimicer',{
        'raw_geometry':geo,'geometry_data':geo,'texture_id':'themimic_er:entity/mimicer','face_texture_records':{}
    },'convertible','java','mimicer.geo.json'))
    p.add(Operation('register_texture','themimic_er:entity/mimicer',{'bytes_hex':png.hex(),'path':'assets/themimic_er/textures/entity/mimicer.png'},'convertible','java','mimicer.png'))
    out=compile_program(p,td/'out')
    client=json.loads((out/'resource_pack/entity/mimicer.entity.json').read_text())
    assert client['minecraft:client_entity']['description']['geometry']['default']=='geo.mimicer'
    assert (out/'resource_pack/models/entity/mimicer.geo.json').exists()
    assert json.loads((out/'resource_pack/models/entity/mimicer.geo.json').read_text())['minecraft:geometry'][0]['description']['identifier']=='geo.mimicer'
print('ENTITY GEO ID PRESERVED: PASS')
