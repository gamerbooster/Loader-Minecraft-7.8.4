from pathlib import Path
import json, tempfile, zipfile, sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'android/app/src/main/python'))
import nex_android_bridge

def ok(name, condition):
    print(f"{name}: " + ("PASS" if condition else "FAIL"))
    if not condition: raise SystemExit(1)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); pack=td/'demo.mrpack'
    with zipfile.ZipFile(pack,'w') as z:
        z.writestr('modrinth.index.json', json.dumps({'formatVersion':1,'name':'Demo','versionId':'1','files':[]}))
    raw=nex_android_bridge.analyze(str(pack), True)
    payload=json.loads(raw)
    ok('1 Android bridge analyzes Modrinth pack without NameError', payload['mode']=='modpack' and payload['status']=='partial' and payload.get('empty_modpack') is True)
    raw2=nex_android_bridge.analyze(str(pack), True, False)
    payload2=json.loads(raw2)
    ok('2 analyze() accepts explicit fetch_externals=False', payload2['mode']=='modpack')
    raw3=nex_android_bridge.analyze(str(pack), True, True)
    payload3=json.loads(raw3)
    ok('3 analyze() accepts fetch_externals=True path', payload3['mode']=='modpack')
print('ALL 3 ANDROID BRIDGE REGRESSION TESTS PASS')
