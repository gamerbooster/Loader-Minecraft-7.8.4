from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from adapters.modpack import _verify_external_artifacts
from adapters.external_fetch import _verify_file

ROOT=Path('/tmp/nex103'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
jar=ROOT/'badgeo.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'badgeo','version':'1.0.0'}))
    z.writestr('assets/badgeo/blockstates/test.json',json.dumps({'variants':{'':{'model':'badgeo:block/test'}}}))
    z.writestr('assets/badgeo/models/block/test.json',json.dumps({'textures':{'all':'badgeo:block/test'},'elements':[{'from':[0,0,0],'to':[16,16,16],'rotation':{'axis':'y','angle':'not-a-number','origin':[8,8,8]}}]}))
    z.writestr('assets/badgeo/textures/block/test.png',b'fake')
_, program=build_ir(jar)
codes={d.get('code') for d in program.diagnostics}
assert 'MODEL_GEO_INVALID' in codes

root=ROOT/'files'; root.mkdir()
f=root/'a.bin'; f.write_bytes(b'1234')
# Bad declared sizes must produce structured mismatches, not ValueError/TypeError.
report=_verify_external_artifacts(root,{'external_files':[{'path':'a.bin','size':'abc'}]})
assert report['counts']['mismatched']==1 and report['mismatched'][0]['reason']=='invalid_expected_size'
ok, detail=_verify_file(f,{'size':'abc'})
assert not ok and detail['reason']=='invalid_declared_size'
print('MALFORMED GEOMETRY + SIZE METADATA: PASS')
