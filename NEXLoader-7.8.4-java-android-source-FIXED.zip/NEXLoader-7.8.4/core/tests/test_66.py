from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path('/tmp/nex66'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
jar=ROOT/'loot.jar'
with zipfile.ZipFile(jar,'w') as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'lootdemo','version':'1.0.0'}))
    z.writestr('data/lootdemo/loot_tables/entities/test.json',json.dumps({
        'pools':[{
            'rolls':1,
            'entries':[{'type':'item','name':'minecraft:diamond','weight':2,'functions':[{'function':'minecraft:set_count','count':{'min':1,'max':2}}]},
                       {'type':'empty','weight':1}],
            'conditions':[{'condition':'minecraft:killed_by_player'}]
        }]
    }))
    z.writestr('data/lootdemo/loot_tables/entities/ref.json',json.dumps({'pools':[{'rolls':1,'entries':[{'type':'loot_table','name':'lootdemo:entities/test'}]}]}))
    z.writestr('data/lootdemo/loot_tables/entities/complex.json',json.dumps({'pools':[{'rolls':1,'entries':[{'type':'alternatives','children':[]}]}]}))
_,p=build_ir(jar)
ops={o.id:o for o in p.operations if o.op=='register_loot_table'}
assert ops['lootdemo:entities/test'].status=='convertible'
assert ops['lootdemo:entities/ref'].args['bedrock_json']['pools'][0]['entries'][0]['name']=='loot_tables/entities/test.json'
assert ops['lootdemo:entities/complex'].status=='adaptable'
print('1 loot analysis + safe subset: PASS')
out=compile_program(p,ROOT/'out')
lt=out/'behavior_pack/loot_tables/entities/test.json'
assert lt.exists()
data=json.loads(lt.read_text())
assert data['pools'][0]['entries'][0]['name']=='minecraft:diamond'
assert data['pools'][0]['conditions'][0]['condition']=='killed_by_player'
manifest=json.loads((out/'behavior_pack/manifest.json').read_text())
assert not any(d.get('module_name')=='@minecraft/server' for d in manifest.get('dependencies',[]))
print('2 loot output + no unnecessary script dependency: PASS')
assert (out/'lootdemo.mcaddon').exists()
print('3 loot mcaddon packaging: PASS')
print('ALL 3 TESTS PASS')
