from pathlib import Path
import tempfile, json
from nex.ir import Program, Operation
from nex.compiler import compile_program

with tempfile.TemporaryDirectory() as td:
    out=Path(td)
    prog=Program('noicon',[Operation('register_entity','noicon:e',{},'emulated','java','E.class')])
    compile_program(prog,out)
    assert not (out/'behavior_pack/pack_icon.png').exists()
    assert not (out/'resource_pack/pack_icon.png').exists()
    report=json.loads((out/'conversion_report.json').read_text())
    assert report['pack_icon_source']=='missing'
print('NO GENERATED PACK ICON: PASS')
