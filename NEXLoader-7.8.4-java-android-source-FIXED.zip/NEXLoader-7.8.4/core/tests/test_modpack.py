from pathlib import Path
import json, zipfile, shutil, sys
sys.path.insert(0, str(Path(__file__).parents[1]))

from adapters.dependencies import ModNode, Dependency, resolve, satisfies
from adapters.modpack import inspect_modpack, build_modpack_ir
from nex.compiler import compile_modpack

ROOT=Path('/tmp/nex_modpack_tests'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()


def fabric_jar(path, mod_id, version, deps=None, extra=None):
    deps=deps or {}; extra=extra or {}
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('fabric.mod.json', json.dumps({'id':mod_id,'version':version,'depends':deps,'name':mod_id}))
        for name,data in extra.items(): z.writestr(name,data)

# 1-5: resolver primitives.
assert satisfies('1.5.0','>=1.0.0')
assert satisfies('1.5.0','[1.0,2.0)') and not satisfies('2.0.0','[1.0,2.0)')
assert satisfies('1.5.0','1.x')
A=ModNode('a','1.0.0',dependencies=[Dependency('b','>=1.0.0',True,'depends','a')])
B=ModNode('b','1.2.0')
r=resolve([A,B]); assert [n.mod_id for n in r.ordered]==['b','a'] and r.complete
D=ModNode('d','1.0.0',dependencies=[Dependency('missing','*',True,'depends','d')])
r=resolve([D]); assert len(r.missing)==1 and not r.complete
O=ModNode('o','1.0.0',dependencies=[Dependency('optional','*',False,'suggests','o')])
r=resolve([O]); assert r.complete and any(w['code']=='OPTIONAL_DEPENDENCY_MISSING' for w in r.warnings)
print('1 resolver ranges/transitive: PASS')

# 6: version mismatch.
H=ModNode('h','1.0.0',dependencies=[Dependency('i','>=2.0.0',True,'depends','h')]); I=ModNode('i','1.0.0')
r=resolve([H,I]); assert len(r.conflicts)==1 and r.conflicts[0]['type']=='version_mismatch'
print('2 version conflict: PASS')

# 7: cycle.
F=ModNode('f','1.0.0',dependencies=[Dependency('g','*',True,'depends','f')]); G=ModNode('g','1.0.0',dependencies=[Dependency('f','*',True,'depends','g')])
r=resolve([F,G]); assert r.cycles and not r.complete
print('3 dependency cycle: PASS')

# Create a realistic pack with Fabric + Forge + missing + duplicate versions.
pack=ROOT/'pack'; (pack/'mods').mkdir(parents=True)
fabric_jar(pack/'mods/b.jar','b','1.2.0')
fabric_jar(pack/'mods/c.jar','c','1.0.0')
fabric_jar(pack/'mods/a.jar','a','1.0.0',{'b':'>=1.0.0','c':'[1.0,2.0)'})
fabric_jar(pack/'mods/d.jar','d','1.0.0',{'missingmod':'>=1.0.0'})

with zipfile.ZipFile(pack/'mods/o.jar','w') as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'o','version':'1.0.0','depends':{},'suggests':{'optionalmod':'*'}}))
fabric_jar(pack/'mods/f.jar','f','1.0.0',{'g':'*'})
fabric_jar(pack/'mods/g.jar','g','1.0.0',{'f':'*'})
fabric_jar(pack/'mods/i.jar','i','1.0.0')
fabric_jar(pack/'mods/h.jar','h','1.0.0',{'i':'>=2.0.0'})
fabric_jar(pack/'mods/j1.jar','j','1.0.0')
fabric_jar(pack/'mods/j2.jar','j','2.0.0')
# Forge metadata with a mandatory dependency to b.
with zipfile.ZipFile(pack/'mods/forgeaddon.jar','w') as z:
    z.writestr('META-INF/mods.toml','''modLoader="javafml"\nloaderVersion="[1,)"\n[[mods]]\nmodId="forgeaddon"\nversion="1.0.0"\ndisplayName="Forge Addon"\n[[dependencies.forgeaddon]]\nmodId="b"\nmandatory=true\nversionRange="[1.0,2.0)"\nordering="NONE"\nside="BOTH"\n''')

info=inspect_modpack(pack)
r=info['resolution']
assert len(r.ordered)>=11
assert any(d.mod_id=='missingmod' for d in r.missing)
assert any(c['type']=='version_mismatch' for c in r.conflicts)
assert any(c['type']=='duplicate_mod_version' and c['mod_id']=='j' for c in r.conflicts)
assert r.cycles
assert any(w['code']=='OPTIONAL_DEPENDENCY_MISSING' for w in r.warnings)
assert 'fabric' in {n.loader for n in r.ordered} and 'forge' in {n.loader for n in r.ordered}
print('4 mixed Fabric/Forge pack resolution: PASS')

program,res,tmp=build_modpack_ir(pack,'testpack')
assert program.mod_id=='testpack'
assert any(d['code']=='DEPENDENCY_RESOLUTION' for d in program.diagnostics)
out=ROOT/'out'
compile_modpack(program,out,res)
report=json.loads((out/'conversion_report.json').read_text())
assert report['modpack_resolution']['missing']
assert report['modpack_resolution']['conflicts']
assert report['modpack_resolution']['cycles']
assert (out/'testpack.mcaddon').exists()
print('5 merged ModPack compile/report: PASS')
shutil.rmtree(tmp,ignore_errors=True)

# Zip input.
zip_pack=ROOT/'pack.zip'
with zipfile.ZipFile(zip_pack,'w',zipfile.ZIP_DEFLATED) as z:
    for f in pack.rglob('*'):
        if f.is_file(): z.write(f,f.relative_to(pack))
info=inspect_modpack(zip_pack)
assert info['resolution'].missing
print('6 ZIP ModPack input: PASS')

# MRPack-shaped input with manifest and embedded jar.
mr=ROOT/'demo.mrpack'
with zipfile.ZipFile(mr,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('modrinth.index.json',json.dumps({'formatVersion':1,'name':'DemoPack','versionId':'1.0'}))
    z.write(pack/'mods/b.jar','overrides/mods/b.jar')
# The extraction is deliberately permissive; a real .mrpack can contain overrides rather than a top-level mods dir.
info=inspect_modpack(mr)
assert info['pack']['format']=='modrinth'
assert len(info['resolution'].ordered)>=1
print('7 .mrpack metadata/overrides: PASS')

# Strict mode must reject unresolved packs.
try:
    compile_modpack(program, ROOT/'strict', res, strict=True)
except ValueError as e:
    assert 'unresolved ModPack dependencies' in str(e)
else:
    raise AssertionError('strict mode accepted unresolved dependencies')
print('8 strict mode: PASS')

print('ALL MODPACK TESTS PASS')
