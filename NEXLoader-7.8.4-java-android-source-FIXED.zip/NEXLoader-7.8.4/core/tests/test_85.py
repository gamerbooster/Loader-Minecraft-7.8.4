from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
main=(ROOT/'android/app/src/main/java/com/nex/loader/MainActivity.java').read_text(encoding='utf-8')
manifest=(ROOT/'android/app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)
ok('1 Android picker accepts official Modrinth MIME', 'application/x-modrinth-modpack+zip' in main)
ok('2 VIEW intent accepts official Modrinth MIME', 'application/x-modrinth-modpack+zip' in manifest)
print('ALL 2 MRPACK MIME TESTS PASS')
