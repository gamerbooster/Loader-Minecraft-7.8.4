from pathlib import Path
import json, tempfile, zipfile, struct, zlib
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.input_detect import detect_input_kind
from adapters.resourcepack import compile_resource_pack
from nex.ir import Program, Operation
from nex.compiler import compile_program
from analyzer.compatibility_plan import build_plan

def png16():
    raw=b"\x00"+(b"\x10\x20\x30\xff"*16)
    data=b"".join(b"\x00"+(b"\x10\x20\x30\xff"*16) for _ in range(16))
    def c(t,d): return struct.pack(">I",len(d))+t+d+struct.pack(">I",zlib.crc32(t+d)&0xffffffff)
    return b"\x89PNG\r\n\x1a\n"+c(b"IHDR",struct.pack(">IIBBBBB",16,16,8,6,0,0,0))+c(b"IDAT",zlib.compress(data,9))+c(b"IEND",b"")

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    # ZIPs exported from a folder often contain one enclosing directory.
    zp=td/'wrapped.zip'
    with zipfile.ZipFile(zp,'w') as z:
        z.writestr('MyJavaPack/pack.mcmeta',json.dumps({'pack':{'pack_format':15,'description':'wrapped'}}))
        z.writestr('MyJavaPack/pack.png',png16())
        z.writestr('MyJavaPack/assets/minecraft/textures/block/stone.png',png16())
    assert detect_input_kind(zp)=='java_resource_pack'
    out=compile_resource_pack(zp,td/'rpout','java_resource_pack')
    assert (out/'resource_pack/textures/blocks/stone.png').exists()
    assert json.loads((out/'conversion_report.json').read_text())['source_root_wrapper']=='MyJavaPack/'
    assert json.loads((out/'conversion_report.json').read_text())['activation'].startswith('imported_resource_pack')
    print('WRAPPED JAVA RESOURCE PACK -> ACTIVE TEXTURE PATH: PASS')

    # Resource pack with no pack.mcmeta is still recognized from standard assets/textures.
    bare=td/'bare.zip'
    with zipfile.ZipFile(bare,'w') as z:
        z.writestr('assets/minecraft/textures/block/dirt.png',png16())
    assert detect_input_kind(bare)=='java_resource_pack'
    out2=compile_resource_pack(bare,td/'bareout','java_resource_pack')
    assert (out2/'resource_pack/textures/blocks/dirt.png').exists()
    assert (out2/'resource_pack/pack_icon.png').exists()
    report2=json.loads((out2/'conversion_report.json').read_text())
    assert report2['pack_icon_source']=='source_asset_png'
    print('BARE JAVA TEXTURE ZIP DETECTION + REAL SOURCE ICON: PASS')

    # Source-derived entity attributes lower only when the value is unique and valid.
    prog=Program('attrmod',[
        Operation('register_entity','attrmod:beast',{'entity_class':'x/Beast','class_hierarchy':['x/Beast','x/Mob']},'emulated','forge','Beast.class'),
        Operation('entity_attribute','x/Beast:MAX_HEALTH',{'entity_class':'x/Beast','bedrock_component':'minecraft:health','value':24.0},'emulated','java','Beast.class'),
        Operation('entity_attribute','x/Beast:ATTACK_DAMAGE',{'entity_class':'x/Beast','bedrock_component':'minecraft:attack','value':6.0},'emulated','java','Beast.class'),
        Operation('entity_attribute','x/Beast:MOVEMENT_SPEED',{'entity_class':'x/Beast','bedrock_component':'minecraft:movement','value':0.3},'emulated','java','Beast.class'),
    ])
    out3=compile_program(prog,td/'attrout')
    ent=json.loads((out3/'behavior_pack/entities/beast.json').read_text())
    comps=ent['minecraft:entity']['components']
    assert comps['minecraft:health']['value']==24.0
    assert comps['minecraft:attack']['damage']==6.0
    assert comps['minecraft:movement']['value']==0.3
    print('ENTITY ATTRIBUTE LOWERING: PASS')

    plan=build_plan(Program('audit',[Operation('capability','render.custom',{},'adaptable','java','Renderer.class')], diagnostics=[{'code':'MECHANICS_DEEP_AUDIT','mechanic_calls':[{'mechanic':'rendering','source':'Renderer.class','class':'x/Renderer','method':'render','line':42,'offset':10,'owner':'x/Y','name':'draw'}]}]))
    assert any(x['surface']=='rendering' and x['samples'][0]['line']==42 for x in plan['mechanics_source_matrix'])
    print('MECHANICS SOURCE-LINE MATRIX: PASS')
