from pathlib import Path
import tempfile
from nex.compiler import compile_program
from nex.ir import Program, Operation

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    p=Program('funfix')
    p.add(Operation('register_function','funfix:start',{
        'namespace':'funfix','path':'start',
        'text':'function funfix:config/debug_message\nexecute as @s run function funfix/config/send_message.mcfunction\nfunction config/done\n'
    },'convertible','fabric','start.mcfunction'))
    for rel in ['config/debug_message','config/send_message','config/done']:
        p.add(Operation('register_function',f'funfix:{rel}',{'namespace':'funfix','path':rel,'text':'say ok\n'},'convertible','fabric',rel+'.mcfunction'))
    out=compile_program(p,td/'out')
    start=(out/'behavior_pack/functions/funfix/start.mcfunction').read_text()
    assert 'function funfix/config/debug_message' in start
    assert '.mcfunction' not in start
    assert 'function funfix/config/send_message' in start
    assert 'function funfix/config/done' in start
    assert 'NEX_UNRESOLVED_FUNCTION' not in start
print('FUNCTION REFERENCE REPAIR: PASS')
