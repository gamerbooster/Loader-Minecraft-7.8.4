from pathlib import Path
import json, shutil, subprocess, sys, zipfile, io
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.loader import detect
from adapters.resources import build_ir
from adapters.recipes import translate_recipe
from nex.compiler import compile_program

ROOT=Path('/tmp/nex60'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()
png=bytes.fromhex('89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082')

# 1: shaped recipe translation
status, out, diag = translate_recipe({
    'type':'minecraft:crafting_shaped','pattern':['XX',' X'],
    'key':{'X':{'item':'minecraft:stick'}},
    'result':{'item':'demo:thing','count':2}
}, 'demo:thing')
assert status=='convertible'
assert out['minecraft:recipe_shaped']['description']['identifier']=='demo:thing'
assert out['minecraft:recipe_shaped']['key']['X']['item']=='minecraft:stick'
print('1 shaped recipe translation: PASS')

# 2: shapeless + item tag
status, out, _ = translate_recipe({
    'type':'minecraft:crafting_shapeless','ingredients':[{'tag':'minecraft:planks'}, {'item':'minecraft:stick'}],
    'result':{'item':'demo:thing'}
}, 'demo:thing2')
assert status=='convertible' and out['minecraft:recipe_shapeless']['ingredients'][0]['tag']=='minecraft:planks'
print('2 shapeless recipe translation: PASS')

# 3: oversized recipe must not be emitted
status, out, diag = translate_recipe({
    'type':'minecraft:crafting_shaped','pattern':['XXXX'], 'key':{'X':{'item':'minecraft:stick'}}, 'result':{'item':'demo:x'}
}, 'demo:x')
assert status=='adaptable' and out is None and any(d['code']=='RECIPE_GRID_GT_3X3' for d in diag)
print('3 oversized recipe guarded: PASS')

# 4: cooking translation
status, out, _ = translate_recipe({'type':'minecraft:smelting','ingredient':{'item':'demo:ore'},'result':{'item':'demo:ingot'}}, 'demo:smelt')
assert status=='convertible' and out['minecraft:recipe_furnace']['input']=='demo:ore' and out['minecraft:recipe_furnace']['output']=='demo:ingot'
print('4 cooking translation: PASS')

# Build an actual Java-style resource jar with tags, recipes and per-face textures.
jar=ROOT/'demo.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'demo','version':'1.0.0'}))
    z.writestr('assets/demo/blockstates/machine.json','{"variants":{"":{"model":"demo:block/machine"}}}')
    z.writestr('assets/demo/models/block/machine.json',json.dumps({'textures':{
        'up':'demo:block/top','down':'demo:block/bottom','north':'demo:block/front','south':'demo:block/back','east':'demo:block/side','west':'demo:block/side'},
        'elements':[{'from':[0,0,0],'to':[16,16,16]}]}))
    for name in ['top','bottom','front','back','side']: z.writestr(f'assets/demo/textures/block/{name}.png',png)
    z.writestr('assets/demo/items/thing.json','{}')
    z.writestr('assets/demo/textures/item/thing.png',png)
    z.writestr('data/demo/tags/blocks/machines.json',json.dumps({'values':['demo:machine']}))
    z.writestr('data/demo/tags/items/things.json',json.dumps({'values':['demo:thing']}))
    z.writestr('data/demo/recipes/thing.json',json.dumps({'type':'minecraft:crafting_shaped','pattern':['X'],'key':{'X':{'item':'minecraft:stick'}},'result':{'item':'demo:thing'}}))
    z.writestr('data/demo/recipes/custom.json',json.dumps({'type':'demo:custom_serializer','foo':'bar'}))

info, p = build_ir(jar)
assert info['loader']=='fabric'
assert any(o.op=='register_tag' and o.id=='demo:blocks/machines' for o in p.operations)
assert any(o.op=='register_recipe' and o.status=='convertible' and o.args.get('bedrock_json') for o in p.operations)
assert any(o.op=='register_recipe' and o.status=='adaptable' for o in p.operations)
print('5 IR tag + recipe analysis: PASS')

outdir=compile_program(p,ROOT/'out')
block=json.loads((outdir/'behavior_pack/blocks/machine.json').read_text())
assert block['minecraft:block']['components']['minecraft:tags']['tags']==['demo:blocks/machines']
# The current tag name maps to the same identifier domain, and the compiler preserves the direct membership.
item=json.loads((outdir/'behavior_pack/items/thing.json').read_text())
assert item['minecraft:item']['components']['minecraft:tags']['tags']==['demo:items/things']
recipe=json.loads((outdir/'behavior_pack/recipes/thing.json').read_text())
assert 'minecraft:recipe_shaped' in recipe and recipe['minecraft:recipe_shaped']['description']['identifier']=='demo:thing'
assert not (outdir/'behavior_pack/recipes/custom.json').exists()
print('6 compiled recipe/tag files: PASS')

# 7 face textures survive in material instances.
mi=block['minecraft:block']['components']['minecraft:material_instances']
assert set(mi)=={'up','down','north','south','east','west'}
assert mi['up']['texture']=='top' and mi['north']['texture']=='front'
print('7 per-face texture preservation: PASS')

# 8 generated JSON and JS archive validation.
for root in [outdir/'behavior_pack', outdir/'resource_pack']:
    for f in root.rglob('*.json'):
        json.loads(f.read_text())
print('8 generated JSON validation: PASS')
print('ALL 8 TESTS PASS')
