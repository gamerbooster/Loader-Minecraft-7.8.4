from pathlib import Path

from analyzer.classfile import parse, code_scan


def test_mimic_string_concat_invokedynamic_does_not_crash():
    fixture = Path(__file__).parent / "fixtures" / "mimic_HandleSound.class"
    parsed = parse(fixture.read_bytes())
    handle = next(m for m in parsed["methods"] if m["name"] == "handle")
    calls = code_scan(parsed, handle)
    unresolved = [c for c in calls if c.get("kind") == "invokedynamic" and c.get("unresolved_bootstrap")]
    assert unresolved
    assert all(c.get("name") == "makeConcatWithConstants" for c in unresolved)
    assert all("callback_target" not in c for c in unresolved)
