from pathlib import Path
import sys, json, zipfile, io, tempfile, shutil
sys.path.insert(0, str(Path(__file__).parents[1]))
ANDROID_ROOT=Path(__file__).parents[2] / 'android/app/src/main/python'
sys.path.insert(0, str(ANDROID_ROOT))
from nex_android_bridge import audit_final_mcaddon
from nex.compiler import compile_program
from nex.ir import Program

ROOT=Path('/tmp/nex106'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()
out=compile_program(Program('guard'), ROOT/'out')
addon=out/'guard.mcaddon'
raw=addon.read_bytes()
# Mutate only the nested manifest to reproduce the exact Bedrock error class.
mut=ROOT/'bad.mcaddon'
with zipfile.ZipFile(io.BytesIO(raw)) as outer_in, zipfile.ZipFile(mut,'w',zipfile.ZIP_DEFLATED) as outer_out:
    for member in outer_in.namelist():
        payload=outer_in.read(member)
        if member.endswith('.mcpack'):
            with zipfile.ZipFile(io.BytesIO(payload)) as inner_in, io.BytesIO() as buf:
                with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as inner_out:
                    for n in inner_in.namelist():
                        part=inner_in.read(n)
                        if n=='manifest.json':
                            d=json.loads(part.decode())
                            d['metadata']={'generated_with':'7.8.4'}
                            part=json.dumps(d).encode()
                        inner_out.writestr(n,part)
                payload=buf.getvalue()
        outer_out.writestr(member,payload)
errs=audit_final_mcaddon(mut)
assert any('contains forbidden generated metadata' in e for e in errs), errs
print('ANDROID FINAL MANIFEST GUARD: PASS')
