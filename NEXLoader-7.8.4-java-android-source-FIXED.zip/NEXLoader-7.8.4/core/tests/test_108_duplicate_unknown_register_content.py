from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from nex.ir import Program, Operation
from nex.validate import validate_program

p=Program("mimicmod")
p.add(Operation("register_content", "unknown", {}, "adaptable", "forge", "A.class"))
p.add(Operation("register_content", "unknown", {}, "adaptable", "forge", "B.class"))
p.add(Operation("register_content", "mimicmod:known", {}, "adaptable", "forge", "C.class"))
p.add(Operation("register_content", "mimicmod:known", {}, "adaptable", "forge", "D.class"))
assert validate_program(p) == [], validate_program(p)
print("DUPLICATE/UNKNOWN REGISTER_CONTENT TEST: PASS")
