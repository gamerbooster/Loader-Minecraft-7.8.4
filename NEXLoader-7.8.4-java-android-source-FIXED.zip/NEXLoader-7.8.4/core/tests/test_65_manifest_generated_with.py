import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from nex.output_validate import validate_compiled_output
from nex.ir import Program
from nex.compiler import compile_program

def test_generated_manifest_omits_optional_generated_with_metadata():
    source=(Path(__file__).parents[1]/'nex/compiler.py').read_text(encoding='utf-8')
    assert "'metadata': {'generated_with'" not in source

def test_validator_accepts_valid_generated_with_object(tmp_path):
    out=tmp_path/'out'
    compile_program(Program('meta'),out)
    for rel in ('behavior_pack/manifest.json','resource_pack/manifest.json'):
        p=out/rel; data=json.loads(p.read_text(encoding='utf-8'))
        data['metadata']={'generated_with':{'nexloader':['7.8.4']}}
        p.write_text(json.dumps(data,indent=2),encoding='utf-8')
    assert validate_compiled_output(out)==[]

def test_validator_rejects_bad_generated_with_shapes(tmp_path):
    out=tmp_path/'out'
    compile_program(Program('badmeta'),out)
    p=out/'behavior_pack/manifest.json'; data=json.loads(p.read_text(encoding='utf-8'))
    data['metadata']={'generated_with':{'nexloader':'7.8.4'}}
    p.write_text(json.dumps(data,indent=2),encoding='utf-8')
    errors=validate_compiled_output(out)
    assert any('must be a non-empty array' in e for e in errors)

print('GENERATED_WITH VALIDATION: PASS')
