from __future__ import annotations

import gzip
import io
import json
import tempfile
import zipfile
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import importlib
import adapters.input_detect as _input_detect
_input_detect = importlib.reload(_input_detect)
detect_input_kind = _input_detect.detect_input_kind
from world.nbt import read_level_dat
from world.probe import probe_java_world
from world.converter import analyze_world
from world.mcworld import package_mcworld, validate_bedrock_world_root


def s(v: str) -> bytes:
    raw = v.encode("utf-8")
    return struct.pack(">H", len(raw)) + raw


def tag(t: int, name: str, payload: bytes) -> bytes:
    return bytes([t]) + s(name) + payload


def level_dat_bytes() -> bytes:
    # Java level.dat normally has a root COMPOUND containing a Data COMPOUND.
    data = b"".join([
        tag(3, "DataVersion", struct.pack(">i", 3105)),
        tag(8, "LevelName", s("NEX Demo World")),
        tag(4, "RandomSeed", struct.pack(">q", 123456789)),
        tag(3, "SpawnX", struct.pack(">i", 12)),
        tag(3, "SpawnY", struct.pack(">i", 71)),
        tag(3, "SpawnZ", struct.pack(">i", -8)),
        bytes([0]),
    ])
    root_payload = tag(10, "Data", data + b"\x00")
    raw = bytes([10]) + s("") + root_payload + bytes([0])
    return gzip.compress(raw)


def make_region(path: Path, used: int = 2) -> None:
    header = bytearray(8192)
    for idx in range(used):
        off = 2 + idx
        header[idx * 4: idx * 4 + 3] = off.to_bytes(3, "big")
        header[idx * 4 + 3] = 1
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(bytes(header) + b"\x00" * (used * 4096))


with tempfile.TemporaryDirectory(prefix="nex_world_test_") as td:
    root = Path(td) / "MyWorld"
    (root / "region").mkdir(parents=True)
    (root / "DIM-1" / "region").mkdir(parents=True)
    (root / "DIM1" / "region").mkdir(parents=True)
    (root / "playerdata").mkdir()
    (root / "level.dat").write_bytes(level_dat_bytes())
    (root / "playerdata" / "00000000-0000-0000-0000-000000000000.dat").write_bytes(b"x")
    make_region(root / "region" / "r.0.0.mca", 3)
    make_region(root / "DIM-1" / "region" / "r.0.0.mca", 1)
    make_region(root / "DIM1" / "region" / "r.1.0.mca", 2)

    assert detect_input_kind(root) == "java_world"
    nbt = read_level_dat(root / "level.dat")
    assert nbt["Data"]["DataVersion"] == 3105
    assert nbt["Data"]["LevelName"] == "NEX Demo World"

    info = probe_java_world(root)
    assert info.kind == "java_world"
    assert info.data_version == 3105
    assert info.name == "NEX Demo World"
    assert info.seed == 123456789
    assert info.spawn == {"x": 12, "y": 71, "z": -8}
    assert info.playerdata_files == 1
    assert {d.id for d in info.dimensions} == {"minecraft:overworld", "minecraft:the_nether", "minecraft:the_end"}
    assert sum(d.chunks for d in info.dimensions) == 6

    archive = Path(td) / "world.zip"
    with zipfile.ZipFile(archive, "w") as z:
        for f in root.rglob("*"):
            if f.is_file():
                z.write(f, f"MyWorld/{f.relative_to(root).as_posix()}")
    assert detect_input_kind(archive) == "java_world"
    zipped_info = probe_java_world(archive)
    assert zipped_info.name == "NEX Demo World"
    assert sum(d.chunks for d in zipped_info.dimensions) == 6

    analysis = analyze_world(root)
    assert analysis["mode"] == "world"
    assert analysis["input_kind"] == "java_world"
    assert analysis["total_chunks"] == 6
    assert analysis["dimension_count"] == 3
    assert analysis["engine"]["available"] is False
    assert any("Chunker CLI" in w for w in analysis["warnings"])

    # Android bridge uses the world analyzer instead of the legacy ModPack route.
    android_python = ROOT.parent / "android" / "app" / "src" / "main" / "python"
    if str(android_python) not in sys.path:
        sys.path.insert(0, str(android_python))
    import nex_android_bridge
    bridge_payload = json.loads(nex_android_bridge.analyze(str(root)))
    assert bridge_payload["mode"] == "world"
    assert bridge_payload["input_kind"] == "java_world"
    assert bridge_payload["total_chunks"] == 6

    # Minimal Bedrock-world packager contract (synthetic LevelDB marker directory).
    bedrock = Path(td) / "bedrock"
    (bedrock / "db").mkdir(parents=True)
    (bedrock / "level.dat").write_bytes(b"bedrock-level-dat")
    (bedrock / "db" / "CURRENT").write_text("MANIFEST-000001\n", encoding="utf-8")
    assert validate_bedrock_world_root(bedrock) == []
    mcworld = Path(td) / "out.mcworld"
    package_mcworld(bedrock, mcworld)
    with zipfile.ZipFile(mcworld) as z:
        assert z.testzip() is None
        assert "level.dat" in z.namelist()
        assert "db/CURRENT" in z.namelist()

print("JAVA WORLD NEXT-LEVEL: PASS")
