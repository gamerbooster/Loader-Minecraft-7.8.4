import sys
from pathlib import Path

ROOT=Path(__file__).parents[1]
sys.path.insert(0, str(ROOT))

import analyzer.behavior as behavior

# Keep this test self-contained: emulate the bytecode scanner's shape and verify
# the analyzer actually lowers detected Java sound/scoreboard calls into IR.
original_parse=behavior.parse
original_scan=behavior.code_scan

try:
    behavior.parse=lambda data: {
        'this':'Test',
        'methods':[{'name':'tick','descriptor':'()V'}],
    }
    calls=[
        {
            'owner':'net/minecraft/world/World','name':'playSound','descriptor':'(Ljava/lang/String;)V',
            'near_strings':['testmod:whisper'],'constant_hints':[],
        },
        {
            'owner':'net/minecraft/scoreboard/Scoreboard','name':'setScore','descriptor':'(Ljava/lang/String;Ljava/lang/String;I)V',
            'near_strings':['events','player'],'constant_hints':[],
        },
    ]
    behavior.code_scan=lambda parsed, method: calls
    diagnostics=[]
    ops=behavior.analyze_classes([('Test.class',b'fixture')], diagnostics, namespace='testmod')
    assert any(o.op=='sound_play' and o.args.get('sound_hint')=='testmod:whisper' for o in ops)
    assert any(o.op=='scoreboard_op' and o.args.get('method')=='setScore' for o in ops)
    assert diagnostics == []
finally:
    behavior.parse=original_parse
    behavior.code_scan=original_scan

print('ANALYZER SOUND + SCOREBOARD: PASS')
