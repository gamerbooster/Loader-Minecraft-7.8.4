from pathlib import Path
import tempfile, zipfile, subprocess, json, sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir

with tempfile.TemporaryDirectory() as td:
    td=Path(td); src=td/'src'; classes=td/'classes'
    for pkg in ('demo','net/minecraft/world/entity/ai/goal','net/minecraft/world/entity/ai'):
        (src/pkg).mkdir(parents=True, exist_ok=True)
    (src/'net/minecraft/world/entity/ai/goal/RandomStrollGoal.java').write_text('package net.minecraft.world.entity.ai.goal; public class RandomStrollGoal { public RandomStrollGoal(Object a,double s){} }')
    (src/'net/minecraft/world/entity/ai/goal/GoalSelector.java').write_text('package net.minecraft.world.entity.ai.goal; public class GoalSelector { public void addGoal(int p,Object g){} }')
    (src/'net/minecraft/world/entity/ai/Mob.java').write_text('package net.minecraft.world.entity.ai; import net.minecraft.world.entity.ai.goal.*; public class Mob { GoalSelector g=new GoalSelector(); public void registerGoals(){ g.addGoal(4,new RandomStrollGoal(this,1.0)); } }')
    subprocess.run(['javac','-d',str(classes)] + [str(x) for x in src.rglob('*.java')],check=True)
    jar=td/'goal.jar'
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('fabric.mod.json',json.dumps({'id':'goalmod','version':'1.0.0'}))
        for f in classes.rglob('*.class'): z.write(f,f.relative_to(classes))
    _,p=build_ir(jar)
    ops=[o for o in p.operations if o.op=='entity_behavior']
    assert any(o.args.get('java_goal')=='RandomStrollGoal' and o.args.get('priority_hint')==4 for o in ops), [(o.id,o.args) for o in ops]
print('ENTITY GOAL EXTRACTION: PASS')
