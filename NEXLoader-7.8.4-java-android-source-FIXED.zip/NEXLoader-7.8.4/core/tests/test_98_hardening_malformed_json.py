from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path('/tmp/nex_hardening_784'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()
jar=ROOT/'malformed.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'malformed.test','version':'1.0.0'}))
    # Root-level null/list JSONs must never trigger AttributeError/TypeError in the scanner.
    z.writestr('assets/malformed.test/models/item/bad_parent.json', 'null')
    z.writestr('assets/malformed.test/models/item/list_model.json', '[]')
    z.writestr('assets/malformed.test/blockstates/bad.json', '[]')
    z.writestr('assets/malformed.test/sounds.json', '[]')
    z.writestr('assets/malformed.test/items/bad.json', '[]')
    z.writestr('data/malformed.test/worldgen/biome/bad.json', 'null')
    z.writestr('data/malformed.test/recipe/bad.json', 'null')
    z.writestr('data/malformed.test/loot_table/bad.json', 'null')
    z.writestr('data/malformed.test/advancement/bad.json', '[]')

info, program = build_ir(jar)
assert info['mods'][0]['id'] == 'malformed.test'
# A malformed source must be reported, not crash the entire conversion.
codes={d.get('code') for d in program.diagnostics}
expected={'MODEL_RESOLVE_FAILED','BLOCKSTATE_ROOT_INVALID','SOUND_ROOT_INVALID','WORLDGEN_PARSE_FAILED','RECIPE_PARSE_FAILED','LOOT_PARSE_FAILED'}
assert expected & codes
out=compile_program(program, ROOT/'out')
assert (out/'malformed.test.mcaddon').exists()
report=json.loads((out/'conversion_report.json').read_text())
assert report['status'] == 'partial'
print('MALFORMED JSON HARDENING: PASS')
