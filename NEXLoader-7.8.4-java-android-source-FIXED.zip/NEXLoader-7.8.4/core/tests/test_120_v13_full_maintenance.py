from pathlib import Path
import json, tempfile, zipfile
from adapters.resourcepack import compile_resource_pack
from nex.compiler import compile_program
from nex.ir import Program, Operation
from compiler.entity_emit import _PHYSICS_PNG

ROOT=Path(tempfile.mkdtemp(prefix="nex_v13_"))

# Java RP with vanilla block/item paths + animated block + real pack icon.
pack=ROOT/'java_rp'; (pack/'assets/minecraft/textures/block').mkdir(parents=True); (pack/'assets/minecraft/textures/item').mkdir(parents=True)
(pack/'pack.mcmeta').write_text('{"pack":{"pack_format":15,"description":"V13 Test"}}')
png=_PHYSICS_PNG
(pack/'pack.png').write_bytes(png)
(pack/'assets/minecraft/textures/block/test.png').write_bytes(png)
(pack/'assets/minecraft/textures/block/test.png.mcmeta').write_text('{"animation":{"frametime":3,"frames":[0,1,2]}}')
(pack/'assets/minecraft/textures/item/test.png').write_bytes(png)
out=compile_resource_pack(pack,ROOT/'rpout','java_resource_pack')
assert (out/'resource_pack/pack_icon.png').read_bytes()==png
assert (out/'resource_pack/textures/blocks/test.png').is_file()
assert (out/'resource_pack/textures/items/test.png').is_file()
flip=json.loads((out/'resource_pack/textures/flipbook_textures.json').read_text())
assert flip and flip[0]['atlas_tile']=='test' and flip[0]['ticks_per_frame']==3
print('1 Java block/item path lowering + flipbook + real icon: PASS')

# Client entity with an absent custom renderer should be repaired to built-in default.
p=Program('v13entity',[
    Operation('register_entity','v13entity:mimicer',{'entity_class':'com.example.Mimicer','class_hierarchy':['com.example.Mimicer']},'emulated','java','Mimicer.class'),
    Operation('register_entity_visual','v13entity:mimicer',{'geometry_data':{'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geo.v13_mimicer'},'bones':[{'name':'root','pivot':[0,0,0],'cubes':[{'origin':[-4,0,-4],'size':[8,8,8]}]}]}]},'geometry':'geo.v13_mimicer','texture_id':'v13entity:entity/mimicer','texture_path':'assets/v13entity/textures/entity/mimicer.png'},'convertible','java','model.json'),
    Operation('register_texture','v13entity:entity/mimicer',{'bytes_hex':png.hex(),'path':'assets/v13entity/textures/entity/mimicer.png'},'convertible','java','texture.png'),
    Operation('entity_behavior','v13entity:MeleeAttackGoal',{'entity_class':'com.example.Mimicer','bedrock_behavior':'minecraft:behavior.melee_attack','priority_hint':1},'emulated','java','Mimicer.class'),
])
res=compile_program(p,ROOT/'entityout')
client=json.loads((res/'resource_pack/entity/mimicer.entity.json').read_text())
assert client['minecraft:client_entity']['description']['render_controllers']==['controller.render.default']
b=json.loads((res/'behavior_pack/entities/mimicer.json').read_text())['minecraft:entity']['components']
assert 'minecraft:behavior.melee_attack' in b
print('2 entity visual + real texture + high-confidence behavior: PASS')

# No fabricated visual when source texture is absent.
p2=Program('v13novis',[Operation('register_entity','v13novis:ghost',{'entity_class':'Ghost'},'emulated','java','Ghost.class'), Operation('register_entity_visual','v13novis:ghost',{'geometry_data':{'minecraft:geometry':[]},'geometry':'geo.ghost','texture_id':'v13novis:entity/ghost','texture_path':'assets/v13novis/textures/entity/ghost.png'},'convertible','java','model.json')])
r2=compile_program(p2,ROOT/'novis')
assert not (r2/'resource_pack/entity/ghost.entity.json').exists()
assert not (r2/'resource_pack/textures/entity/ghost.png').exists()
print('3 missing visual never fabricates texture/entity renderer: PASS')
