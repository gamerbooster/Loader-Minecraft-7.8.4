from pathlib import Path
import json, tempfile, zipfile, struct, zlib
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.input_detect import detect_input_kind
from adapters.resourcepack import compile_resource_pack
from adapters.resources import build_ir
from nex.ir import Operation

def png16():
    raw=b'\x00'+(b'\x40\x80\xc0\xff'*16)
    data=b''.join(raw for _ in range(16))
    def c(t,d): return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+c(b'IHDR',struct.pack('>IIBBBBB',16,16,8,6,0,0,0))+c(b'IDAT',zlib.compress(data,9))+c(b'IEND',b'')

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    rp=td/'pack.zip'
    with zipfile.ZipFile(rp,'w') as z:
        z.writestr('pack.mcmeta',json.dumps({'pack':{'pack_format':15,'description':'test'}}))
        z.writestr('pack.png',png16())
        z.writestr('assets/minecraft/textures/block/test.png',png16())
        z.writestr('assets/minecraft/shaders/test.vsh','void main(){}')
    assert detect_input_kind(rp)=='java_resource_pack'
    out=compile_resource_pack(rp,td/'out','java_resource_pack')
    assert (out/'resource_pack/pack_icon.png').read_bytes()==png16()
    assert (out/'resource_pack/textures/blocks/test.png').is_file()
    assert (out/'resource_pack/nex_untranslated/minecraft/shaders/test.vsh').is_file()
    report=json.loads((out/'conversion_report.json').read_text())
    assert report['source_kind']=='java_resource_pack'
    assert report['unsupported']
    jar=td/'mod.jar'
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('fabric.mod.json',json.dumps({'id':'auditmod','version':'1.0.0'}))
        z.writestr('assets/auditmod/textures/icon.png',png16())
    info,p=build_ir(jar)
    codes={d.get('code') for d in p.diagnostics}
    assert 'DEEP_ARCHIVE_AUDIT' in codes
    assert 'BYTECODE_SURFACE_AUDIT' not in codes or any(d.get('code')=='BYTECODE_SURFACE_AUDIT' for d in p.diagnostics)==True
print('INPUT RESOURCE PACK + DEEP AUDIT: PASS')
