from pathlib import Path
import json
import tempfile
from nex.ir import Program, Operation
from nex.compiler import compile_program
from nex.output_repair import repair_generated_output

# Client-only minimap profile must produce a real safe approximation and analysis report.
p=Program('xaero')
p.add(Operation('feature_profile','xaero:feature:minimap',{'kind':'minimap','features':['waypoint_metadata','player_position']},'adaptable','java','Xaero.class'))
with tempfile.TemporaryDirectory() as td:
    out=compile_program(p,Path(td)/'out')
    plan=json.loads((out/'compatibility_plan.json').read_text())
    assert plan['failure_first']['analysis']=='failure-first'
    assert plan['failure_first']['client_surface_operations']>=1
    assert (out/'behavior_pack/scripts/nex_runtime/map_hud.js').is_file()
    script=(out/'behavior_pack/scripts/nex_bridge.js').read_text()
    assert 'startMapHud(world' in script
    assert not (out/'resource_pack/entity').exists() or not list((out/'resource_pack/entity').glob('*.entity.json'))

# Visual quarantine preserves behavior while removing broken client-entity references.
with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    rp=root/'resource_pack'/'entity'; rp.mkdir(parents=True)
    (root/'resource_pack'/'models').mkdir(parents=True)
    (root/'behavior_pack'/'entities').mkdir(parents=True)
    (rp/'bad.entity.json').write_text(json.dumps({'minecraft:client_entity':{'description':{'identifier':'x:bad','geometry':{'default':'geometry.missing'},'textures':{'default':'textures/entity/missing'}}}}),encoding='utf-8')
    repairs=repair_generated_output(root)
    assert any(r['type']=='quarantine_visual' for r in repairs)
    assert not (rp/'bad.entity.json').exists()
    assert (root/'resource_pack'/'nex_untranslated'/'quarantined_visuals'/'bad.entity.json').is_file()
print('FAILURE-FIRST + SAFE VISUAL REPAIR: PASS')
