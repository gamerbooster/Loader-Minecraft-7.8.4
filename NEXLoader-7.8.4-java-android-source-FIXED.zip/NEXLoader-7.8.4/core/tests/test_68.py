from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0,str(Path(__file__).parents[1]))
from adapters.loader import detect
from adapters.modpack import build_modpack_ir

ROOT=Path('/tmp/nex68'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
# 1 NeoForge metadata is detected and its dependency loader family is preserved.
neo=ROOT/'neo.jar'
with zipfile.ZipFile(neo,'w') as z:
    z.writestr('META-INF/neoforge.mods.toml','modLoader="javafml"\nloaderVersion="[4,)"\n[[mods]]\nmodId="neo"\nversion="1.0.0"\ndisplayName="Neo"\n[[dependencies.neo]]\nmodId="dep"\nmandatory=true\nversionRange="[1.0,2.0)"\n')
info=detect(neo)
assert info['loader']=='neoforge'
assert info['mods'][0]['dependencies'][0]['loader']=='neoforge'
print('1 NeoForge detection/deps: PASS')

# 2 Quilt metadata is detected and version alternatives are preserved as OR ranges.
quilt=ROOT/'quilt.jar'
with zipfile.ZipFile(quilt,'w') as z:
    z.writestr('quilt.mod.json',json.dumps({'quilt_loader':{'id':'quilted','version':'2.0.0','name':'Quilted','depends':[{'id':'qdep','versions':['>=1.0','<2.0']}]}}))
qi=detect(quilt)
assert qi['loader']=='quilt'
assert qi['mods'][0]['dependencies'][0]['loader']=='quilt'
assert '||' in qi['mods'][0]['dependencies'][0]['version_spec']
print('2 Quilt detection/deps: PASS')

# 3 A ModPack can merge Quilt + NeoForge metadata into the common resolver graph.
pack=ROOT/'pack'; (pack/'mods').mkdir(parents=True)
shutil.copy2(neo,pack/'mods/neo.jar'); shutil.copy2(quilt,pack/'mods/quilt.jar')
prog,res,tmp=build_modpack_ir(pack,'families')
try:
    ids={n.mod_id for n in res.ordered}
    assert ids=={'neo','quilted'}
    assert sorted({n.loader for n in res.ordered})==['neoforge','quilt']
finally: shutil.rmtree(tmp,ignore_errors=True)
print('3 mixed loader-family ModPack graph: PASS')
print('ALL 3 TESTS PASS')
