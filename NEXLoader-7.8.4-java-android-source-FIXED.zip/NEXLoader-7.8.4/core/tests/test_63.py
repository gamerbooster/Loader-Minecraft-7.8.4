from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.dependencies import Dependency, ModNode, resolve
from adapters.modpack import build_modpack_ir, inspect_modpack
from adapters.resources import build_ir
from nex.compiler import compile_program
from nex.ir import Program, Operation

ROOT=Path('/tmp/nex63'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()

# 1 declared Fabric conflict is a real conflict when the conflicting mod is present.
a=ROOT/'a.jar'; b=ROOT/'b.jar'
with zipfile.ZipFile(a,'w') as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'a','version':'1.0.0','conflicts':{'b':'*'}}))
with zipfile.ZipFile(b,'w') as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'b','version':'1.0.0'}))
res=resolve([ModNode('a','1.0.0','fabric','mods/a.jar',[Dependency('b','*',False,'conflicts','a','fabric')]),ModNode('b','1.0.0','fabric','mods/b.jar',[])])
assert not res.complete and any(c['type']=='declared_conflict' for c in res.conflicts)
print('1 declared conflict enforcement: PASS')

# 2 break only blocks the declared version range.
res2=resolve([ModNode('a','1.0.0','fabric','a.jar',[Dependency('b','[2.0,3.0)','False'=='True','breaks','a','fabric')]), ModNode('b','1.5.0','fabric','b.jar',[])])
assert res2.complete
res3=resolve([ModNode('a','1.0.0','fabric','a.jar',[Dependency('b','[1.0,2.0)','False'=='True','breaks','a','fabric')]), ModNode('b','1.5.0','fabric','b.jar',[])])
assert not res3.complete and any(c['type']=='declared_conflict' for c in res3.conflicts)
print('2 breaks version gating: PASS')

# 3 Modrinth external artifact metadata is visible when files are not bundled.
pack=ROOT/'external.mrpack'
with zipfile.ZipFile(pack,'w') as z:
    z.writestr('modrinth.index.json', json.dumps({'formatVersion':1,'game':'minecraft','name':'Ext','versionId':'1','files':[{'path':'mods/missing.jar','hashes':{'sha1':'abc'},'downloads':['https://example.invalid/missing.jar'],'fileSize':12}]}))
    z.writestr('mods/local.jar', b'not-a-real-jar')
info=inspect_modpack(pack)
assert info['pack']['external_files_count']==1
print('3 Modrinth external artifacts detected: PASS')

# 4 Java item model with inherited layer0 texture is lowered to Bedrock icon.
png=bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001ff15c48900000000d49444154789c63600000ffff0005fe02fea7d0a8d00000000049454e44ae426082')
jar=ROOT/'item_model.jar'
with zipfile.ZipFile(jar,'w') as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'itemdemo','version':'1.0.0'}))
    z.writestr('assets/itemdemo/items/token.json',json.dumps({'model':{'type':'minecraft:model','model':'itemdemo:item/token'}}))
    z.writestr('assets/itemdemo/models/item/token.json',json.dumps({'parent':'item/generated','textures':{'layer0':'itemdemo:item/token'}}))
    z.writestr('assets/itemdemo/textures/item/token.png',png)
_, prog=build_ir(jar); item=[o for o in prog.operations if o.op=='register_item'][0]
assert item.args['icon'] and item.args['icon']['texture_id']=='itemdemo:item/token'
out=compile_program(prog,ROOT/'item_out')
assert json.loads((out/'resource_pack/textures/item_texture.json').read_text())['texture_data']['token']['textures']=='textures/item/token'
print('4 item model layer0 lowering: PASS')

# 5 sound-only program still emits definitions after 6.2 fix.
p5=Program('soundsonly',[Operation('register_sound','soundsonly:test',{'definition':{'category':'master','sounds':[{'name':'sounds/soundsonly/test'}]},'assets_bytes_hex':{'assets/soundsonly/sounds/test.ogg':'4f676753'},'assets':['assets/soundsonly/sounds/test.ogg']},'convertible','fabric')])
out5=compile_program(p5,ROOT/'sound_out')
assert (out5/'resource_pack/sounds/sound_definitions.json').exists()
print('5 sound-only output: PASS')

print('ALL 5 TESTS PASS')
