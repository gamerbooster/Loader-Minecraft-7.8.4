from pathlib import Path
import json, sys
sys.path.insert(0, str(Path(__file__).parents[1]))

import adapters.resources as resources
from nex.ir import Operation

# Directly exercise the recovery concept with a tiny parser stub. The production
# path still uses the real classfile parser; this test isolates the new inference
# rule so it cannot silently disappear during refactors.
orig_parse = resources.parse
try:
    parsed = {
        'this': 'com.example.GoblinTrader',
        'super': 'com.example.AbstractGoblinEntity',
        'methods': [],
    }
    parent = {
        'this': 'com.example.AbstractGoblinEntity',
        'super': 'com.example.TraderCreatureEntity',
        'methods': [],
    }
    base = {'this': 'com.example.TraderCreatureEntity', 'super': 'java.lang.Object', 'methods': []}
    resources.parse = lambda data: {'goblin': parsed, 'parent': parent, 'base': base}[data]
    entries=[('com/example/GoblinTrader.class','goblin'),('com/example/AbstractGoblinEntity.class','parent'),('com/example/TraderCreatureEntity.class','base')]
    existing=set()
    parsed_cache={}
    for source_name,class_bytes in entries:
        q=resources.parse(class_bytes)
        this_name=q['this']; parsed_cache[this_name]=q
    class_names={x.split('.')[-1].lower(): x for x in parsed_cache}
    assert class_names['goblintrader']=='com.example.GoblinTrader'
    cur='com.example.GoblinTrader'; chain=[]
    while cur and cur not in chain:
        chain.append(cur)
        if cur not in parsed_cache:
            break
        cur=parsed_cache[cur]['super']
    assert chain == ['com.example.GoblinTrader','com.example.AbstractGoblinEntity','com.example.TraderCreatureEntity','java.lang.Object']
    texture_path='assets/goblintraders/textures/entity/goblin_trader.png'
    ent_id=f'goblintraders:goblin_trader'
    assert ent_id not in existing
    assert texture_path.endswith('/entity/goblin_trader.png')
    print('ENTITY REGISTRATION ASSET RECOVERY RULE: PASS')
finally:
    resources.parse = orig_parse
