from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
main=(ROOT/'android/app/src/main/java/com/nex/loader/MainActivity.java').read_text(encoding='utf-8')
limits=(ROOT/'core/nex/io_limits.py').read_text(encoding='utf-8')
bridge=(ROOT/'android/app/src/main/python/nex_android_bridge.py').read_text(encoding='utf-8')
assert 'MAX_SELECTED_INPUT_BYTES' in main
assert 'MAX_SELECTED_TREE_FILES' in main and 'MAX_SELECTED_TREE_BYTES' in main
assert 'copyLimited(' in main
assert 'fetchMissingExternals = fetchExternals.isChecked()' in main
assert 'MAX_ZIP_MEMBER_BYTES' in limits and 'read_zip_member' in limits
assert 'read_zip_member' in bridge or 'build_ir' in bridge
print('1 Android selected-file ceiling: PASS')
print('2 Android folder count/byte ceilings: PASS')
print('3 Python nested archive bounded reads: PASS')
print('4 UI option captured before worker thread: PASS')
print('ALL ANDROID HARDENING TESTS PASS')
