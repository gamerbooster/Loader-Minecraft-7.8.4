from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0,str(Path(__file__).parents[1]))
from adapters.loader import detect
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path('/tmp/nex72'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
jar=ROOT/'fabricmeta.jar'
with zipfile.ZipFile(jar,'w') as z:
    z.writestr('fabric.mod.json',json.dumps({
        'id':'fabricmeta','version':'1.0.0',
        'entrypoints':{'main':['com.example.Main'], 'server':[{'value':'com.example.Server','adapter':'default'}], 'client':['com.example.Client']},
        'mixins':['fabricmeta.mixins.json']
    }))
    z.writestr('fabricmeta.mixins.json',json.dumps({'required':True,'package':'com.example.mixin','mixins':['CommonMixin'],'client':['ClientMixin']}))
info=detect(jar)
assert info['loader']=='fabric'
assert len(info['mods'][0]['entrypoints']['main'])==1
assert info['mods'][0]['mixins']==['fabricmeta.mixins.json']
print('1 Fabric entrypoint + Mixin metadata detection: PASS')
_,prog=build_ir(jar)
ops={o.op for o in prog.operations}
assert 'entrypoint' in ops and 'mixin' in ops
assert any(o.op=='entrypoint' and o.args['kind']=='server' and o.status=='adaptable' for o in prog.operations)
assert any(o.op=='mixin' and o.args['class']=='com.example.mixin.CommonMixin' for o in prog.operations)
out=ROOT/'out'; compile_program(prog,out)
report=json.loads((out/'conversion_report.json').read_text())
assert report['status']=='partial'
assert 'entrypoint' in {x['op'] for x in report['skipped']}
assert 'mixin' in {x['op'] for x in report['skipped']}
print('2 IR/report retention of reconstruction-required metadata: PASS')
print('ALL 2 TESTS PASS')
