from pathlib import Path
import tempfile, zipfile, json, sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.input_detect import detect_input_kind
from adapters.resourcepack import compile_resource_pack
from nex.ir import Program, Operation
from nex.compiler import compile_program

root=Path(__file__).parents[2]
main=(root/'android/app/src/main/java/com/nex/loader/MainActivity.java').read_text(encoding='utf-8')
assert 'ext.equals("zip")' not in main
bridge=(root/'android/app/src/main/python/nex_android_bridge.py').read_text(encoding='utf-8')
assert "'java_shaderpack'" in bridge

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    p=Program('closure')
    p.add(Operation('capability','ui.screen',{'target':'@minecraft/server-ui'},'adaptable','java','Ui.class'))
    out=compile_program(p,td/'out')
    errors=[]
    from nex.output_validate import validate_compiled_output
    errors=validate_compiled_output(out)
    assert not errors, errors
    # Local runtime imports are checked by the final validator.

print('ANDROID ROUTING + RUNTIME CLOSURE: PASS')
