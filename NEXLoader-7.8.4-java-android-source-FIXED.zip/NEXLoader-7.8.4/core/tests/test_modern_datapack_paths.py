from pathlib import Path
import json, sys, tempfile, zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adapters.resources import build_ir
from nex.compiler import compile_program

PNG=bytes.fromhex(
    '89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C489'
    '0000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082'
)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); jar=td/'modern.jar'
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('fabric.mod.json',json.dumps({'id':'watching','version':'1.0.0'}))
        # Three real item definitions.
        for name in ('deathbed','herobrine_lullaby','hes_from_the_fog'):
            z.writestr(f'assets/watching/items/{name}.json',
                       json.dumps({'model': f'watching:item/{name}'}))
            z.writestr(f'assets/watching/models/item/{name}.json',
                       json.dumps({'textures': {'layer0': f'watching:item/{name}'}}))
            z.writestr(f'assets/watching/textures/item/{name}.png', PNG)
        # Auxiliary JSON under the same directory must NOT become items.
        z.writestr('assets/watching/items/ui/config.json', '{"screens":[]}')
        z.writestr('assets/watching/items/skins/default.json', '{"skin":"default"}')
        # Modern singular data-pack paths.
        z.writestr('data/watching/function/start_events.mcfunction',
                   'say hello\\nscoreboard players set started_events watching.global_values 1\\n')
        z.writestr('data/watching/function/main/tick.mcfunction',
                   'function watching:start_events\\n')
        z.writestr('data/watching/recipe/test.json', '{"type":"minecraft:crafting_shaped","pattern":["X"],"key":{"X":{"item":"minecraft:stick"}}}')
        z.writestr('data/watching/loot_table/test.json', '{"type":"minecraft:chest","pools":[]}')
        z.writestr('data/watching/advancement/test.json', '{"criteria":{}}')
    _,p=build_ir(jar)
    items=[o for o in p.operations if o.op=='register_item']
    funcs=[o for o in p.operations if o.op=='register_function']
    recipes=[o for o in p.operations if o.op=='register_recipe']
    loots=[o for o in p.operations if o.op=='register_loot_table']
    adv=[o for o in p.operations if o.op=='register_advancement']
    assert len(items)==3, [(o.id,o.source) for o in items]
    assert all('/items/ui/' not in o.source and '/items/skins/' not in o.source for o in items)
    assert len(funcs)==2, [(o.id,o.source) for o in funcs]
    assert len(recipes)==1 and len(loots)==1 and len(adv)==1
    out=compile_program(p,td/'out')
    report=json.loads((out/'conversion_report.json').read_text())
    item_files=sorted((out/'behavior_pack/items').glob('*.json'))
    assert len(item_files)==3, [x.name for x in item_files]
    assert (out/'resource_pack/textures/item_texture.json').exists()
    assert (out/'behavior_pack/functions/watching/start_events.mcfunction').exists()
    assert (out/'behavior_pack/functions/watching/main/tick.mcfunction').exists()
    assert (out/'behavior_pack/nex_untranslated/advancements/test.json').exists()
    # No phantom item files for nested auxiliary JSON.
    assert not (out/'behavior_pack/items/config.json').exists()
    assert not (out/'behavior_pack/items/default.json').exists()
    print('MODERN DATAPACK PATHS: PASS')
