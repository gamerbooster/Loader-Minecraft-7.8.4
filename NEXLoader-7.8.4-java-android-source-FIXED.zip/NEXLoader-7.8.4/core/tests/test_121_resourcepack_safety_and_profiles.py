from pathlib import Path
import json, tempfile, zipfile, sys, struct, zlib
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resourcepack import compile_resource_pack
from adapters.input_detect import detect_input_kind


def png8():
    px=b'\x00'+b'\x80\x40\x20\xff'
    def c(t,d):
        return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+c(b'IHDR',struct.pack('>IIBBBBB',1,1,8,6,0,0,0))+c(b'IDAT',zlib.compress(px))+c(b'IEND',b'')

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    rp=td/'resource.zip'
    with zipfile.ZipFile(rp,'w') as z:
        z.writestr('pack.mcmeta',json.dumps({'pack':{'pack_format':15,'description':'texture test'}}))
        z.writestr('pack.png',png8())
        z.writestr('assets/demo/textures/block/a.png',png8())
        z.writestr('assets/demo/textures/block/b.jpg',b'not-a-png')
        z.writestr('assets/demo/optifine/cit.properties','type=item')
        z.writestr('overlays/new/assets/demo/textures/block/a.png',png8())
    assert detect_input_kind(rp)=='java_resource_pack'
    out=compile_resource_pack(rp,td/'out','java_resource_pack')
    assert (out/'resource_pack/pack_icon.png').read_bytes()==png8()
    assert (out/'resource_pack/textures/demo/block/a.png').is_file()
    assert not (out/'resource_pack/textures/demo/block/b.jpg').exists()
    assert (out/'resource_pack/nex_untranslated/raster/assets/demo/textures/block/b.jpg').is_file()
    assert (out/'resource_pack/nex_untranslated/overlays/overlays/new/assets/demo/textures/block/a.png').is_file()
    report=json.loads((out/'conversion_report.json').read_text())
    assert report['optifine_features']
    assert any('not PNG' in x['reason'] for x in report['unsupported'])
print('RESOURCE PACK SAFETY + OPTIFINE PROFILE: PASS')
