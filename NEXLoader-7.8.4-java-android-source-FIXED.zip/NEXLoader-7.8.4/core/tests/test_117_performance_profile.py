from pathlib import Path
import tempfile, json
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from nex.ir import Program, Operation
from nex.compiler import compile_program
with tempfile.TemporaryDirectory() as td:
    p=Program('sodium')
    p.add(Operation('performance_profile','sodium:optimization:sodium',{'profile':'sodium','kind':'java_renderer_optimization'},'adaptable','java','fabric.mod.json'))
    out=compile_program(p,Path(td)/'out')
    assert (out/'behavior_pack/nex_untranslated/performance_profiles.json').is_file()
    report=json.loads((out/'conversion_report.json').read_text())
    assert report['performance_profiles']
print('PERFORMANCE PROFILE LOWERING: PASS')
