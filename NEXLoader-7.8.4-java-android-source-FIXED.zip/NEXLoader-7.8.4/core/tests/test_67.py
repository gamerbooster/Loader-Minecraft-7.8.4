from pathlib import Path
import io,json,shutil,sys,zipfile
sys.path.insert(0,str(Path(__file__).parents[1]))
from adapters.modpack import inspect_modpack, build_modpack_ir

ROOT=Path('/tmp/nex67'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
outer=ROOT/'host.jar'; embedded=io.BytesIO()
with zipfile.ZipFile(embedded,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'embedded','version':'1.2.3'}))
    z.writestr('assets/embedded/lang/en_us.json',json.dumps({'item.embedded:test':'Nested'}))
with zipfile.ZipFile(outer,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('META-INF/mods.toml','modLoader="javafml"\nloaderVersion="[1,)"\n[[mods]]\nmodId="host"\nversion="1.0.0"\n')
    z.writestr('META-INF/jarjar/embedded.jar',embedded.getvalue())
pack=ROOT/'pack'; (pack/'mods').mkdir(parents=True)
shutil.copy2(outer,pack/'mods/host.jar')
info=inspect_modpack(pack)
ids=sorted(n.mod_id for _,_,n in info['mods'])
assert 'host' in ids and 'embedded' in ids
print('1 embedded Jar-in-Jar mod discovery: PASS')
prog,res,tmp=build_modpack_ir(pack,'nestedpack')
try:
    assert 'embedded' in [n.mod_id for n in res.ordered]
    assert any(d.get('code')=='MODPACK_DETECTED' and d.get('embedded_mods')==1 for d in prog.diagnostics)
    assert any(o.id=='embedded:en_US' and o.op=='register_language' for o in prog.operations)
finally:
    shutil.rmtree(tmp,ignore_errors=True)
print('2 embedded mod merged into NEX-IR: PASS')
print('ALL 2 TESTS PASS')
