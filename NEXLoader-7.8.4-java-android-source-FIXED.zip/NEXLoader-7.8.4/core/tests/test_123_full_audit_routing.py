from pathlib import Path
import json, tempfile, zipfile, sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.input_detect import detect_input_kind
from adapters.resourcepack import compile_resource_pack
from nex.ir import Program, Operation
from nex.compiler import compile_program
from analyzer.failure_predictor import predict_failures

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    folder=td/'JavaPack'; (folder/'assets/minecraft/textures/block').mkdir(parents=True)
    (folder/'pack.mcmeta').write_text(json.dumps({'pack':{'pack_format':15,'description':'x'}}))
    (folder/'assets/minecraft/textures/block/stone.png').write_bytes(b'\x89PNG\r\n\x1a\n'+b'0'*100)
    assert detect_input_kind(folder)=='java_resource_pack'

    p=Program('evidence',[Operation('capability','shader.java_pipeline',{'class':'Renderer','method':'render','line':88},'adaptable','java','Renderer.class')])
    fp=predict_failures(p)
    assert any(f.get('code')=='ADAPTABLE_FEATURE' and f.get('line')==88 for f in fp['findings'])
    out=compile_program(p,td/'out')
    ev=json.loads((out/'source_evidence.json').read_text())
    assert ev['operations'] and ev['failure_first']['analysis']=='failure-first'
    print('FOLDER ROUTING + SOURCE EVIDENCE INDEX: PASS')
