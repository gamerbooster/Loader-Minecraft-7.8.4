from pathlib import Path
import json, sys, tempfile, zipfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adapters.resources import build_ir
from nex.compiler import compile_program

PNG=bytes.fromhex(
    '89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C489'
    '0000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082'
)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); jar=td/'fog.jar'
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('fabric.mod.json',json.dumps({'id':'lunareclipse.watching','version':'1.10.0'}))
        z.writestr('data/lunareclipse.watching/function/main/tick.mcfunction',
                   'summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:stone"}}\\n')
        z.writestr('assets/lunareclipse.watching/textures/item/skins/default.png',PNG)
    _,p=build_ir(jar)
    ents=[o for o in p.operations if o.op=='register_entity']
    assert len(ents)==1 and ents[0].id=='lunareclipse.watching:herobrine'
    out=compile_program(p,td/'out')
    assert (out/'behavior_pack/entities/herobrine.json').exists()
    assert (out/'resource_pack/entity/herobrine.entity.json').exists()
    assert (out/'resource_pack/models/entity/herobrine.geo.json').exists()
    client=json.loads((out/'resource_pack/entity/herobrine.entity.json').read_text())
    assert 'spawn_egg' in client['minecraft:client_entity']['description']
    assert (out/'resource_pack/textures/entity/herobrine.png').exists()
    print('DISPLAY ENTITY PROXY: PASS')
