from pathlib import Path
import sys,tempfile,zipfile,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adapters.resources import build_ir
from nex.compiler import compile_program

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)

# Compile Java that combines EntityType.Builder with Registry.register.
with tempfile.TemporaryDirectory() as td:
    td=Path(td); src=td/'src'; (src/'demo').mkdir(parents=True); (src/'net/minecraft/entity').mkdir(parents=True); (src/'net/minecraft/registry').mkdir(parents=True)
    (src/'demo/Entities.java').write_text('''package demo;\npublic class Entities { public static void init() { net.minecraft.registry.Registry.register(null, "demo:robot", net.minecraft.entity.EntityType.Builder.create().build()); } }\n''')
    (src/'net/minecraft/entity/EntityType.java').write_text('''package net.minecraft.entity; public class EntityType { public static class Builder { public static Builder create(){return new Builder();} public Object build(){return null;} } }''')
    (src/'net/minecraft/registry/Registry.java').write_text('''package net.minecraft.registry; public class Registry { public static Object register(Object r, String id, Object value){return value;} }''')
    classes=td/'classes'; classes.mkdir()
    subprocess.run(['javac','-d',str(classes),str(src/'demo/Entities.java'),str(src/'net/minecraft/entity/EntityType.java'),str(src/'net/minecraft/registry/Registry.java')],check=True)
    jar=td/'entity.jar'
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('fabric.mod.json',json.dumps({'id':'entitymod','version':'1.0.0'}))
        z.writestr('assets/entitymod/textures/entity/robot.png',bytes.fromhex('89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082'))
        for f in classes.rglob('*.class'): z.write(f,f.relative_to(classes))
    _,p=build_ir(jar); ents=[o for o in p.operations if o.op=='register_entity']
    ok('1 Java EntityType registration recovered', len(ents)==1 and ents[0].id=='demo:robot')
    out=compile_program(p,td/'out')
    ok('2 behavior entity emitted', (out/'behavior_pack/entities/robot.json').exists())
    ok('3 matching entity visual emitted', (out/'resource_pack/entity/robot.entity.json').exists() and (out/'resource_pack/models/entity/robot.geo.json').exists())
    report=json.loads((out/'conversion_report.json').read_text())
    ok('4 entity appears in report', any(e.get('op')=='register_entity' for e in report['emitted']))
print('ALL 4 ENTITY TESTS PASS')
