# NEXLoader 7.8.4 — M2 verification report

Date: 2026-10-05

## Result

- Full regression suite: **80 PASS / 0 FAIL**
- Android Source Lint: **18/18 PASS**
- Version check: **PASS — 7.8.4**
- Release preflight: **PASS**
- Release smoke conversion: **PASS**
- Java syntax/compile check for embedded Python: **PASS**

## M2 correction

The Android world converter no longer rejects conversion solely because Android/ART is not a desktop Java SE 17 runtime.

The world engine now:

1. Detects a supported Android ABI (aarch64 or x86_64).
2. Downloads the matching Android OpenJDK 17 artifact from the FCL-Team Build_JRE_17 workflow.
3. Safely extracts and verifies `release` and `bin/java`.
4. Runs `java -version` and requires Java 17+.
5. Downloads Chunker CLI 1.21.0 and verifies its pinned SHA-256.
6. Runs Chunker with the Android JRE.
7. Validates the resulting Bedrock world and packages `.mcworld`.
8. Reuses the downloaded runtime and engine on later conversions.

## Android memory guard

Chunker receives a conservative dynamic `-Xmx` based on the device's reported physical RAM, avoiding the desktop-style default of consuming most of the process memory.

## User-visible build marker

`NEXLoader 7.8.4 • MANTENIMIENTO M2`

Build ID:
`7.8.4-M2-ANDROID-JRE17-2026-10-05`

## Important limitation

The Android device itself was not available in this build environment, so the JRE bootstrap and Chunker execution path were regression-tested with deterministic mocks/static checks, not with a physical Android handset. The first real handset test is therefore still required to confirm the specific device's ABI, kernel, and native runtime compatibility.
