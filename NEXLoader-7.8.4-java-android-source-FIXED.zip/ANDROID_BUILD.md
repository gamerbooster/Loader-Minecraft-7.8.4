# Android build gate

NEXLoader 7.8.4 uses:
- Android Gradle Plugin 8.11.1
- Gradle 8.13
- Kotlin 2.2.20
- Chaquopy 17.0.0
- AndroidX Activity 1.13.0
- compileSdk/targetSdk 35
- Python 3.13 inside Chaquopy

The repository contains the Python converter under `android/app/src/main/python` and the Kotlin UI/bridge.

To build a debug APK on a machine with the Android SDK:

```bash
cd android
# Generate wrapper once if absent:
gradle wrapper --gradle-version 8.13
cd ..
ANDROID_SDK_ROOT=/path/to/Android/Sdk ./tools/build_android.sh
```

Required SDK components include platform 35 and build-tools 35.0.0. The project is intentionally not marked as having a verified APK until `assembleDebug` succeeds.


## M3 World Engine

World conversion is local inside the APK. The Android build task downloads and verifies:

- Chunker CLI 1.21.0 (`chunker-cli-1.21.0.jar`)
- Android OpenJDK 17 for `arm64-v8a`
- Android OpenJDK 17 for `x86_64`

The build task extracts the two JREs into APK assets. `WorldEngine.java` copies the matching ABI JRE into app-private storage, sets `JAVA_HOME`/`LD_LIBRARY_PATH`, checks `java -version`, checks `Chunker --help`, runs the documented CLI, and creates a `.mcworld` from the resulting Bedrock world.

The source pins SHA-256 hashes for all three downloaded artifacts. A build fails closed if any hash or expected `bin/java` file is missing.
