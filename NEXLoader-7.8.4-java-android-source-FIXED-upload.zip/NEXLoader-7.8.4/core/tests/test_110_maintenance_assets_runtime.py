from pathlib import Path
import io, json, tempfile, zipfile
from PIL import Image
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from nex.compiler import compile_program
from nex.ir import Program, Operation

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    # Real source artwork outside assets/*/textures/* must win over NEX's generated icon.
    img=Image.new('RGBA',(16,16),(20,40,60,255)); bio=io.BytesIO(); img.save(bio,format='PNG'); icon=bio.getvalue()
    jar=td/'asset.jar'
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('fabric.mod.json',json.dumps({'id':'assetmod','version':'1.0.0'}))
        z.writestr('assets/assetmod/icon.png', icon)
        z.writestr('assets/assetmod/textures/entity/monster.png', icon)
    info,p=build_ir(jar)
    assert any(o.op=='register_pack_asset' for o in p.operations)
    p.add(Operation('register_entity','assetmod:monster',{},'emulated','java','Monster.class'))
    out=compile_program(p,td/'out')
    out_icon=(out/'behavior_pack/pack_icon.png').read_bytes()
    assert out_icon.startswith(b'\x89PNG') and out_icon[16:24] == (256).to_bytes(4,'big')*2
    assert out_icon == (out/'resource_pack/pack_icon.png').read_bytes()
    assert (out/'resource_pack/textures/entity/monster.png').read_bytes()==icon

    geo={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.assetmod_monster','texture_width':16,'texture_height':16},'bones':[]} ]}
    prog=Program('assetmod',[Operation('register_entity_visual','assetmod:monster',{'geometry_data':geo,'geometry':'geometry.assetmod_monster','texture_id':'assetmod:entity/monster'},'convertible','java','assets/assetmod/models/entity/monster.json'), Operation('register_entity','assetmod:monster',{},'emulated','java','Monster.class'), Operation('register_sound','assetmod:roar',{'definition':{'category':'hostile','sounds':[{'name':'sounds/assetmod/roar'}]},'assets':['assets/assetmod/sounds/roar.ogg'],'assets_bytes_hex':{'assets/assetmod/sounds/roar.ogg':'4f676753'},},'convertible','java','assets/assetmod/sounds.json'), Operation('sound_play','Monster.playSound',{'method':'playSound','sound_hint':'assetmod:roar','resolved_sound_id':'assetmod:roar'},'convertible','java','Monster.class'), Operation('scoreboard_op','Scoreboard.setScore',{'method':'setScore'},'convertible','java','Scoreboard.class')])
    out=compile_program(prog,td/'runtime_out')
    client=json.loads((out/'resource_pack/entity/monster.entity.json').read_text())
    assert client['minecraft:client_entity']['description']['geometry']['default']=='geometry.assetmod_monster'
    assert 'sounds.js' in {p.name for p in (out/'behavior_pack/scripts/nex_runtime').iterdir()}
    assert 'scoreboard.js' in {p.name for p in (out/'behavior_pack/scripts/nex_runtime').iterdir()}
    bridge=(out/'behavior_pack/scripts/nex_bridge.js').read_text()
    assert 'assetmod:roar' in bridge
    assert 'scoreboard' in bridge.lower()
print('MAINTENANCE ASSETS / ENTITY VISUAL / SOUND / SCOREBOARD: PASS')
