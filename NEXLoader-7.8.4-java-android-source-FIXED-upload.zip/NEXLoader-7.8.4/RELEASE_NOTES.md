# NEXLoader 7.8.4

- Added central bounded ZIP/JAR member reads for the Python core, with per-class and per-JSON limits.
- Embedded Jar-in-Jar extraction now enforces an actual streaming decompression ceiling.
- Java class scanning skips oversized class members with explicit diagnostics instead of buffering them.
- Android PackAnalyzer now uses bounded stream reads for nested JARs and metadata.
- Android file/folder imports now enforce file count, nesting and byte ceilings.
- Android conversion captures the external-download checkbox before entering the worker thread.
- Added regression tests for bounded archive reads and Android input hardening.
- Bumped Android versionCode/versionName and synchronized core metadata to 7.8.3.

## 7.7 hardening retained

- Corrupt Fabric, Quilt, Forge and NeoForge manifests fail explicitly instead of becoming an `unknown` mod.
- Empty ModPacks are marked incomplete with an `EMPTY_MODPACK` diagnostic.
- External Modrinth downloads are verified from streamed temporary files and published atomically only after integrity checks.
- Local Modrinth artifact verification hashes files incrementally.

## 7.7 worldgen retained

- Conservative Java worldgen lowering for simple ore configured features.
- Simple fixed-block worldgen lowering for supported random/vegetal patch providers.
- Simple placed-feature lowering to Bedrock scatter features for count/in-square/biome and uniform absolute height modifiers.
- Generated feature rules can attach converted placed features to converted custom biomes.
- Complex worldgen graphs remain lossless under `nex_untranslated/worldgen/` and explicit as adaptable.

Real APK generation remains gated on an actual Android SDK + Gradle environment and is not claimed unless `assembleDebug` succeeds.


## 7.8.4 V6 fixes
- Prefer original mod PNG artwork for pack icons; no synthetic icon when source artwork exists.
- Entity texture resolver now searches across namespaces and by entity basename before falling back.
- Generated entities use an explicit UV and alphatest material.
- Detect Java sound playback calls for later Bedrock lowering.

## 7.8.4 V7 maintenance

- Full pre-test maintenance pass across the converter, Java analyzer, resource/model extraction, runtime bridges, Android embedded core, validation, and release checks.
- Pack icons now prefer real PNG artwork found in the source mod assets, including icon-like PNGs outside the normal textures directory; source artwork is normalized without inventing a replacement when a usable PNG exists.
- Entity visual extraction now preserves supported Java entity geometry/model data and performs broader texture matching before falling back to placeholder geometry.
- Java sound playback calls now produce explicit `sound_play` IR operations, resolve against the generated sound registry, and have a Bedrock runtime bridge for safe playback contexts.
- Java scoreboard/objective calls now produce explicit `scoreboard_op` IR operations and package a namespaced-safe Bedrock scoreboard runtime bridge.
- Generated runtime bridge capability comments are de-duplicated to keep conversion output readable.
- Added analyzer regression coverage for sound and scoreboard detection.
- Fixed a V7 analyzer defect where detected sound/scoreboard operations referenced an undefined loader variable; these operations now correctly record `java` as their source loader.
- Core Python and the Android embedded Python copy are synchronized with zero source differences.

## Maintenance verification
- VERSION CHECK: PASS (7.8.4)
- TEST SUITE: 61 PASS / 0 FAIL
- ANDROID SOURCE LINT: 18/18 PASS
- Analyzer sound + scoreboard regression: PASS
- Release smoke conversion + output validation: PASS
