from nex.ir import Operation
from pathlib import Path
import re
from .classfile import parse, code_scan
from compat.analyzer import analyze_call

FORGE_DEFERRED_REGISTER_OWNERS={
    'net/minecraftforge/registries/DeferredRegister',
    'net/minecraftforge/registries/DeferredRegisterImpl',
}


def _sanitize_identifier(value: str) -> str:
    value = re.sub(r'[^a-z0-9_.-]+', '_', str(value).lower())
    value = re.sub(r'_+', '_', value).strip('_.-')
    return value or 'unknown'

def _registration_id(ids, namespace, fallback):
    """Recover a Bedrock-safe registration id from bytecode string constants.
    Prefer fully-qualified ids, then plausible simple names. Never return 'unknown'.
    """
    strings = [x for x in (ids or []) if isinstance(x, str) and x]
    full = next(
        (x for x in reversed(strings)
         if re.fullmatch(r'[A-Za-z0-9_.-]+:[A-Za-z0-9_/.-]+', x)),
        None,
    )
    if full:
        return full.lower()
    simple = next(
        (x for x in reversed(strings)
         if re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,63}', x)
         and x.lower() not in {'unknown', 'register', 'build', 'create', 'of'}),
        None,
    )
    if simple:
        return f'{namespace}:{_sanitize_identifier(simple)}' if namespace else _sanitize_identifier(simple)
    return fallback

FABRIC_TICK_OWNERS={
 'net/fabricmc/fabric/api/event/lifecycle/v1/ServerTickEvents$EndTick':'server_tick',
 'net/fabricmc/fabric/api/event/lifecycle/v1/ServerTickEvents$StartTick':'server_tick',
}

def analyze_classes(entries, diagnostics=None, namespace=None):
    ops=[]
    diagnostics = diagnostics if diagnostics is not None else []
    namespace = str(namespace or '').strip() or None
    for source,data in entries:
        try:
            p=parse(data)
        except Exception as exc:
            diagnostics.append({'code':'CLASSFILE_PARSE_FAILED','message':str(exc),'source':source})
            continue
        method_calls = {}
        method_has_entity_builder = {}
        for candidate in p['methods']:
            ccalls = code_scan(p, candidate)
            key = (candidate.get('name'), candidate.get('descriptor'))
            method_calls[key] = ccalls
            method_has_entity_builder[key] = any(
                'EntityType' in (c.get('owner') or '')
                and (
                    'Builder' in (c.get('owner') or '')
                    or c.get('name') in {'create','build','of'}
                )
                for c in ccalls
            )

        for m in p['methods']:
            calls=method_calls.get((m.get('name'),m.get('descriptor')),[])
            has_entity_builder=method_has_entity_builder.get((m.get('name'),m.get('descriptor')),False)
            for call_index, c in enumerate(calls):
                cap_op = analyze_call(c, 'java', source)
                if cap_op:
                    ops.append(cap_op)
                owner,name=c.get('owner'),c.get('name')
                if cap_op and cap_op.id == 'client.input':
                    hints=' '.join(c.get('near_strings') or []).lower()
                    button='Jump' if 'jump' in hints else ('Sneak' if 'sneak' in hints or 'shift' in hints else None)
                    ops.append(Operation('keybind', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'),
                        'button_hint': button, 'hints': c.get('near_strings') or []
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'ui.screen':
                    title=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('ui_screen', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'), 'title_hint': title
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'client.hud':
                    ops.append(Operation('hud_overlay', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor')
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'particle.spawn':
                    particle=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('particle', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'), 'particle_hint': particle
                    }, 'convertible', 'java', source))
                if owner in FABRIC_TICK_OWNERS and name=='register':
                    cb=c.get('callback_target') or {}
                    ops.append(Operation('event',FABRIC_TICK_OWNERS[owner],{
                        'method':m['name'],'callback':cb
                    },'convertible','fabric',source))
                elif owner=='net/minecraft/world/World' and name=='sendMessage':
                    msg=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('world_message',f'{p["this"]}.{m["name"]}',{
                        'method':m['name'],'message':msg
                    },'convertible' if msg else 'adaptable','java',source))
                elif owner=='net/minecraft/registry/Registry' and name=='register':
                    ids=c.get('near_strings') or []
                    fallback=f'{namespace}:{_sanitize_identifier(Path(source).stem)}_{_sanitize_identifier(m.get("name") or "register")}_{call_index}' if namespace else f'unknown:entity_{call_index}'
                    reg_id=_registration_id(ids, namespace, fallback)
                    callback = c.get('callback_target') or {}
                    callback_key = (callback.get('name'), callback.get('descriptor'))
                    callback_has_entity_builder = method_has_entity_builder.get(callback_key, False)
                    entity_builder = has_entity_builder or callback_has_entity_builder
                    if entity_builder:
                        ops.append(Operation('register_entity',reg_id,{
                            'method':m['name'], 'owner':owner, 'near_strings':ids,
                            'callback_target':callback,
                            'entity_builder_detected':True, 'loader_hint':'java'
                        },'emulated','java',source))
                    elif reg_id != fallback:
                        ops.append(Operation('register_content',reg_id,{
                            'method':m['name'], 'near_strings':ids
                        },'adaptable','java',source))
                    else:
                        diagnostics.append({
                            'code':'REGISTRY_REGISTER_ID_UNRECOVERED',
                            'message':f'Ignored Java Registry.register without a recoverable id: {reg_id}',
                            'source':source
                        })
                elif owner in FORGE_DEFERRED_REGISTER_OWNERS and name=='register':
                    ids=c.get('near_strings') or []
                    fallback=f'{namespace}:{_sanitize_identifier(Path(source).stem)}_{_sanitize_identifier(m.get("name") or "register")}_{call_index}' if namespace else f'unknown:entity_{call_index}'
                    reg_id=_registration_id(ids, namespace, fallback)
                    callback = c.get('callback_target') or {}
                    callback_key = (callback.get('name'), callback.get('descriptor'))
                    callback_has_entity_builder = method_has_entity_builder.get(callback_key, False)
                    entity_builder = has_entity_builder or callback_has_entity_builder
                    if entity_builder:
                        ops.append(Operation('register_entity',reg_id,{
                            'method':m['name'], 'owner':owner, 'near_strings':ids,
                            'callback_target':callback,
                            'entity_builder_detected':True, 'loader_hint':'forge',
                            'registration_style':'DeferredRegister'
                        },'emulated','forge',source))
                        diagnostics.append({
                            'code':'FORGE_ENTITY_REGISTRATION_RECOVERED',
                            'message':f'Recovered Forge DeferredRegister entity {reg_id}',
                            'source':source
                        })
                    elif reg_id != fallback:
                        ops.append(Operation('register_content',reg_id,{
                            'method':m['name'], 'near_strings':ids,
                            'registration_style':'DeferredRegister'
                        },'adaptable','forge',source))
                    else:
                        diagnostics.append({
                            'code':'FORGE_REGISTER_ID_UNRECOVERED',
                            'message':f'Ignored Forge DeferredRegister.register without a recoverable id: {reg_id}',
                            'source':source
                        })
                elif owner=='net/minecraftforge/eventbus/api/IEventBus' and name in ('addListener','addGenericListener'):
                    ops.append(Operation('event',f'forge:{name}',{
                        'method':m['name'],'callback':c.get('callback_target') or {}
                    },'adaptable','forge',source))
    return ops
